
<?php
  //SELECT @@GLOBAL.sql_mode;
  //SET sql_mode = '';
  //SET GLOBAL sql_mode = 'NO_ENGINE_SUBSTITUTION';
  //Customers
  function find_all_customers() {
    global $db;

    $sql = "SELECT * FROM MQ_CUST ";
    $sql .= "ORDER BY cust_id ASC";
    $result = mysqli_query($db, $sql);
    return $result;
  }
  function find_customer_by_id($id) {
    global $db;

    $sql = "SELECT * FROM MQ_CUST ";
    $sql .= "WHERE cust_id='" . db_escape($db, $id) . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $customer = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $customer; 
  }
  function find_all_individuals() {
    global $db;

    $sql = "SELECT * FROM MQ_CUST ";
    $sql .= "WHERE cust_type='" . 'I' . "'";
    $sql .= " ORDER BY cust_id ASC";
    $result = mysqli_query($db, $sql);
    return $result;
  }
  function find_all_corporations() {
    global $db;

    $sql = "SELECT * FROM MQ_CUST ";
    $sql .= "WHERE cust_type='" . 'C' . "'";
    $sql .= " ORDER BY cust_id ASC";
    $result = mysqli_query($db, $sql);
    return $result;
  }


  function validate_customer($customer) {
    $errors = [];

    //CustType
    if(is_blank($customer['cust_type'])) {
      $errors[] = "Please select one customer type.";
    }

    // FirstName
    if(is_blank($customer['fname'])) {
      $errors[] = "First Name cannot be blank.";
    }elseif(is_numeric($customer['fname'])){
      $errors[] = "First Name cannot be Numeric!";
    }elseif(has_special_charac($customer['fname'])){
      $errors[] = "First Name cannot contain special characters.";
    }elseif(!has_length($customer['fname'], ['min' => 2, 'max' => 30])) {
      $errors[] = "First Name must be between 2 and 30 characters.";
    }
    

    // LastName
    if(is_blank($customer['lname'])) {
      $errors[] = "Last Name cannot be blank.";
    } elseif(is_numeric($customer['lname'])){
      $errors[] = "Last Name cannot be Numeric!";
    }elseif(has_special_charac($customer['lname'])){
      $errors[] = "Last Name cannot contain special characters.";
    }elseif(!has_length($customer['lname'], ['min' => 2, 'max' => 30])) {
      $errors[] = "Last Name must be between 2 and 30 characters.";
    }
    

    // State
    if(is_blank($customer['state'])) {
      $errors[] = "State cannot be blank.";
    } elseif(has_special_charac($customer['state'])){
      $errors[] = "State cannot contain special characters.";
    }elseif(is_numeric($customer['state'])){
      $errors[] = "State cannot be Numeric!";
    }elseif(!has_length($customer['state'], ['min' => 2, 'max' => 30])) {
      $errors[] = "State must be between 2 and 30 characters.";
    }

    // City
    if(is_blank($customer['city'])) {
      $errors[] = "City cannot be blank.";
    }elseif(is_numeric($customer['city'])){
      $errors[] = "City cannot be Numeric!";
    }elseif(has_special_charac($customer['city'])){
      $errors[] = "City cannot contain special characters.";
    } elseif(!has_length($customer['city'], ['min' => 2, 'max' => 30])) {
      $errors[] = "City must be between 2 and 30 characters.";
    }
    

    // Street
    if(is_blank($customer['st_addr'])) {
      $errors[] = "Street cannot be blank.";
    }elseif(has_special_charac($customer['st_addr'])){
      $errors[] = "Street cannot contain special characters.";
    }elseif(!has_length_less_than($customer['st_addr'], 45)) {
      $errors[] = "Street must be less than 45 characters.";
    } 

    // Apartment 

    /*if(!is_int($customer['apt'])) {
      $errors[] = "Apartment No. must be integer!";
      $apt_int = (int) $customer['apt'];
    }elseif($apt_int <= 0){
      $errors[] = "Apartment No. must be greater than zero.";
    }*/
    if(!is_blank($customer['apt'])){
      if(!is_numeric($customer['apt'])) {
        $errors[] = "Apartment No. must be numeric.";
      }elseif($customer['apt'] < 0) {
        $errors[] = "Apartment must be positive.";
      }elseif(!has_length_less_than($customer['apt'], 6)) {
        $errors[] = "Apartment No. must be less than 6 characters.";
      }
    }
    
    
    // Zipcode
    // Zipcode numeric?
    if(is_blank($customer['zipcode'])) {
      $errors[] = "Zipcode cannot be blank.";
    }/*elseif(!is_numeric($customer['zipcode'])){
      $errors[] = "Zipcode must be integer.";
      $zipcode_int = (int) $customer['zipcode'];
    }elseif($zipcode_int <= 0) {
      $errors[] = "Zipcode must be greater than zero.";
    }*/elseif(!has_length_exactly($customer['zipcode'], 5)) {
      $errors[] = "Zipcode must be exactly 5 characters.";
    }

    //Email
    if(is_blank($customer['email'])) {
      $errors[] = "Email cannot be blank.";
    } elseif(!has_valid_email_format($customer['email'])) {
      $errors[] = "Please enter valid email format.";
    }

    //Phone
    if(is_blank($customer['phone'])) {
      $errors[] = "Phone cannot be blank.";
    } elseif(!has_valid_phone_format($customer['phone'])) {
      $errors[] = "Please enter valid phone format 'xxx-xxx-xxxx'. ";
    }
    
    return $errors;
  }

  function insert_customer($customer) {
    global $db;

    $errors = validate_customer($customer);
    if(!empty($errors)) {
      return $errors;
    }

    $cust_type = db_escape($db, $customer['cust_type']);
    $firstname = db_escape($db, $customer['fname']);
    $lastname = db_escape($db, $customer['lname']);
    $state = db_escape($db, $customer['state']) ??'';
    $city = db_escape($db, $customer['city']);
    $street = db_escape($db, $customer['st_addr']);
    $apartment = db_escape($db, $customer['apt']) ?? '';
    $zipcode = db_escape($db, $customer['zipcode']);
    $email = db_escape($db, $customer['email']);
    $phone = db_escape($db, $customer['phone']);


    $sql = "INSERT INTO MQ_CUST (cust_type, fname, lname, state, city, st_addr, apt, zipcode, email, phone) VALUES 
    ('$cust_type','$firstname','$lastname', '$state', '$city', '$street', '$apartment', '$zipcode' ,'$email', '$phone')";

    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  } 
  function update_customer($customer) {
    global $db;

    $errors = validate_customer($customer);
    if(!empty($errors)) {
      return $errors;
    }

    $sql = "UPDATE MQ_CUST SET ";
    $sql .= "cust_type='" . db_escape($db, $customer['cust_type']) . "', ";
    $sql .= "fname='" . db_escape($db, $customer['fname']) . "', ";
    $sql .= "lname='" . db_escape($db, $customer['lname']) . "', ";
    $sql .= "state='" . db_escape($db, $customer['state']) . "', ";
    $sql .= "city='" . db_escape($db, $customer['city']) . "', ";
    $sql .= "st_addr='" . db_escape($db, $customer['st_addr']) . "', ";
    $sql .= "apt='" . db_escape($db, $customer['apt']) . "', ";
    $sql .= "zipcode='" . db_escape($db, $customer['zipcode']) . "', ";
    $sql .= "email='" . db_escape($db, $customer['email']) . "', ";
    $sql .= "phone='" . db_escape($db, $customer['phone']) . "' ";
    $sql .= "WHERE cust_id='" . db_escape($db, $customer['cust_id']) . "' ";
    $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  } 
  function delete_customer($id) {
    global $db;

    $sql = "DELETE FROM MQ_CUST ";
    $sql .= "WHERE cust_id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function has_first_name($firstname){
    global $db;

    $fname = db_escape($db, $firstname);
    $sql = "SELECT * FROM MQ_CUST WHERE fname = '$fname' ";

    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $customer = mysqli_fetch_assoc($result); // find first
    mysqli_free_result($result);
    return $customer; // returns an assoc. array

  }


  function has_last_name($lastname){
    global $db;

    $lname = db_escape($db, $lastname);
    $sql = "SELECT * FROM MQ_CUST WHERE lname = '$lname' ";

    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $customer = mysqli_fetch_assoc($result); 
    mysqli_free_result($result);
    return $customer; // returns an assoc. array

  }

  function find_customer_by_custname($firstname, $lastname) {
    global $db;

    $fname = db_escape($db, $firstname);
    $lname = db_escape($db, $lastname);
    $sql = "SELECT * FROM MQ_CUST WHERE fname = '$fname' AND lname = '$lname' ";

    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $customer = mysqli_fetch_assoc($result); // find first
    mysqli_free_result($result);
    return $customer; // returns an assoc. array
  }




  //Individuals
  function find_all_custinds() {
    global $db;

    $sql = "SELECT * FROM MQ_CUSTIND ";
    $sql .= "ORDER BY cust_id ASC";
    $result = mysqli_query($db, $sql);
    return $result;
  }
 
  function find_custind_by_id($id) {
    global $db;

    $sql = "SELECT * FROM MQ_CUSTIND ";
    $sql .= "WHERE cust_id='" . db_escape($db, $id) . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $custind = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $custind;

  } 

  //Used in customer show
  function find_custind_by_custid($id) {
    global $db;

    $sql = "SELECT * FROM MQ_CUSTIND ";
    $sql .= "WHERE cust_id='" . db_escape($db, $id) . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    //$count = mysqli_num_rows($result);
    //$custind = mysqli_fetch_assoc($result);
    //mysqli_free_result($result);
    return $result;

  } 

  function validate_custind($custind) {
    $errors = [];

    //Customer ID
    if(is_blank($custind['cust_id'])) {
      $errors[] = "Please enter customer ID.";
    }

    // Driver License No.
    if(is_blank($custind['DLN'])) {
      $errors[] = "Driver License No. cannot be NULL.";
    } elseif(has_special_charac($custind['DLN'])){
      $errors[] = "Driver License No. cannot contain special characters.";
    }elseif(!has_length($custind['DLN'], ['min' => 4, 'max' => 16])) {
      $errors[] = "Driver License No. must be between 5 and 16 characters.";
    }
    


    // Insurace Company Name
    if(is_blank($custind['INSCN'])) {
      $errors[] = "Insurace Company Name cannot be NULL.";
    }elseif(has_special_charac($custind['INSCN'])){
      $errors[] = "Insurace Company Name cannot contain special characters.";
    }elseif(!has_length($custind['INSCN'], ['min' => 2, 'max' => 45])) {
      $errors[] = "Insurace Company Name must be between 2 and 45 characters.";
    }


    // Insurace Policy Number
    if(is_blank($custind['INSPN'])) {
      $errors[] = "Insurace Policy Number cannot be NULL.";
    } elseif(isPartLowercase($custind['INSPN'])){
      $errors[] = "Insurace Policy Number '" . h($custind['INSPN']) . "' cannot contain lowercase letters.";
    }elseif(has_special_charac($custind['INSPN'])){
      $errors[] = "Insurace Policy Number cannot contain special characters.";
    }elseif(!has_length($custind['INSPN'], ['min' => 2, 'max' => 20])) {
      $errors[] = "Insurace Policy Number must be between 2 and 20 characters.";
    }

    return $errors;
  }


  
  function insert_custind($custind) {
    global $db;

    $errors = validate_custind($custind);
    if(!empty($errors)) {
      return $errors;
    }

    $cust_id = db_escape($db, $custind['cust_id']);
    $DLN = db_escape($db, $custind['DLN']);
    $INSCN = db_escape($db, $custind['INSCN']);
    $INSPN = db_escape($db, $custind['INSPN']);

    $sql = "INSERT INTO MQ_CUSTIND (cust_id, DLN, INSCN, INSPN) VALUES ('$cust_id', '$DLN' , '$INSCN', '$INSPN')";
    
    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  function update_custind($custind) {
    global $db;

    $errors = validate_custind($custind);
    if(!empty($errors)) {
      return $errors;
    }

    $sql = "UPDATE MQ_CUSTIND SET ";
    $sql .= "DLN='" . db_escape($db, $custind['DLN']) . "', ";
    $sql .= "INSCN='" . db_escape($db, $custind['INSCN']) . "', ";
    $sql .= "INSPN='" . db_escape($db, $custind['INSPN']) . "' ";
    $sql .= "WHERE cust_id='" . db_escape($db, $custind['cust_id']) . "' ";
    $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  function delete_custind($id) {
    global $db;

    $sql = "DELETE FROM MQ_CUSTIND ";
    $sql .= "WHERE cust_id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }



  //Corporations
  function find_all_custcors() {
    global $db;

    $sql = "SELECT * FROM MQ_CUSTCOR ";
    $sql .= "ORDER BY cust_id ASC";
    $result = mysqli_query($db, $sql);
    return $result;
  }
  function find_custcor_by_id($id) {
    global $db;

    $sql = "SELECT * FROM MQ_CUSTCOR ";
    $sql .= "WHERE cust_id='" . db_escape($db, $id) . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $custcor = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $custcor; 
  }

  //Used in customer show
  function find_custcor_by_custid($id) {
    global $db;

    $sql = "SELECT * FROM MQ_CUSTCOR ";
    $sql .= "WHERE cust_id='" . db_escape($db, $id) . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    //$count = mysqli_num_rows($result);
    //$custcor = mysqli_fetch_assoc($result);
    //mysqli_free_result($result);
    return $result; 
  }

  function validate_custcor($custcor) {
    $errors = [];

    //Customer ID
    if(is_blank($custcor['cust_id'])) {
      $errors[] = "Please enter customer ID.";
    }

    // Corporation Name
    if(is_blank($custcor['corp_name'])) {
      $errors[] = "Corporation Name cannot be blank.";
    }elseif(has_special_charac($custcor['corp_name'])){
      $errors[] = "Corporation Name cannot contain special characters.";
    }elseif(!has_length($custcor['corp_name'], ['min' => 2, 'max' => 45])) {
      $errors[] = "Corporation Name must be between 2 and 45 characters.";
    }


    //Register Number
    if(is_blank($custcor['register_no'])) {
      $errors[] = "Registration Number cannot be NULL.";
    }elseif(has_special_charac($custcor['register_no'])){
      $errors[] = "Registration Number cannot contain special characters.";
    }elseif(isPartLowercase($custcor['register_no'])){
      $errors[] = "Registration Number '" . h($custcor['register_no']) . "' cannot contain lowercase letters.";
    }elseif(!has_length($custcor['register_no'], ['min' => 5, 'max' => 20])) {
      $errors[] = "Registration Number must be between 6 and 20 characters.";
    }
   

    //Employee ID
    /*$empid_int = (int) $custcor['emp_id'];
    if(is_blank($custcor['emp_id'])) {
      $errors[] = "Employee ID cannot be blank.";
    }
    if($empid_int <= 0) {
      $errors[] = "Employee ID must be greater than zero.";
    } */
    if(is_blank($custcor['emp_id'])) {
      $errors[] = "Employee ID cannot be NULL.";
    }elseif(!has_length($custcor['emp_id'], ['min' => 1, 'max' => 12])) {
      $errors[] = "Employee ID must be between 1 and 16 numbers.";
    }


    return $errors;

  }



  function insert_custcor($custcor) {
    global $db;

    $errors = validate_custcor($custcor);
    if(!empty($errors)) {
      return $errors;
    }

    $cust_id = db_escape($db, $custcor['cust_id']);
    $corp_name = db_escape($db, $custcor['corp_name']);
    $regis_no = db_escape($db, $custcor['register_no']);
    $emp_id = db_escape($db, $custcor['emp_id']);

    $sql = "INSERT INTO MQ_CUSTCOR (cust_id, corp_name, register_no, emp_id) VALUES ('$cust_id', '$corp_name' , '$regis_no',  '$emp_id')";

    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  } 
  function update_custcor($custcor) {
    global $db;

    $errors = validate_custcor($custcor);
    if(!empty($errors)) {
      return $errors;
    }

    $sql = "UPDATE MQ_CUSTCOR SET ";
    $sql .= "corp_name='" . db_escape($db, $custcor['corp_name']) . "', ";
    $sql .= "register_no='" . db_escape($db, $custcor['register_no']) . "', ";
    $sql .= "emp_id='" . db_escape($db, $custcor['emp_id']) . "' ";
    $sql .= "WHERE cust_id='" . db_escape($db, $custcor['cust_id']) . "' ";
    $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  function delete_custcor($id) {
    global $db;

    $sql = "DELETE FROM MQ_CUSTCOR ";
    $sql .= "WHERE cust_id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }



  //Coupons
  function find_all_coupons() {
    global $db;

    $sql = "SELECT * FROM MQ_COUPON ";
    $sql .= "ORDER BY coupon_no ASC";
    $result = mysqli_query($db, $sql);
    return $result;
  }

  function find_coupon_by_id($id) {
    global $db;

    $sql = "SELECT * FROM MQ_COUPON ";
    $sql .= "WHERE coupon_no='" . db_escape($db, $id) . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $coupon = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $coupon; 
  }

  function validate_coupon($coupon) {
    $errors = [];

    //Coupon Type
    if(is_blank($coupon['coup_type'])) {
      $errors[] = "Please select one coupon type.";
    }

    // Discount
    if(is_blank($coupon['discount'])) {
      $errors[] = "Discount cannot be blank.";
    } elseif($coupon['discount']<0) {
      $errors[] = "Discount cannot be negative!";
    } elseif($coupon['discount']>100){
      $errors[] = "Discount cannot go beyond 100%!";
    }

    //Vaild date from
    if(is_blank($coupon['sta_date'])) {
      $errors[] = "Start validation date cannot be NULL.";
    }
    
    //Valid date to
    //How to implement date difference in dates?
    if(is_blank($coupon['exp_date'])) {
      $errors[] = "Expiration date cannot be NULL.";
    } elseif($coupon['exp_date']< $coupon['sta_date']) {
      $errors[] = "Expiration date must be larger than start validation date.";
    } /*elseif(round(($coupon['exp_date'] - $coupon['sta_date'])/ (60 * 60 * 24)) < 90){
      $errors[] = "Expiration date must be at least 3 months larger than start validation date.";
    }*/

    //Customer ID
    if(is_blank($coupon['cust_id'])) {
      $errors[] = "Customer ID cannot be blank.";
    } /*elseif(!has_length($coupon['cust_id'], ['min' => 2, 'max' => 45])) {
      $errors[] = "Customer ID must be between 2 and 45 characters.";
    }*/

    return $errors;
  }


  function insert_coupon($coupon) {
    global $db;

    $errors = validate_coupon($coupon);
    if(!empty($errors)) {
      return $errors;
    }

    $coup_type = db_escape($db, $coupon['coup_type']);
    $discount = db_escape($db, $coupon['discount']);
    $sta_date = db_escape($db, $coupon['sta_date']);
    $exp_date = db_escape($db, $coupon['exp_date']);
    //$usedate = $coupon['usedate'];
    $cust_id = db_escape($db, $coupon['cust_id']);

    $sql = "INSERT INTO MQ_COUPON ( coup_type, discount, sta_date, exp_date, cust_id) VALUES 
    ('$coup_type', '$discount', '$sta_date', '$exp_date', '$cust_id' )";

    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function update_coupon($coupon) {
    global $db;

    $errors = validate_coupon($coupon);
    if(!empty($errors)) {
      return $errors;
    }

    $sql = "UPDATE MQ_COUPON SET ";
    $sql .= "coup_type='" . db_escape($db, $coupon['coup_type']) . "', ";
    $sql .= "discount='" . db_escape($db, $coupon['discount']) . "', ";
    $sql .= "sta_date='" . db_escape($db, $coupon['sta_date']). "', ";
    $sql .= "exp_date='" . db_escape($db, $coupon['exp_date']) . "', ";
    //$sql .= "usedate='" . $coupon['usedate'] . "', ";
    $sql .= "cust_id='" . db_escape($db, $coupon['cust_id']) . "' ";
    $sql .= "WHERE coupon_no='" . db_escape($db, $coupon['coupon_no']) . "' ";
    $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function delete_coupon($id) {
    global $db;

    $sql = "DELETE FROM MQ_COUPON ";
    $sql .= "WHERE coupon_no='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }



  //Offices
  function find_all_offices() {
    global $db;

    $sql = "SELECT * FROM MQ_OFFLOC ";
    $sql .= "ORDER BY loc_id ASC";
    //echo $sql;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }
  function find_office_by_id($id) {
    global $db;

    $sql = "SELECT * FROM MQ_OFFLOC ";
    $sql .= "WHERE loc_id='" . db_escape($db, $id) . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $office = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $office; 
  }

  function validate_office($office) {
    $errors = [];

    //Located State
    if(is_blank($office['loc_state'])) {
      $errors[] = "State cannot be blank.";
    } elseif(has_special_charac($office['loc_state'])){
      $errors[] = "State cannot contain special characters.";
    }elseif(!has_length($office['loc_state'], ['min' => 2, 'max' => 30])) {
      $errors[] = "State must be between 2 and 30 characters.";
    }
    

    //Located City
    if(is_blank($office['loc_city'])) {
      $errors[] = "City cannot be blank.";
    } elseif(has_special_charac($office['loc_city'])){
      $errors[] = "City cannot contain special characters.";
    }elseif(!has_length($office['loc_city'], ['min' => 2, 'max' => 30])) {
      $errors[] = "City must be between 2 and 30 characters.";
    }
    

    //Located Street
    if(is_blank($office['loc_st'])) {
      $errors[] = "Street cannot be blank.";
    } elseif(has_special_charac($office['loc_st'])){
      $errors[] = "Street cannot contain special characters.";
    }elseif(!has_length($office['loc_st'], ['min' => 2, 'max' => 45])) {
      $errors[] = "Street must be between 2 and 45 characters.";
    }
    

    // floor
    if(!is_blank($office['floor'])){
      /*if(!is_numeric($office['floor'])) {
        $errors[] = "Floor must be numeric.";
        $floor_int = (int) $office['floor'];
      }if($office['floor'] <= 0) {
        $errors[] = "Floor must be greater than zero.";
      }elseif($office['floor'] > 70) {
        $errors[] = "Floor cannot be greater than 70.";
      }*/
  }

    // Zipcode  
    if(is_blank($office['loc_zipcode'])) {
      $errors[] = "Zipcode cannot be blank.";
    }/*elseif(!is_int($office['loc_zipcode'])){
      $errors[] = "Zipcode must be integer.";
      $zipcode_int = (int) $office['loc_zipcode'];
    }elseif($zipcode_int <= 0) {
      $errors[] = "Zipcode must be greater than zero.";
    }*/elseif(!has_length_exactly($office['loc_zipcode'], 5)) {
      $errors[] = "Zipcode must be exactly 5 characters.";
    }

    //Phone
    if(is_blank($office['loc_phone'])) {
      $errors[] = "Phone cannot be blank.";
    } elseif(!has_valid_phone_format($office['loc_phone'])) {
      $errors[] = "Please enter valid phone format 'xxx-xxx-xxxx'. ";
    }

    return $errors;
  }


  function insert_office($office) {
    global $db;

    $errors = validate_office($office);
    if(!empty($errors)) {
      return $errors;
    }

    $state = db_escape($db, $office['loc_state']);
    $city = db_escape($db, $office['loc_city']);
    $street = db_escape($db, $office['loc_st']);
    $floor = db_escape($db, $office['floor']) ??'';
    $zipcode = db_escape($db, $office['loc_zipcode']);
    $phone = db_escape($db, $office['loc_phone']);
    if($floor === ''){
      $sql = "INSERT INTO MQ_OFFLOC (loc_state, loc_city, loc_st, floor, loc_zipcode, loc_phone) VALUES 
    ('$state' , '$city', '$street', 'NULL' , '$zipcode', '$phone')";
    }else{
      $sql = "INSERT INTO MQ_OFFLOC (loc_state, loc_city, loc_st, floor, loc_zipcode, loc_phone) VALUES 
    ('$state' , '$city', '$street', '$floor', '$zipcode', '$phone')";

    }
    
    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  function update_office($office) {
    global $db;

    $errors = validate_office($office);
    if(!empty($errors)) {
      return $errors;
    }

    $sql = "UPDATE MQ_OFFLOC SET ";
    $sql .= "loc_state='" . db_escape($db, $office['loc_state']) . "', ";
    $sql .= "loc_city='" . db_escape($db, $office['loc_city']) . "', ";
    $sql .= "loc_st='" . db_escape($db, $office['loc_st']) . "', ";
    if($office['floor']=''){
      $sql .= "floor='" . NULL . "', ";
    }else{
      $sql .= "floor='" . db_escape($db, $office['floor']) . "', ";
    }
    $sql .= "loc_zipcode='" . db_escape($db, $office['loc_zipcode']) . "', ";
    $sql .= "loc_phone='" . db_escape($db, $office['loc_phone']) . "' ";
    $sql .= "WHERE loc_id='" . db_escape($db, $office['loc_id']) . "' ";
    $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  function delete_office($id) {
    global $db;

    $sql = "DELETE FROM MQ_OFFLOC ";
    $sql .= "WHERE loc_id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  //Vehicle Classes
  function find_all_vclasses() {
    global $db;

    $sql = "SELECT * FROM MQ_VCLASS ";
    $sql .= "ORDER BY vclass_id ASC";
    $result = mysqli_query($db, $sql);
    return $result;
  }
  function find_vclass_by_id($id) {
    global $db;

    $sql = "SELECT * FROM MQ_VCLASS ";
    $sql .= "WHERE vclass_id='" . db_escape($db, $id) . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $vclass = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $vclass; 
  }


  function validate_vclass($vclass) {
    $errors = [];

    //Vehicle type name
    if(is_blank($vclass['vc_name'])) {
      $errors[] = "Vehicle type name cannot be blank.";
    }elseif(is_numeric($vclass['vc_name'])){
      $errors[] = "Vehicle type name cannot be numeric!";
    }elseif(has_special_charac($vclass['vc_name'])){
      $errors[] = "Vehicle type name cannot contain special characters.";
    }elseif(isPartLowercase($vclass['vc_name'])){
      $errors[] = "Vehicle type name '" . h($vclass['vc_name']) . "' cannot contain lowercase letters.";
    }elseif(!has_length($vclass['vc_name'], ['min' => 2, 'max' => 20])) {
      $errors[] = "Vehicle type name must be between 2 and 20 characters.";
    }
    
    
    // Rent charge
    if(is_blank($vclass['rent_charge'])) {
      $errors[] = "Rent charge cannot be blank.";
    } elseif($vclass['rent_charge']<=0) {
      $errors[] = "Rent charge must be positive.";
    } else if($vclass['rent_charge'] > 9999){
      $errors[] = "Rent charge cannot go beyond 9999 $. ";
    }

    // Extra charge
    if(is_blank($vclass['rent_charge'])) {
      $errors[] = "Extra charge cannot be blank.";
    } elseif($vclass['rent_charge']<0) {
      $errors[] = "Extra charge cannot be negative.";
    } else if($vclass['rent_charge'] > 999){
      $errors[] = "Rent charge cannot go beyond 999 $. ";
    }

    return $errors;

  }

  function insert_vclass($vclass) {
    global $db;

    $errors = validate_vclass($vclass);
    if(!empty($errors)) {
      return $errors;
    }

    $vc_name = db_escape($db, $vclass['vc_name']);
    $rent_charge = db_escape($db, $vclass['rent_charge']);
    $extra_charge = $db_escape($db, vclass['extra_charge']);
    
    $sql = "INSERT INTO MQ_VCLASS (vc_name, rent_charge, extra_charge) VALUES 
    ('$vc_name' , '$rent_charge', '$extra_charge')";

    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  function update_vclass($vclass) {
    global $db;

    $errors = validate_vclass($vclass);
    if(!empty($errors)) {
      return $errors;
    }

    $sql = "UPDATE MQ_VCLASS SET ";
    $sql .= "vc_name='" . db_escape($db, $vclass['vc_name']) . "', ";
    $sql .= "rent_charge='" . db_escape($db, $vclass['rent_charge']) . "', ";
    $sql .= "extra_charge='" . db_escape($db, $vclass['extra_charge']) . "' ";
    $sql .= "WHERE vclass_id='" . db_escape($db, $vclass['vclass_id']) . "' ";
    $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  function delete_vclass($id) {
    global $db;

    $sql = "DELETE FROM MQ_VCLASS ";
    $sql .= "WHERE vclass_id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }


  //Vehicles
  function find_all_vehicles() {
    global $db;

    $sql = "SELECT * FROM MQ_VEH ";
    $sql .= "ORDER BY veh_id ASC";
    $result = mysqli_query($db, $sql);
    return $result;
  }
  function find_vehicle_by_id($id) {
    global $db;

    $sql = "SELECT * FROM MQ_VEH ";
    $sql .= "WHERE veh_id='" . db_escape($db, $id) . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $vehicle = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $vehicle; 
  }

  function validate_vehicle($vehicle) {
    $errors = [];

    //Vehicle Make
    if(is_blank($vehicle['make'])) {
      $errors[] = "Vehicle Make cannot be blank.";
    }elseif(is_numeric($vehicle['make'])){
      $errors[] = "Vehicle Make cannot be numeric!";
    }elseif(has_special_charac($vehicle['make'])){
      $errors[] = "Vehicle Make cannot contain special characters.";
    }elseif(isPartLowercase($vehicle['make'])){
      $errors[] = "Vehicle Make '" . h($vehicle['make']) . "' cannot contain lowercase letters.";
    }elseif(!has_length($vehicle['make'], ['min' => 1, 'max' => 30])) {
      $errors[] = "Vehicle Make must be between 2 and 30 characters.";
    }
    
    

    //Vehicle Model
    if(is_blank($vehicle['model'])) {
      $errors[] = "Vehicle Model cannot be blank.";
    }elseif(is_numeric($vehicle['model'])){
      $errors[] = "Vehicle Model cannot be numeric!";
    }elseif(has_special_charac($vehicle['model'])){
      $errors[] = "Vehicle Model cannot contain special characters.";
    }elseif(isPartLowercase($vehicle['model'])){
      $errors[] = "Vehicle Model name '" . h($vehicle['model']) . "' cannot contain lowercase letters.";
    }elseif(!has_length($vehicle['model'], ['min' => 2, 'max' => 30])) {
      $errors[] = "Vehicle Model must be between 3 and 30 characters.";
    }
    


    //
    //Vehicle Identity Number
    if(is_blank($vehicle['VIN'])) {
      $errors[] = "Vehicle Identity Number cannot be blank.";
    }elseif(has_special_charac($vehicle['VIN'])){
      $errors[] = "Vehicle Identity Number cannot contain special characters.";
    }elseif(isPartLowercase($vehicle['VIN'])){
      $errors[] = "Vehicle Identity Number '" . h($vehicle['VIN']) . "' cannot contain lowercase letters.";
    }elseif(!has_length($vehicle['VIN'], ['min' => 4, 'max' => 20])) {
      $errors[] = "Vehicle Identity Number must be between 5 and 20 characters.";
    }
     

    //License Plate No.
    if(is_blank($vehicle['LPN'])) {
      $errors[] = "License Plate No. cannot be blank.";
    }elseif(has_special_charac($vehicle['LPN'])){
      $errors[] = "License Plate No. cannot contain special characters.";
    }elseif(isPartLowercase($vehicle['LPN'])){
      $errors[] = "License Plate No. '" . h($vehicle['LPN']) . "' cannot contain lowercase letters.";
    }elseif(!has_length($vehicle['LPN'], ['min' => 4, 'max' => 15])) {
      $errors[] = "License Plate No. must be between 5 and 15 characters.";
    }

    //Vehicle Class ID
    if(is_blank($vehicle['vclass_id'])) {
      $errors[] = "Vehicle Class ID cannot be blank.";
    } 

    //Office Location ID
    if(is_blank($vehicle['loc_id'])) {
      $errors[] = "Office Location ID cannot be blank.";
    } 

    return $errors;
  }


  function insert_vehicle($vehicle) {
    global $db;

    $errors = validate_vehicle($vehicle);
    if(!empty($errors)) {
      return $errors;
    }

    $make = db_escape($db, $vehicle['make']);
    $model = db_escape($db, $vehicle['model']);
    $year = db_escape($db, $vehicle['vyear']);
    $VIN = db_escape($db, $vehicle['VIN']);
    $LPN = db_escape($db, $vehicle['LPN']);
    $vclass_id = db_escape($db, $vehicle['vclass_id']);
    $loc_id = db_escape($db, $vehicle['loc_id']);


    $sql = "INSERT INTO MQ_VEH (make, model, vyear, VIN, LPN, vclass_id, loc_id) VALUES 
    ('$make','$model','$year', '$VIN', '$LPN', '$vclass_id', '$loc_id')";

    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  function update_vehicle($vehicle) {
    global $db;

    $errors = validate_vehicle($vehicle);
    if(!empty($errors)) {
      return $errors;
    }

    $sql = "UPDATE MQ_VEH SET ";
    $sql .= "make='" . db_escape($db, $vehicle['make']) . "', ";
    $sql .= "model='" . db_escape($db, $vehicle['model']) . "', ";
    $sql .= "vyear='" . db_escape($db, $vehicle['vyear']) . "', ";
    $sql .= "VIN='" . db_escape($db, $vehicle['VIN']) . "', ";
    $sql .= "LPN='" . db_escape($db, $vehicle['LPN']) . "', ";
    $sql .= "vclass_id='" . db_escape($db, $vehicle['vclass_id']) . "', ";
    $sql .= "loc_id='" . db_escape($db, $vehicle['loc_id']) . "' ";
    $sql .= "WHERE veh_id='" . db_escape($db, $vehicle['veh_id']) . "' ";
    $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  function delete_vehicle($id) {
    global $db;

    $sql = "DELETE FROM MQ_VEH ";
    $sql .= "WHERE veh_id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }



  //Services
  function find_all_services() {
    global $db;

    $sql = "SELECT * FROM MQ_SERV ";
    $sql .= "ORDER BY serv_no ASC";
    $result = mysqli_query($db, $sql);
    return $result;
  }
  function find_service_by_id($id) {
    global $db;
    

    $sql = "SELECT * FROM MQ_SERV ";
    $sql .= "WHERE serv_no='" . db_escape($db, $id) . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $service = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $service; // returns an assoc. array
  }

  function validate_service($service) {
    $errors = [];

    //Pickup Date
    if(is_blank($service['pickup_date'])) {
      $errors[] = "Pickup date cannot be blank.";
    }elseif($service['pickup_date']<$service['sche_time']){
      $errors[] = "Pickup date cannot be earlier than service scheduled date.";
    }

    //Dropoff date
    if(is_blank($service['droff_date'])) {
      $errors[] = "Dropoff date  cannot be blank.";
    } elseif($service['droff_date']<$service['pickup_date']) {
      $errors[] = "Dropoff date cannot be earlier than pickup date.";
    }

    // Start odometer
    if(is_blank($service['sta_odo'])) {
      $errors[] = "Start odometer cannot be blank.";
    }

    // End odometer
    if(is_blank($service['end_odo'])) {
      $errors[] = "End odometer cannot be blank.";
    }else if($service['end_odo']<$service['sta_odo']){
      $errors[] = "End odometer cannot be smaller than start odometer.";
    }

    // Daily odolimit
    if(is_blank($service['odolimit'])) {
      $errors[] = "Daily odolimit cannot be blank.";
    }

    //Pickup Location
    if(is_blank($service['pickup_loc'])) {
      $errors[] = "Pickup Location cannot be blank.";
    }

    //Dropoff Location
    if(is_blank($service['droff_loc'])) {
      $errors[] = "Dropoff Location cannot be blank.";
    }elseif($service['droff_loc']==$service['pickup_loc']){
      $errors[] = "Dropoff Location must be different with pickup location!";
    }
    
    //Vehicle ID
    if(is_blank($service['veh_id'])) {
      $errors[] = "Vehicle ID cannot be blank.";
    }

    //Customer ID
    if(is_blank($service['cust_id'])) {
      $errors[] = "Customer ID cannot be blank.";
    }

    //Invoice Number
    if(is_blank($service['invno'])) {
      $errors[] = "Invoice Number cannot be blank.";
    }


    //Coupon Number
    if(!is_blank($service['coupon_no'])){
      if(!is_numeric($service['coupon_no'])) {
        $errors[] = "Coupon Number must be integer.";
        $coupon_int = (int) $service['coupon_no'];
      }elseif($service['coupon_no'] < 1) {
        $errors[] = "Coupon Number  be greater than 1.";
      }elseif($service['coupon_no'] > 99999999999) {
        $errors[] = "Coupon Number cannot be outrange than 99,999,999,999.";
      }
    }

    return $errors;
  }

 

  function insert_service($service) {
    global $db;

    $errors = validate_service($service);
    if(!empty($errors)) {
      return $errors;
    }

    $sche_time = db_escape($db, $service['sche_time']);
    $pickup_date = db_escape($db, $service['pickup_date']);
    $droff_date = db_escape($db, $service['droff_date']);
    $sta_odo = db_escape($db, $service['sta_odo']);
    $end_odo = db_escape($db, $service['end_odo']);
    $odolimit = db_escape($db, $service['odolimit']);
    $pickup_loc = db_escape($db, $service['pickup_loc']);
    $droff_loc = db_escape($db, $service['droff_loc']);
    $veh_id = db_escape($db, $service['veh_id']);
    $cust_id = db_escape($db, $service['cust_id']);
    $invno = db_escape($db, $service['invno']);
    $coupon_no = db_escape($db, $service['coupon_no'])=='' ? NULL : h($service['coupon_no']);
    
    $sql = "INSERT INTO MQ_SERV (sche_time, pickup_date, droff_date, sta_odo, end_odo, odolimit, pickup_loc, droff_loc, veh_id, cust_id, invno, coupon_no) VALUES 
    ('$sche_time', '$pickup_date', '$droff_date', '$sta_odo', '$end_odo', '$odolimit', '$pickup_loc', '$droff_loc', '$veh_id', '$cust_id', '$invno', '$coupon_no')";
    
    

    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  function update_service($service) {
    global $db;

    $errors = validate_service($service);
    if(!empty($errors)) {
      return $errors;
    }

    $sql = "UPDATE MQ_SERV SET ";
    $sql .= "serv_no='" . db_escape($db, $service['serv_no']) . "', ";
    $sql .= "sche_time='" . db_escape($db, $service['sche_time']) . "', ";
    $sql .= "pickup_date='" . db_escape($db, $service['pickup_date']) . "', ";
    $sql .= "droff_date='" . db_escape($db, $service['droff_date']) . "', ";
    $sql .= "sta_odo='" . db_escape($db, $service['sta_odo']) . "', ";
    $sql .= "end_odo='" . db_escape($db, $service['end_odo']) . "', ";
    $sql .= "odolimit='" . db_escape($db, $service['odolimit']) . "', ";
    $sql .= "pickup_loc='" . db_escape($db, $service['pickup_loc']) . "', ";
    $sql .= "droff_loc='" . db_escape($db, $service['droff_loc']) . "', ";
    $sql .= "veh_id='" . db_escape($db, $service['veh_id']) . "', ";
    $sql .= "cust_id='" . db_escape($db, $service['cust_id']) . "', ";
    $sql .= "invno='" . db_escape($db, $service['invno']) . "', ";
    $sql .= "coupon_no='" . db_escape($db, $service['coupon_no']) . "' ";
    $sql .= "WHERE serv_no='" . db_escape($db, $service['serv_no']) . "' ";
    $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  function delete_service($id) {
    global $db;

    $sql = "DELETE FROM MQ_SERV ";
    $sql .= "WHERE serv_no='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }


  function last_inserted_service() {
    global $db;

    $sql = "SELECT * FROM MQ_SERV ORDER BY serv_no DESC LIMIT 1 ";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $service = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $service; // returns an assoc. array
    
  }



  //Invoices
  function find_all_invoices() {
    global $db;

    $sql = "SELECT * FROM MQ_INV ";
    $sql .= "ORDER BY invno ASC";
    $result = mysqli_query($db, $sql);
    return $result;
  } 
  function find_invoice_by_id($id) {
    global $db;

    $sql = "SELECT * FROM MQ_INV ";
    $sql .= "WHERE invno='" . db_escape($db, $id) . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $invoice = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $invoice; 
  }

  function validate_invoice($invoice) {
    $errors = [];

    //Invoice date 
    if(is_blank($invoice['inv_date'])) {
      $errors[] = "Invoice date cannot be blank.";
    } 

    //Invoice amount
    if(is_blank($invoice['inv_amount'])) {
      $errors[] = "Invoice amount cannot be blank.";
    } elseif ($invoice['inv_amount']>99999999) {
      $errors[] = "Invoice amount cannot outrange $99,999,999.";

    }

    return $errors;
  }

  function insert_invoice($invoice) {
    global $db;

    $errors = validate_invoice($invoice);
    if(!empty($errors)) {
      return $errors;
    }

    $inv_date = db_escape($db, $invoice['inv_date']);
    $amount = db_escape($db, $invoice['inv_amount']);

    $sql = "INSERT INTO MQ_INV (inv_date, inv_amount) VALUES ('$inv_date', '$amount')";
    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function insert_cust_invoice($invoice) {
    global $db;

    $errors = validate_invoice($invoice);
    if(!empty($errors)) {
      return $errors;
    }
    $invno = db_escape($db, $invoice['invno']);
    $inv_date = db_escape($db, $invoice['inv_date']);
    $amount = db_escape($db, $invoice['inv_amount']);

    $sql = "INSERT INTO MQ_INV (invno, inv_date, inv_amount) VALUES ('$invno', '$inv_date', '$amount')";
    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }    
  function update_invoice($invoice) {
    global $db;

    $errors = validate_invoice($invoice);
    if(!empty($errors)) {
      return $errors;
    }

    $sql = "UPDATE MQ_INV SET ";
    $sql .= "inv_date='" . db_escape($db, $invoice['inv_date']) . "', ";
    $sql .= "inv_amount='" . db_escape($db, $invoice['inv_amount']) . "' ";
    $sql .= "WHERE invno='" . db_escape($db, $invoice['invno']) . "' ";
    $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  
  function delete_invoice($id) {
    global $db;

    $sql = "DELETE FROM MQ_INV ";
    $sql .= "WHERE invno='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }


  //Payments
  function find_all_payments() {
    global $db;

    $sql = "SELECT * FROM MQ_PAY";
    $sql .= " ORDER BY payno ASC";
    $result = mysqli_query($db, $sql);
    return $result;
  }
  function find_payment_by_id($id) {
    global $db;

    $sql = "SELECT * FROM MQ_PAY ";
    $sql .= "WHERE payno='" . $id . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $payment = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $payment; 
  }

  function validate_payment($payment) {
    $errors = [];

    //Card Number
    if(is_blank($payment['card_no'])) {
      $errors[] = "Card Number cannot be blank.";
    } elseif(($payment['method'] != 'G')){
      if(!has_length($payment['card_no'], ['min' => 11, 'max' => 19])) {
      $errors[] = "Credit card & Debit card number must have 12～19 digits.";
      } 
    }/*if(($payment['method'] == 'G')) {
      if(!has_exact_length($payment['card_no'], 9){
      $errors[] = "Gift card number must have 9 digits.";
    }
    
    }
    */

    //Paymethod
    if(is_blank($payment['method'])) {
      $errors[] = "Please select one payment method.";
    } 

    //Customer ID
    if(is_blank($payment['cust_id'])) {
      $errors[] = "Customer ID of card holder cannot be blank.";
    } 

    return $errors;

  }


  function insert_payment($payment) {
    global $db;

    $errors = validate_payment($payment);
    if(!empty($errors)) {
      return $errors;
    }

    $card_no = db_escape($db, $payment['card_no']);
    $method = db_escape($db, $payment['method']);
    $cust_id = db_escape($db, $payment['cust_id']);

    $sql = "INSERT INTO MQ_PAY (card_no, method, cust_id) VALUES ('$card_no', '$method', '$cust_id')";

    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  function update_payment($payment) {
    global $db;

    $errors = validate_payment($payment);
    if(!empty($errors)) {
      return $errors;
    }

    $sql = "UPDATE MQ_PAY SET ";
    $sql .= "card_no='" . db_escape($db, $payment['card_no']) . "', ";
    $sql .= "method='" . db_escape($db, $payment['method']) . "', ";
    $sql .= "cust_id='" . db_escape($db, $payment['cust_id']) . "' ";
    $sql .= "WHERE payno='" . db_escape($db, $payment['payno']) . "' ";
    $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  function delete_payment($id) {
    global $db;

    $sql = "DELETE FROM MQ_PAY ";
    $sql .= "WHERE payno='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }




  //Invpays
  function find_all_invpays() {
    global $db;

    $sql = "SELECT * FROM MQ_INVPAY";
    $sql .= " ORDER BY txn_id ASC";
    $result = mysqli_query($db, $sql);
    return $result;
  }
  function find_invpay_by_id($id) {
    global $db;

    $sql = "SELECT * FROM MQ_INVPAY ";
    $sql .= "WHERE txn_id='" . db_escape($db, $id) . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $invpay = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $invpay; 
  }

  function validate_invpay($invpay) {
    $errors = [];

    //Invoice Number
    if(is_blank($invpay['invno'])) {
      $errors[] = "Invoice number cannot be blank.";
    }

    //Payment Number
    if(is_blank($invpay['payno'])) {
      $errors[] = "Payment Number cannot be blank.";
    }
    
    //Transaction Date
    if(is_blank($invpay['pay_date'])) {
      $errors[] = "Transaction date cannot be blank.";
    } 

    //Transaction amount
    if(is_blank($invpay['pay_amount'])) {
      $errors[] = "Transaction amount cannot be blank.";
    } elseif($invpay['pay_amount'] > 99999999) {
      $errors[] = "Transaction amount cannot outrange $99,999,999.";
    }

    //Payment Status
    if(is_blank($invpay['pay_status'])) {
      $errors[] = "Please select one payment status.";
    } 

    return $errors;
  }



  function insert_invpay($invpay) {
    global $db;

    $errors = validate_invpay($invpay);
    if(!empty($errors)) {
      return $errors;
    }

    $invno = db_escape($db, $invpay['invno']);
    $payno = db_escape($db, $invpay['payno']);
    $pay_date = db_escape($db, $invpay['pay_date']);
    $pay_amount = db_escape($db, $invpay['pay_amount']);
    $pay_status = db_escape($db, $invpay['pay_status']);

    $sql = "INSERT INTO MQ_INVPAY (invno, payno, pay_date, pay_amount, pay_status) VALUES 
    ('$invno', '$payno', '$pay_date', '$pay_amount', '$pay_status')";

    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  function update_invpay($invpay) {
    global $db;

    $errors = validate_invpay($invpay);
    if(!empty($errors)) {
      return $errors;
    }

    $sql = "UPDATE MQ_INVPAY SET ";
    $sql .= "invno='" . db_escape($db, $invpay['invno']) . "', ";
    $sql .= "payno='" . db_escape($db, $invpay['payno']) . "', ";
    $sql .= "pay_date='" .db_escape($db,  $invpay['pay_date']) . "', ";
    $sql .= "pay_amount='" . db_escape($db, $invpay['pay_amount']) . "', ";
    $sql .= "pay_status='" . db_escape($db, $invpay['pay_status']) . "' ";
    $sql .= "WHERE txn_id='" . db_escape($db, $invpay['txn_id']) . "' ";
    $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  function delete_invpay($id) {
    global $db;

    $sql = "DELETE FROM MQ_INVPAY ";
    $sql .= "WHERE txn_id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }



  //staff_admins

  // Find all admins, ordered last_name, first_name
  function find_all_admins() {
    global $db;

    $sql = "SELECT * FROM staff_admins ";
    $sql .= "ORDER BY last_name ASC, first_name ASC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

  function find_admin_by_id($id) {
    global $db;

    $sql = "SELECT * FROM staff_admins ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $admin = mysqli_fetch_assoc($result); // find first
    mysqli_free_result($result);
    return $admin; // returns an assoc. array
  }

  function find_admin_by_username($username) {
    global $db;

    $sql = "SELECT * FROM staff_admins ";
    $sql .= "WHERE username='" . db_escape($db, $username) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $admin = mysqli_fetch_assoc($result); // find first
    mysqli_free_result($result);
    return $admin; // returns an assoc. array
  }

  function validate_admin($admin, $options=[]) {

    $password_required = $options['password_required'] ?? true;

    if(is_blank($admin['first_name'])) {
      $errors[] = "First name cannot be blank.";
    } elseif (!has_length($admin['first_name'], array('min' => 2, 'max' => 255))) {
      $errors[] = "First name must be between 2 and 255 characters.";
    }

    if(is_blank($admin['last_name'])) {
      $errors[] = "Last name cannot be blank.";
    } elseif (!has_length($admin['last_name'], array('min' => 2, 'max' => 255))) {
      $errors[] = "Last name must be between 2 and 255 characters.";
    }

    if(is_blank($admin['email'])) {
      $errors[] = "Email cannot be blank.";
    } elseif (!has_length($admin['email'], array('max' => 255))) {
      $errors[] = "Last name must be less than 255 characters.";
    } elseif (!has_valid_email_format($admin['email'])) {
      $errors[] = "Email must be a valid format.";
    }

    if(is_blank($admin['username'])) {
      $errors[] = "Username cannot be blank.";
    } elseif (!has_length($admin['username'], array('min' => 5, 'max' => 255))) {
      $errors[] = "Username must be between 6 and 255 characters.";
    } elseif (!has_unique_staff_username($admin['username'], $admin['id'] ?? 0)) {
      $errors[] = "Username not allowed. Try another.";
    }

    if($password_required) {
      if(is_blank($admin['password'])) {
        $errors[] = "Password cannot be blank.";
      } elseif (!has_length($admin['password'], array('min' => 8))) {
        $errors[] = "Password must contain 8 or more characters";
      } elseif (!preg_match('/[A-Z]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 uppercase letter";
      } elseif (!preg_match('/[a-z]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 lowercase letter";
      } elseif (!preg_match('/[0-9]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 number";
      } 
      /*elseif (!preg_match('/[^A-Za-z0-9\s]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 symbol";
      }*/

      if(is_blank($admin['confirm_password'])) {
        $errors[] = "Confirm password cannot be blank.";
      } elseif ($admin['password'] !== $admin['confirm_password']) {
        $errors[] = "Password and confirm password must match.";
      }
    }
    
    return $errors;
  }

  function insert_admin($admin) {
    global $db;

    $errors = validate_admin($admin);
    if (!empty($errors)) {
      return $errors;
    }

    $hashed_password = password_hash($admin['password'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO staff_admins ";
    $sql .= "(first_name, last_name, email, username, hashed_password) ";
    $sql .= "VALUES (";
    $sql .= "'" . db_escape($db, $admin['first_name']) . "',";
    $sql .= "'" . db_escape($db, $admin['last_name']) . "',";
    $sql .= "'" . db_escape($db, $admin['email']) . "',";
    $sql .= "'" . db_escape($db, $admin['username']) . "',";
    $sql .= "'" . db_escape($db, $hashed_password) . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);

    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function update_admin($admin) {
    global $db;

    $password_sent = !is_blank($admin['password']);

    $errors = validate_admin($admin, ['password_required' => $password_sent]);
    if (!empty($errors)) {
      return $errors;
    }

    $hashed_password = password_hash($admin['password'], PASSWORD_BCRYPT);

    $sql = "UPDATE staff_admins SET ";
    $sql .= "first_name='" . db_escape($db, $admin['first_name']) . "', ";
    $sql .= "last_name='" . db_escape($db, $admin['last_name']) . "', ";
    $sql .= "email='" . db_escape($db, $admin['email']) . "', ";
    if($password_sent) {
      $sql .= "hashed_password='" . db_escape($db, $hashed_password) . "', ";
    }
    $sql .= "username='" . db_escape($db, $admin['username']) . "' ";
    $sql .= "WHERE id='" . db_escape($db, $admin['id']) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function delete_admin($admin) {
    global $db;

    $sql = "DELETE FROM staff_admins ";
    $sql .= "WHERE id='" . db_escape($db, $admin['id']) . "' ";
    $sql .= "LIMIT 1;";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }



  //cust_admins

  // Find all customer admins, ordered last_name, first_name
  function find_all_cust_admins() {
    global $db;

    $sql = "SELECT * FROM cust_admins ";
    $sql .= "ORDER BY last_name ASC, first_name ASC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

  function find_cust_admin_by_id($id) {
    global $db;

    $sql = "SELECT * FROM cust_admins ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $admin = mysqli_fetch_assoc($result); // find first
    mysqli_free_result($result);
    return $admin; // returns an assoc. array
  }

  function find_cust_admin_by_username($username) {
    global $db;

    $sql = "SELECT * FROM cust_admins ";
    $sql .= "WHERE username='" . db_escape($db, $username) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $admin = mysqli_fetch_assoc($result); // find first
    mysqli_free_result($result);
    return $admin; // returns an assoc. array
  }

  function validate_cust_admin($admin, $options=[]) {

    $password_required = $options['password_required'] ?? true;
    
    if(is_blank($admin['first_name'])) {
      $errors[] = "First name cannot be blank.";
    } elseif (!has_length($admin['first_name'], array('min' => 2, 'max' => 255))) {
      $errors[] = "First name must be between 2 and 255 characters.";
    }

    if(is_blank($admin['last_name'])) {
      $errors[] = "Last name cannot be blank.";
    } elseif (!has_length($admin['last_name'], array('min' => 2, 'max' => 255))) {
      $errors[] = "Last name must be between 2 and 255 characters.";
    }

    if(is_blank($admin['email'])) {
      $errors[] = "Email cannot be blank.";
    } elseif (!has_length($admin['email'], array('max' => 255))) {
      $errors[] = "Last name must be less than 255 characters.";
    } elseif (!has_valid_email_format($admin['email'])) {
      $errors[] = "Email must be a valid format.";
    }
   
    if(is_blank($admin['username'])) {
      $errors[] = "Username cannot be blank.";
    } elseif (!has_length($admin['username'], array('min' => 5, 'max' => 255))) {
      $errors[] = "Username must be between 6 and 255 characters.";
    } elseif (!has_unique_cust_username($admin['username'], $admin['id'] ?? 0)) {
      $errors[] = "Username not allowed. Try another.";
    }

    if($password_required) {
      if(is_blank($admin['password'])) {
        $errors[] = "Password cannot be blank.";
      } elseif (!has_length($admin['password'], array('min' => 8))) {
        $errors[] = "Password must contain 8 or more characters";
      } elseif (!preg_match('/[A-Z]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 uppercase letter";
      } elseif (!preg_match('/[a-z]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 lowercase letter";
      } elseif (!preg_match('/[0-9]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 number";
      } 
      /*elseif (!preg_match('/[^A-Za-z0-9\s]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 symbol";
      }*/

      if(is_blank($admin['confirm_password'])) {
        $errors[] = "Confirm password cannot be blank.";
      } elseif ($admin['password'] !== $admin['confirm_password']) {
        $errors[] = "Password and confirm password must match.";
      }
    }
    
    return $errors;
  }

  function insert_cust_admin($admin) {
    global $db;

    $errors = validate_admin($admin);
    if (!empty($errors)) {
      return $errors;
    }

    $hashed_password = password_hash($admin['password'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO cust_admins ";
    $sql .= "(first_name, last_name, email, username, hashed_password) ";
    $sql .= "VALUES (";
    $sql .= "'" . db_escape($db, $admin['first_name']) . "',";
    $sql .= "'" . db_escape($db, $admin['last_name']) . "',";
    $sql .= "'" . db_escape($db, $admin['email']) . "',";
    $sql .= "'" . db_escape($db, $admin['username']) . "',";
    $sql .= "'" . db_escape($db, $hashed_password) . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);

    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function update_cust_admin($admin) {
    global $db;

    $password_sent = !is_blank($admin['password']);

    $errors = validate_admin($admin, ['password_required' => $password_sent]);
    if (!empty($errors)) {
      return $errors;
    }

    $hashed_password = password_hash($admin['password'], PASSWORD_BCRYPT);

    $sql = "UPDATE cust_admins SET ";
    $sql .= "first_name='" . db_escape($db, $admin['first_name']) . "', ";
    $sql .= "last_name='" . db_escape($db, $admin['last_name']) . "', ";
    $sql .= "email='" . db_escape($db, $admin['email']) . "', ";
    if($password_sent) {
      $sql .= "hashed_password='" . db_escape($db, $hashed_password) . "', ";
    }
    $sql .= "username='" . db_escape($db, $admin['username']) . "' ";
    $sql .= "WHERE id='" . db_escape($db, $admin['id']) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function delete_cust_admin($cust_admin) {
    global $db;

    $sql = "DELETE FROM cust_admins ";
    $sql .= "WHERE id='" . db_escape($db, $cust_admin['id']) . "' ";
    $sql .= "LIMIT 1;";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    echo "Delete admin_id= " . $cust_admin['id'];
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  
  function find_customer_by_cust_admin($cust_admin) {
    global $db;

    $fname = db_escape($db, $cust_admin['first_name']);
    $lname = db_escape($db, $cust_admin['last_name']);
    $sql = "SELECT * FROM MQ_CUST WHERE fname = '$fname' AND lname = '$lname' ";

    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $customer = mysqli_fetch_assoc($result); // find first
    mysqli_free_result($result);
    return $customer; // returns an assoc. array
  }

  function find_cust_admin_by_customer($customer) {
    global $db;

    $fname = db_escape($db, $customer['fname']);
    $lname = db_escape($db, $customer['lname']);
    $sql = "SELECT * FROM cust_admins WHERE first_name = '$fname' AND last_name = '$lname' ";

    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $cust_admin = mysqli_fetch_assoc($result); // find first
    mysqli_free_result($result);
    return $cust_admin; // returns an assoc. array
  }


  // sql queries among mutiple tables
  function find_coupons_by_custid($cust_id){
    global $db;

    $sql = "SELECT * FROM MQ_COUPON ";
    $sql .= "WHERE cust_id='" . db_escape($db, $cust_id) . "' ";
  ;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    //$coupon = mysqli_fetch_assoc($result); // find first
    //mysqli_free_result($result);
    return $result; // returns an assoc. array

  }

  function find_payments_by_custid($cust_id){
    global $db;

    $sql = "SELECT * FROM MQ_PAY ";
    $sql .= "WHERE cust_id='" . db_escape($db, $cust_id) . "' ";
    //$sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    //$payment = mysqli_fetch_assoc($result); // find first
    //mysqli_free_result($result);
    return $result; // returns an assoc. array

  }

  function find_all_vehicles_info(){
    global $db;

    $sql = "SELECT a.loc_id, a.loc_state, a.loc_city, b.veh_id, b.make, b.model, b.VIN, b.LPN, c.vc_name, c.rent_charge, c.extra_charge FROM MQ_OFFLOC a join MQ_VEH b on a.loc_id = b.loc_id join MQ_VCLASS c on b.vclass_id = c.vclass_id ORDER BY 1, 4 ";

    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;

  }

  function find_vehicles_by_office_id($loc_id){
    global $db;

    $sql = "SELECT * FROM MQ_VEH ";
    $sql .= "WHERE loc_id='" . db_escape($db, $loc_id) . "' ";
    $sql .= "ORDER BY veh_id ASC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

  function count_vehicles_by_office_id($loc_id){
    global $db;

    $sql = "SELECT COUNT(veh_id) FROM MQ_VEH ";
    $sql .= "WHERE loc_id='" . db_escape($db, $loc_id) . "' ";
    //$sql .= "ORDER BY veh_id ASC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $row = mysqli_fetch_row($result); //return a single array instead of an associated array
    mysqli_free_result($result);
    $count = $row[0];
    return $count;
  }

  function find_vehicles_by_vclass_id($vclass_id){
    global $db;

    $sql = "SELECT * FROM MQ_VEH ";
    $sql .= "WHERE vclass_id='" . db_escape($db, $vclass_id) . "' ";
    $sql .= "ORDER BY veh_id ASC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }


  function count_vehicles_by_vclass_id($vclass_id){
    global $db;

    $sql = "SELECT COUNT(veh_id) FROM MQ_VEH ";
    $sql .= "WHERE vclass_id='" . db_escape($db, $vclass_id) . "' ";
    //$sql .= "ORDER BY veh_id ASC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $row = mysqli_fetch_row($result); //return a single array instead of an associated array
    mysqli_free_result($result);
    $count = $row[0];
    return $count;
  }


  function find_cust_invoices_info_by_id($cust_id){
    global $db;

    $cust_id = db_escape($db, $cust_id);

    $sql = "SELECT a.*, b.txn_id, b.pay_date, b.pay_amount, c.card_no, c.method, b.pay_status 
            FROM MQ_INV a join MQ_INVPAY b on a.invno=b.invno join MQ_PAY c on b.payno=c.payno 
            WHERE c.cust_id = $cust_id ORDER BY a.invno;
             ";

    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;

  }

  function find_services_by_custid($cust_id){
    global $db;

    $sql = "SELECT * FROM MQ_SERV ";
    $sql .= "WHERE cust_id='" . db_escape($db, $cust_id) . "' ";
    //$sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result; 
  }

  function find_invoices_by_custid($cust_id){
    global $db;

    $cust_id = db_escape($db, $cust_id);

    $sql = "SELECT a.* FROM MQ_INV a join MQ_SERV b on a.invno=b.serv_no join MQ_CUST c on b.cust_id=c.cust_id 
    WHERE c.cust_id = $cust_id ORDER BY a.invno;" ;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result; 
  }

  function find_invpays_by_custid($cust_id){
    global $db;

    $cust_id = db_escape($db, $cust_id);

    $sql = "SELECT b.* FROM MQ_INV a join MQ_INVPAY b on a.invno=b.invno join MQ_PAY c on b.payno=c.payno 
    WHERE c.cust_id = $cust_id ORDER BY a.invno;" ;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result; 
  }




  ?>
