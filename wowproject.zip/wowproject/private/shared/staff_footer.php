<footer>
  &copy; <?php echo date('Y'); ?> World on Wheels
</footer>

</body>
</html>

<?php
  db_disconnect($db);
?>
