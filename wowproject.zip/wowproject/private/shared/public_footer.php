  <footer>
    <p>Copyright <?php echo date('Y'); ?>, World On Wheels </p>
  </footer>

  <p>WOW (World On Wheels) is a car rental company. WOW has many locations at various airports, towns, and cities
in the United States.</p>

  </body>
</html>

<?php
  db_disconnect($db);
?>
