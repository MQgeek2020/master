<?php
  if(!isset($page_title)) { $page_title = 'Customer Area'; }

?>

<!doctype html>

<html lang="en">
  <head>
    <title>WOW - <?php echo h($page_title); ?></title>
    <meta charset="utf-8">
    <link rel="stylesheet" media="all" href="<?php echo url_for('/stylesheets/customer.css'); ?>" />
  </head>

  <body>
    <header>
      <h1>WOW Customer Area</h1>
    </header>

    <navigation>
      <ul>
        <li>Customer User: <?php echo $_SESSION['cust_username'] ?? ''; ?></li>
        <li>First Name: <?php echo ''; ?></li>
        <li>Last Name: <?php echo ''; ?></li><br/>
        <li><a href="<?php echo url_for('/homepage/login.php'); ?>">Login Page</a></li>
      </ul>
    </navigation>

    <?php echo display_session_message(); ?>
