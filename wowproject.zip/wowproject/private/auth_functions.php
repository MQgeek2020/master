<?php

  // Performs all actions necessary to log in an admin
  function log_in_staff_admin($admin) {
  // Renerating the ID protects the admin from session fixation.
    session_regenerate_id();
    $_SESSION['staff_admin_id'] = $admin['id'];
    $_SESSION['staff_last_login'] = time();
    $_SESSION['staff_username'] = $admin['username'];
    $_SESSION['staff_first_name'] = $admin['first_name'];
    $_SESSION['staff_last_name'] = $admin['last_name'];
    return true;
  }

  // Performs all actions necessary to log out an admin
  function log_out_staff_admin() {
    unset($_SESSION['staff_admin_id']);
    unset($_SESSION['staff_last_login']);
    unset($_SESSION['staff_username']);
    unset($_SESSION['staff_first_name']);
    unset($_SESSION['staff_last_name']) ;
    // session_destroy(); // optional: destroys the whole session
    return true;
  }

  function log_in_cust_admin($admin) {
  // Renerating the ID protects the admin from session fixation.
    session_regenerate_id();
    $_SESSION['cust_admin_id'] = $admin['id'];
    $_SESSION['cust_last_login'] = time();
    $_SESSION['cust_username'] = $admin['username'];
    $_SESSION['cust_first_name'] = $admin['first_name'];
    $_SESSION['cust_last_name'] = $admin['last_name'];
    return true;
  }

  // Performs all actions necessary to log out an admin
  function log_out_cust_admin() {
    unset($_SESSION['cust_admin_id']);
    unset($_SESSION['cust_last_login']);
    unset($_SESSION['cust_username']);
    unset($_SESSION['cust_first_name']);
    unset($_SESSION['cust_last_name']) ;
    // session_destroy(); // optional: destroys the whole session
    return true;
  }


  // is_logged_in() contains all the logic for determining if a
  // request should be considered a "logged in" request or not.
  // It is the core of require_login() but it can also be called
  // on its own in other contexts (e.g. display one link if an admin
  // is logged in and display another link if they are not)
  function is_staff_logged_in() {
    // Having a admin_id in the session serves a dual-purpose:
    // - Its presence indicates the admin is logged in.
    // - Its value tells which admin for looking up their record.
    return isset($_SESSION['staff_admin_id']);
  }

  function is_cust_logged_in() {
    // Having a admin_id in the session serves a dual-purpose:
    // - Its presence indicates the admin is logged in.
    // - Its value tells which admin for looking up their record.
    return isset($_SESSION['cust_admin_id']);
  }

  // Call require_login() at the top of any page which needs to
  // require a valid login before granting acccess to the page.
  function require_login() {
    if(!is_staff_logged_in()) {
      redirect_to(url_for('/staff/login.php'));
    } else {
      // Do nothing, let the rest of the page proceed
    }
  }


  function require_cust_login() {
    if(!is_cust_logged_in()) {
      redirect_to(url_for('/homepage/login.php'));
    } else {
      // Do nothing, let the rest of the page proceed
    }
  }

?>
