<?php

define("DB_SERVER", "localhost");
define("DB_USER", "wow");
define("DB_PASS", "wowpass");
define("DB_NAME", "wowdb");

?>
