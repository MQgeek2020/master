<?php require_once('../private/initialize.php'); ?>

<?php include(SHARED_PATH . '/public_header.php'); ?>

<div id="main">

  <div id="page">

  </div>

</div>

<?php include(SHARED_PATH . '/public_footer.php'); ?>
