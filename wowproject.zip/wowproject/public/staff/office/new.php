<?php

require_once('../../../private/initialize.php');

require_login();

if(is_post_request()) {

  // Handle form values sent by new.php
  
  $office = [];
  $office['loc_state'] = $_POST['state'] ?? '';
  $office['loc_city'] = $_POST['city'] ?? '';
  $office['loc_st'] = $_POST['street'] ?? '';
  $office['floor'] = $_POST['floor'] ?? '';
  $office['loc_zipcode'] = $_POST['zipcode'] ?? '';
  $office['loc_phone'] = $_POST['phone'] ?? '';

  $result = insert_office($office);
  if($result === true){
      $new_id = mysqli_insert_id($db);
      redirect_to(url_for('/staff/office/show.php?id=' . $new_id));
  }else{
      $errors = $result;
  }

} else {
  //display the blank form
  $office = [];
  $office['loc_state'] = '';
  $office['loc_city'] = '';
  $office['loc_st'] = '';
  $office['floor'] = '';
  $office['loc_zipcode'] = '';
  $office['loc_phone'] = '';

}


?>

<?php $page_title = 'Create Office'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/office/index.php'); ?>">&laquo; Back to List</a>

  <div class="subject new">
    <h1>Create Office</h1>

    <?php echo display_errors($errors); ?>

    <form action="<?php echo url_for('/staff/office/new.php'); ?>" method="post">
     <dl>
        <dt>State</dt>
        <dd><input type="text" name="state" value="<?php echo $office['loc_state']; ?>" /></dd>
      </dl>
      <dl>
        <dt>City</dt>
        <dd><input type="text" name="city" value="<?php echo $office['loc_city']; ?>" /></dd>
      </dl>
       <dl>
        <dt>Street</dt>
        <dd><input type="text" name="street" value="<?php echo $office['loc_st']; ?>" /></dd>
      </dl>
       <dl>
        <dt>Floor</dt>
        <dd><input type="number" name="floor" value="<?php echo $office['floor']; ?>" min="0" max="70"/></dd>(Optional)
      </dl>
       <dl>
        <dt>Zipcode</dt>
        <dd><input type="number" name="zipcode" value="<?php echo $office['loc_zipcode']; ?>" min="0"/></dd>
      </dl>
      <dl>
        <dt>Phone</dt>
        <dd><input type="text" name="phone" value="<?php echo  $office['loc_phone']; ?>" /></dd>
      </dl>
      
      <div id="operations">
        <input type="submit" value="Create New Office" />
      </div>
    </form>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
