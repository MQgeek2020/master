<?php require_once('../../../private/initialize.php'); ?>

<?php
  
  require_login();
  
  $office_set = find_all_offices();
?>

<?php $page_title = 'Office Locations'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

   <a class="action" href="<?php echo url_for('/staff/index.php'); ?>"> &laquo; Back to Main Menu</a>

  <div class="offices listing">
    <h1>Office Locations</h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/office/new.php'); ?>">Create New Office</a>
    </div>

  	<table class="list">
  	  <tr>
        <th>ID</th>
        <th>State</th>
        <th>City</th>
  	    <th>Street</th>
        <th>Floor</th>
        <th>Zipcode</th>
        <th>Phone</th>
        <th>Vehicles Stored</th>
  	    <th>&nbsp;</th>
  	    <th>&nbsp;</th>
        <th>&nbsp;</th>
  	  </tr>

      <?php while($office = mysqli_fetch_assoc($office_set)) { ?>
        <?php $vehicle_count = count_vehicles_by_office_id($office['loc_id']); ?>
        <tr>
          <td><?php echo h($office['loc_id']); ?></td>
          <td><?php echo h($office['loc_state']); ?></td>
          <td><?php echo h($office['loc_city']); ?></td>
          <td><?php echo h($office['loc_st']); ?></td>
          <td><?php echo h($office['floor']) == 0 ? 'NULL' : h($office['floor']); ?></td>
          <td><?php echo h($office['loc_zipcode']); ?></td>
          <td><?php echo "+1 " . h($office['loc_phone']); ?></td>
          <td><?php echo $vehicle_count; ?></td>

          <td><a class="action" href="<?php echo url_for('/staff/office/show.php?id=' . h(u($office['loc_id']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/office/edit.php?id=' . h(u($office['loc_id']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/office/delete.php?id=' . h(u($office['loc_id']))); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>

    <?php
      mysqli_free_result($office_set);
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
