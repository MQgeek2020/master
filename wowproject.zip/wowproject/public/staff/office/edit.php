<?php

require_once('../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/office/index.php'));
}
$id = $_GET['id'];

if(is_post_request()) {

  // Handle form values sent by edit.php
  // This is single page post submission.

  $office = [];
  $office['loc_id'] = $id;
  $office['loc_state'] = $_POST['state'] ?? '';
  $office['loc_city'] = $_POST['city'] ?? '';
  $office['loc_st'] = $_POST['street'] ?? '';
  $office['floor'] = $_POST['floor'] ?? '';
  $office['loc_zipcode'] = $_POST['zipcode'] ?? '';
  $office['loc_phone'] = $_POST['phone'] ?? '';
 

  $result = update_office($office);
  if($result === true) {
    redirect_to(url_for('/staff/office/show.php?id=' . $id));
  } else {
    $errors = $result;
    //var_dump($errors);
  }

} else {

  $office = find_office_by_id($id);

}

?>


<?php $page_title = 'Edit Office Location'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/office/index.php'); ?>">&laquo; Back to List</a>

  <div class="office edit">
    <h1>Edit Office Location</h1>
    <?php echo display_errors($errors); ?>

    <form action="" method="post">
      <dl>
        <dt>State</dt>
        <dd><input type="text" name="state" value="<?php echo h($office['loc_state']); ?>" /></dd>
      </dl>
      <dl>
        <dt>City</dt>
        <dd><input type="text" name="city" value="<?php echo h($office['loc_city']); ?>" /></dd>
      </dl>
       <dl>
        <dt>Street</dt>
        <dd><input type="text" name="street" value="<?php echo h($office['loc_st']); ?>" /></dd>
      </dl>
       <dl>
        <dt>Floor</dt>
        <dd><input type="number" name="floor" value="<?php echo h($office['floor']); ?>" min="0" max="70"/></dd>(Optional)
      </dl>
       <dl>
        <dt>Zipcode</dt>
        <dd><input type="number" name="zipcode" value="<?php echo h($office['loc_zipcode']); ?>" min="0"/></dd>
      </dl>
      <dl>
        <dt>Phone</dt>
        <dd><input type="text" name="phone" value="<?php echo h($office['loc_phone']); ?>" /></dd>
      </dl>
      
      
      <div id="operations">
        <input type="submit" value="Edit Office Location" />
      </div>
    </form>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
