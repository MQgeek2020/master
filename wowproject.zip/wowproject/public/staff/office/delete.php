<?php

require_once('../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/office/index.php'));
}
$loc_id = $_GET['id'];

if(is_post_request()) {

  $result = delete_office($loc_id);
  redirect_to(url_for('/staff/office/index.php'));

} else {
  $office = find_office_by_id($loc_id);
}

?>

<?php $page_title = 'Delete Office'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/office/index.php'); ?>">&laquo; Back to List</a>

  <div class="office delete">
    <h1>Delete Office</h1>
    <p><h2>Are you sure you want to delete this office?</h2></p>
    <p class="item">
      <?php echo "<h3>Form parameters:</h3>";
            echo "Office Location ID: ". h($office['loc_id']) . "<br />";
            echo "State: " . h($office['loc_state']) . "<br />";
            echo "City: " . h($office['loc_city']) . "<br />";
            echo "Street: " . h($office['loc_st']) . "<br />";
            echo "Floor: " . h($office['floor']) . "<br />";
            echo "Zipcode: " . h($office['loc_zipcode']) . "<br />";
            echo "Phone: " . "+1" .  h($office['loc_phone']) . "<br />";
      ?>      
      </p>
     <br/>
    <form action="<?php echo url_for('/staff/office/delete.php?id=' . h(u($office['loc_id']))); ?>" method="post">
      <div id="operations">
        <input type="submit" name="commit" value="Delete Office" />
      </div>
    </form>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
