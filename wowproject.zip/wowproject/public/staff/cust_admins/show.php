<?php

require_once('../../../private/initialize.php');

require_login();

$id = $_GET['id'] ?? '1'; // PHP > 7.0
$cust_admin = find_cust_admin_by_id($id);

?>

<?php $page_title = 'Show Cusotmer Admin'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/cust_admins/index.php'); ?>">&laquo; Back to List</a>

  <div class="admin show">
    
    <h1>Customer Admins: </h1></br>
    <h1>Username: <?php echo h($cust_admin['username']); ?></h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/cust_admins/edit.php?id=' . h(u($cust_admin['id']))); ?>">Edit</a>
      <a class="action" href="<?php echo url_for('/staff/cust_admins/delete.php?id=' . h(u($cust_admin['id']))); ?>">Delete</a>
    </div>

    <div class="attributes">
      <dl>
        <dt>First name</dt>
        <dd><?php echo h($cust_admin['first_name']); ?></dd>
      </dl>
      <dl>
        <dt>Last name</dt>
        <dd><?php echo h($cust_admin['last_name']); ?></dd>
      </dl>
      <dl>
        <dt>Email</dt>
        <dd><?php echo h($cust_admin['email']); ?></dd>
      </dl>
      <dl>
        <dt>Username</dt>
        <dd><?php echo h($cust_admin['username']); ?></dd>
      </dl>
    </div>

  </div>

</div>
<?php include(SHARED_PATH . '/staff_footer.php'); ?>