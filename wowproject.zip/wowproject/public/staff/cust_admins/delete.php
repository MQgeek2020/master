<?php

require_once('../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/cust_admins/index.php'));
}
$id = $_GET['id'];

if(is_post_request()) {
  $result = delete_cust_admin($id);
  $_SESSION['message'] = 'Customer Admin Deleted.';
  redirect_to(url_for('/staff/cust_admins/index.php'));
} else {
  $admin = find_cust_admin_by_id($id);
}

?>

<?php $page_title = 'Delete Customer Admin'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/cust_admins/index.php'); ?>">&laquo; Back to List</a>

  <div class="admin delete">
    <h1>Delete Customer Admin</h1>
    <p>Are you sure you want to delete this admin?</p>
    <p class="item">
      <?php echo "<h3>Admin parameters:</h3>";
            echo "Admin ID: ". h($admin['id']). "<br />" ; 
            echo "First Name: " . h($admin['first_name']) . "<br />";
            echo "Last Name: " . h($admin['last_name']) . "<br />";
            echo "Email: " . h($admin['email']) . "<br />";
            echo "Username: " . h($admin['username']) . "<br />";
            echo "Hashed_password: " . h($admin['hashed_password']). "<br />";
          ?>       
    </p>
     </br>
    <form action="<?php echo url_for('/staff/cust_admins/delete.php?id=' . h(u($admin['id']))); ?>" method="post">
      <div id="operations">
        <input type="submit" name="commit" value="Delete Customer Admin" />
      </div>
    </form>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
