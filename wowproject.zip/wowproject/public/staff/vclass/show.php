<?php require_once('../../../private/initialize.php'); ?>

<?php

require_login();

$id = $_GET['id'] ?? '1';

$vclass = find_vclass_by_id($id);
$vehicle_set = find_vehicles_by_vclass_id($id);
$vehicle_count = mysqli_num_rows($vehicle_set);

?>

<?php $page_title = 'Show Vehicle Class'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/vclass/index.php'); ?>">&laquo; Back to List</a>

  <div class="vehicle class show">

    <h1>Vehicle Class Name: <?php echo h($vclass['vc_name']); ?></h1>

    <div class="attributes">
     <dl>
        <dt>Vehicle Class ID</dt>
        <dd><?php echo h($vclass['vclass_id']); ?></dd>
      </dl>
       <dl>
        <dt>Rental Charge Rate</dt>
        <dd><?php echo h($vclass['rent_charge']) . "  $/day"; ?></dd>  
      </dl>
       <dl>
        <dt>Over Mileage Fees</dt>
        <dd><?php echo h($vclass['extra_charge']) . "  $/mile"; ?></dd> 
      </dl>
      
   </div>

 <hr />

      <div class="vehicles listing">
    <h1>Vehicles</h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/vehtype/new.php?vclass_id=' . h(u($vclass['vclass_id']))); ?>">Create New Vehicle</a>
    </div>

   <?php $msg[] = "No vehicles found of this type. Please add new vehicles.";
       if($vehicle_count==0){ echo display_messages($msg);} 
       elseif($vehicle_count!=0) { ?>

    <table class="list">
      <tr>
        <th>Vehicle ID</th>
        <th>Make</th>
        <th>Model</th>
        <th>Year</th>
        <th>Vehicle Identification Number</th>
        <th>License Plate number</th>
        <th>Vehcle Class</th>
        <th>Office ID</th>
        <th>&nbsp;</th>
        <th>&nbsp;</th>
        <th>&nbsp;</th>
      </tr>

      <?php while($vehicle = mysqli_fetch_assoc($vehicle_set))  { ?>
      <?php $vclass = find_vclass_by_id($vehicle['vclass_id']); ?>
        <tr>
          <td><?php echo h($vehicle['veh_id']); ?></td>
          <td><?php echo h($vehicle['make']); ?></td>       
          <td><?php echo h($vehicle['model']); ?></td>
          <td><?php echo h($vehicle['vyear']); ?></td>
          <td><?php echo h($vehicle['VIN']); ?></td>       
          <td><?php echo h($vehicle['LPN']); ?></td>     
          <td><?php echo h($vclass['vc_name']); ?></td>
          <td><?php echo h($vehicle['loc_id']); ?></td>
          <td><a class="action" href="<?php echo url_for('/staff/vehtype/show.php?id=' . h(u($vehicle['veh_id']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/vehtype/edit.php?id=' . h(u($vehicle['veh_id']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/vehtype/delete.php?id=' . h(u($vehicle['veh_id']))); ?>">Delete</a></td>
        </tr>
      <?php } ?>
    </table>
    
    <?php
      mysqli_free_result($vehicle_set); }
    ?>

  </div>
</div>

</div>