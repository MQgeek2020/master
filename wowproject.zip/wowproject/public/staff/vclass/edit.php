<?php

require_once('../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/vclass/index.php'));
}
$id = $_GET['id'];

if(is_post_request()) {

  // Handle form values sent by edit.php

  $vclass = [];
  $vclass['vclass_id'] = $id;
  $vclass['vc_name'] = $_POST['vc_name'] ?? '';
  $vclass['rent_charge'] = $_POST['rent_charge'] ?? '';
  $vclass['extra_charge'] = $_POST['extra_charge'] ?? '';

  $result = update_vclass($vclass);
  if($result === true) {
    redirect_to(url_for('/staff/vclass/show.php?id=' . $id));
  } else {
    $errors = $result;
    //var_dump($errors);
  }

} else {

  $vclass = find_vclass_by_id($id);

}

?>

<?php $page_title = 'Edit Vehicle Class'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/vclass/index.php'); ?>">&laquo; Back to List</a>

  <div class="vehicle Class edit">
    <h1>Edit Vehicle Class</h1>
    <?php echo display_errors($errors); ?>

    <form action="" method="post">
      <dl>
        <dt>Vehicle Class Name</dt>
        <dd><input type="text" name="vc_name" value="<?php echo h($vclass['vc_name']); ?>" /></dd>
      </dl>

       <dl>
        <dt>Rental Rate</dt>
        <dd><input type="number" name="rent_charge" value="<?php echo h($vclass['rent_charge']); ?>"  min="0" step="0.1"/></dd>  $/day
      </dl>

       <dl>
        <dt>Over Mileage Fees</dt>
        <dd><input type="number" name="extra_charge" value="<?php echo h($vclass['extra_charge']); ?>" min="0" step="0.1"/></dd>  $/mile
      </dl>
      
      <div id="operations">
        <input type="submit" value="Edit Class" />
      </div>
    </form>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
