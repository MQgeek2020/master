<?php

require_once('../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/vclass/index.php'));
}
$vclass_id = $_GET['id'];

if(is_post_request()) {

  $result = delete_vclass($vclass_id);
  redirect_to(url_for('/staff/vclass/index.php'));

} else {
  $vclass = find_vclass_by_id($vclass_id);
}

?>

<?php $page_title = 'Delete Vehicle Class'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/vclass/index.php'); ?>">&laquo; Back to List</a>

  <div class="vehicle class delete">
    <h1>Delete Vehicle Class</h1>
    <p><h2>Are you sure you want to delete this vehicle class?</h2></p>
    <p class="item"><?php 
        echo "<h3>Form parameters:</h3>";
        echo "Vehicle Class ID: " . h($vclass['vclass_id']) . "<br />";
        echo "Vehicle Class Name: " . h($vclass['vc_name']) . "<br />";
        echo "Rental Rate: " . h($vclass['rent_charge']) . "$/day" . "<br />";
        echo "Over Mileage Fees: " . h($vclass['extra_charge']) . "$/mile" ."<br />";
    ?></p>

    <form action="<?php echo url_for('/staff/vclass/delete.php?id=' . h(u($vclass['vclass_id']))); ?>" method="post">
      <div id="operations">
        <input type="submit" name="commit" value="Delete Vehicle Class" />
      </div>
    </form>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
