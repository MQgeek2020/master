<?php require_once('../../../private/initialize.php'); ?>

<?php

  require_login();

  $vclass_set = find_all_vclasses();
?>

<?php $page_title = 'VehicleClasses'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
  
  <a class="action" href="<?php echo url_for('/staff/index.php'); ?>"> &laquo; Back to Main Menu</a>

  <div class="classes listing">
    <h1>Vehicle Classes</h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/vclass/new.php'); ?>">Create New Vehicle Tpye</a>
    </div>

  	<table class="list">
  	  <tr>
        <th>Vehicle Class ID</th>
        <th>Vehicle Class Name</th>
        <th>Rental Charge Rate</th>
  	    <th>Over Mileage Fees</th>
        <th>Vehicles</th>
  	    <th>&nbsp;</th>
  	    <th>&nbsp;</th>
        <th>&nbsp;</th>
  	  </tr>

      <?php while($vclass = mysqli_fetch_assoc($vclass_set)) { ?>
        <?php $vehicle_count = count_vehicles_by_vclass_id($vclass['vclass_id']); ?>
        <tr>
          <td><?php echo h($vclass['vclass_id']); ?></td>
          <td><?php echo h($vclass['vc_name']); ?></td>
          <td><?php echo h($vclass['rent_charge']); ?></td>
    	    <td><?php echo h($vclass['extra_charge']); ?></td>
          <td><?php echo $vehicle_count; ?></td>
          <td><a class="action" href="<?php echo url_for('/staff/vclass/show.php?id=' . h(u($vclass['vclass_id']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/vclass/edit.php?id=' . h(u($vclass['vclass_id']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/vclass/delete.php?id=' . h(u($vclass['vclass_id']))); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>
    <?php
      mysqli_free_result($vclass_set);
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
