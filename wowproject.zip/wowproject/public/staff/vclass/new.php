<?php

require_once('../../../private/initialize.php');

require_login();


if(is_post_request()) {

  // Handle form values sent by new.php
  $vclass =[];
  $vclass['vc_name'] = $_POST['vc_name'] ?? '';
  $vclass['rent_charge'] = $_POST['rent_charge'] ?? '';
  $vclass['extra_charge'] = $_POST['extra_charge'] ?? '';
  
  $result = insert_vclass($vclass);
  if($result === true){
      $new_id = mysqli_insert_id($db);
      redirect_to(url_for('/staff/vclass/show.php?id=' . $new_id));
  }else{
      $errors = $result;
  }

} else {
  //display the blank form
  $vclass =[];
  $vclass['vc_name'] = '';
  $vclass['rent_charge'] = '';
  $vclass['extra_charge'] = '';

}


?>

<?php $page_title = 'Create Vehicle Class'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/vclass/index.php'); ?>">&laquo; Back to List</a>

  <div class="class new">
    <h1>Create Vehicle Class</h1>

    <?php echo display_errors($errors); ?>

    <form action="<?php echo url_for('/staff/vclass/new.php'); ?>" method="post">

      <dl>
        <dt>Class Name</dt>
        <dd><input type="text" name="vc_name" value="<?php echo $vclass['vc_name']; ?>" /></dd>
      </dl>

       <dl>
        <dt>Rental Charge Rate</dt>
        <dd><input type="text" name="rent_charge" value="<?php echo $vclass['rent_charge']; ?>" min="0" step="0.1"/></dd> $/day
      </dl>

       <dl>
        <dt>Over Mileage Fees</dt>
        <dd><input type="text" name="extra_charge" value="<?php echo $vclass['extra_charge']; ?>" min="0" step="0.1"/></dd>  $/mile
      </dl>

      <div id="operations">
        <input type="submit" value="Create Class" />
      </div>
    </form>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
