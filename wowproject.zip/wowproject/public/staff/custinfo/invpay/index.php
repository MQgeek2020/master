<?php require_once('../../../../private/initialize.php'); ?>

<?php
  
  require_login();

  if(!isset($_SESSION['cust_id'])) {
    redirect_to(url_for('/staff/index.php'));
  }
  $cust_id = $_SESSION['cust_id'];
  $customer = find_customer_by_id($cust_id);
  $fname = name_format($customer['fname']);
  $lname = name_format($customer['lname']);
  $invpay_set = find_invpays_by_custid($cust_id);
  $invpay_count = mysqli_num_rows($invpay_set);

?>

<?php $page_title = 'Invoice Payments'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
   
  <a class="action" href="<?php echo url_for('/staff/custsearch.php'); ?>"> &lArr; Back to Search Index</a>

  <div class="invpays listing">
    <h1><?php echo h(u($fname)) . " " . h(u($lname)). "'s Invoice Pay Status"?></h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/custinfo/invpay/new.php'); ?>">Create New Invoice Payment &rArr; </a>
    </div>

    <?php if($invpay_count == 0 ){
      $msg[] = "No invoice payment record found.";
      echo display_messages($msg);

    } if ($invpay_count!= 0) { ?>


  	<table class="list">
  	  <tr>
        <th>Transaction ID</th>
        <th>Invoice No</th>
        <th>Payment No</th>
        <th>Transaction Date</th>
  	    <th>Amount</th>
        <th>Status</th>
  	    <th>&nbsp;</th>
  	    <th>&nbsp;</th>
        <th>&nbsp;</th>
  	  </tr>

      <?php while($invpay = mysqli_fetch_assoc($invpay_set))  { ?>
        <tr>
          <td><?php echo h($invpay['txn_id']); ?></td>
          <td><?php echo h($invpay['invno']); ?></td>
          <td><?php echo h($invpay['payno']); ?></td>
    	    <td><?php echo h($invpay['pay_date']); ?></td>
          <td><?php echo h($invpay['pay_amount']); ?></td>
          <td>
            <?php if($invpay['pay_status'] == 'CLEARED'){
                  echo 'Cleared';
             } else{
              echo $invpay['pay_status'] == 'UNCLEARED' ? 'Uncleared' : 'Unpaid';  }
              
              ?> </td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/invpay/show.php?id=' . h(u($invpay['txn_id'])) ); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/invpay/edit.php?id=' . h(u($invpay['txn_id'])) ); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/invpay/delete.php?id=' . h(u($invpay['txn_id'])) ); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>
    <?php
      mysqli_free_result($invpay_set); }
    ?>

  </div>

</div>

<?php
/*<td><a class="action" href="<?php echo url_for('/staff/invpay/edit.php?id=' . h(u($invpay['id']))); ?>">Edit</a></td> */
?>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
