<?php

require_once('../../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/custinfo/invpay/index.php'));
}
$id = $_GET['id'];

if(is_post_request()) {

  // Handle form values sent by edit.php

  $invpay = [];
  $invpay['txn_id'] = $id;
  $invpay['invno'] = $_POST['invno'] ?? '';
  $invpay['payno'] = $_POST['payno'] ?? '';
  $invpay['pay_date'] = $_POST['pay_date'] ?? '';
  $invpay['pay_amount'] = $_POST['pay_amount'] ?? '';
  $invpay['pay_status'] = $_POST['status'] ?? '';

  $result = update_invpay($invpay);
  if($result === true) {
    redirect_to(url_for('/staff/custinfo/invpay/show.php?id=' . $id));
  } else {
    $errors = $result;
    //var_dump($errors);
  }

} else {

  $invpay = find_invpay_by_id($id);

}

// $invoice_set = find_all_invoices();
// $payment_set = find_all_payments();
$cust_id = $_SESSION['cust_id'];
$invoice_set = find_invoices_by_custid($cust_id);
$payment_set = find_payments_by_custid($cust_id);

?>

<?php $page_title = 'Edit Invoice Payment'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custinfo/invpay/index.php'); ?>">&laquo; Back to Index</a>

  <div class="invpay edit">
    <h1>Edit Invoice Payment</h1>
    <?php echo display_errors($errors); ?>

    <form action="" method="post">
       <dl>
        <dt>Invoice No</dt>
        <dd>
          <select name="invno">
          <?php
            foreach($invoice_set as $invoice) {
              echo "<option value=\"{$invoice['invno']}\"";
              if($invpay['invno'] == $invoice['invno']) {
                echo " selected";
              }
              echo ">{$invoice['invno']}</option>";
            }
          ?>
          </select>
        </dd>
      </dl>  
      <dl>
        <dt>Payment No</dt>
        <dd>
          <select name="payno">
          <?php
            foreach($payment_set as $payment) {
              echo "<option value=\"{$payment['payno']}\"";
              if($invpay['payno'] == $payment['payno']) {
                echo " selected";
              }
              echo ">{$payment['payno']}</option>";
            }
          ?>
          </select>
        </dd>
      </dl>
      
      <dl>
        <dt>Transaction Date</dt>
        <dd><input type="date" name="pay_date" value="<?php echo h($invpay['pay_date']); ?>" /></dd>
      </dl>
      <dl>
        <dt>Payment Amount</dt>
        <dd><input type="number" name="pay_amount" value="<?php echo h($invpay['pay_amount']); ?>" min="0" step="0.01"/></dd>  $
      </dl>
      <dl>
        <dt>Status</dt>
         <dd><select name="status">
         <option  value="CLEARED" <?php if (h($invpay['pay_status']!==NULL) && h($invpay['pay_status'])=="CLEARED") echo "selected";?>>Cleared</option>
         <option  value="UNCLEARED" <?php if (h($invpay['pay_status']!==NULL) && h($invpay['pay_status'])=="UNCLEARED") echo "selected";?>>Uncleared</option>
         <option  value="UNPAID"  <?php if (h($invpay['pay_status']!==NULL) && h($invpay['pay_status'])=="UNPAID") echo "selected";?>>Unpaid</option>
         </select><dd>
      </dl>   
      <br>
      <div id="operations">
        <input type="submit" value="Edit Invoice Payment" />
      </div>
    </form>

  </div>

</div>
<?php

mysqli_free_result($invoice_set);
mysqli_free_result($payment_set);

?>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
