<?php

require_once('../../../../private/initialize.php');

require_login();

if(is_post_request()) {

  // Handle form values sent by new.php

  $invpay = [];
  $invpay['invno'] = $_POST['invno'] ?? '';
  $invpay['payno'] = $_POST['payno'] ?? '';
  $invpay['pay_date']= $_POST['pay_date'] ?? '';
  $invpay['pay_amount'] = $_POST['pay_amount'] ?? '';
  $invpay['pay_status'] = $_POST['status'] ?? '';

  $result = insert_invpay($invpay);
  if($result === true){
      $new_id = mysqli_insert_id($db);
      redirect_to(url_for('/staff/custinfo/invpay/show.php?id=' . $new_id));
  }else{
      $errors = $result;
  }

  } else {
  //display the blank form
  $invpay = [];
  $invpay['invno'] = '';
  $invpay['payno'] = '';
  $invpay['pay_date']= '';
  $invpay['pay_amount'] = '';
  $invpay['pay_status'] = '';

}

// $invoice_set = find_all_invoices();
// $payment_set = find_all_payments$cust_id = $_SESSION['cust_id'];
$cust_id = $_SESSION['cust_id'];
//$invoice_set = find_invoices_by_custid($cust_id);
$invoice_set = find_invoices_by_custid($cust_id);
$payment_set = find_payments_by_custid($cust_id);
$payment_count = mysqli_num_rows($payment_set);

?>

<?php $page_title = 'Create Invoice Payment'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <div class="invpay new">
       <?php if($payment_count == 0){
      $msg[] = "At least one payment must be added before create a new invoice payment record.";
      echo display_messages($msg);
    } ?>
  </div>

  <a class="back-link" href="<?php echo url_for('/staff/custinfo/invpay/index.php'); ?>">&lArr; Back to Index</a>
  
  <div class="invpay new">
    <h1>Create Invoice Payment</h1>

     <?php echo display_errors($errors); ?>

    <form action="<?php echo url_for('/staff/custinfo/invpay/new.php'); ?>" method="post">
       <dl>
        <dt>Invoice No</dt>
        <dd>
          <select name="invno">
          <?php
            foreach($invoice_set as $invoice) {
              echo "<option value=\"{$invoice['invno']}\"";
              if($invpay['invno'] == $invoice['invno']) {
                echo " selected";
              }
              echo ">{$invoice['invno']}</option>";
            }
          ?>
          </select>
        </dd>
      </dl>  
      <dl>
        <dt>Payment No</dt>
        <dd>
          <select name="payno">
          <?php
            foreach($payment_set as $payment) {
              echo "<option value=\"{$payment['payno']}\"";
              if($invpay['payno'] == $payment['payno']) {
                echo " selected";
              }
              echo ">{$payment['payno']}</option>";
            }
          ?>
          </select>
        </dd>
      </dl>
      <dl>
        <dt>Transaction Date</dt>
        <dd><input type="date" name="pay_date" value="<?php echo $invpay['pay_date']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Payment Amount</dt>
        <dd><input type="number" name="pay_amount" value="<?php echo $invpay['pay_status']; ?>" min="0" step="0.01"/></dd>
      </dl>

      <dl>
        <dt>Status</dt>
         <dd><select name="status">
         <option value="CLEARED" <?php if (h($invpay['pay_status'])=="CLEARED") echo "selected";?>>Cleared</option>
         <option value="UNCLEARED" <?php if  (h($invpay['pay_status'])=="UNCLEARED") echo "selected";?>>Uncleared</option>
         <option value="UNPAID"<?php if  (h($invpay['pay_status'])=="UNPAID") echo "selected";?>>Unpaid</option>
         </select><dd>
      </dl>   
      
      <br>
      <div id="operations">
        <input type="submit" value="Create Invoice Payment" />
      </div>
    </form>

  </div>

</div>
<?php
/*    <dl>
        <dt>Invoice No</dt>
        <dd><input type="number" name="invno" value="<?php echo $invpay['invno']; ?>" min="1"/></dd>
      </dl>
      <dl>
        <dt>Payment No</dt>
        <dd><input type="number" name="payno" value="<?php echo $invpay['payno']; ?>" min="1"/></dd>
      </dl>



*/
mysqli_free_result($invoice_set);
mysqli_free_result($payment_set);


?>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
