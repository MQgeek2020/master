<?php

require_once('../../../../private/initialize.php');

require_login();

$id = $_GET['id'] ?? '1'; 
//$cust_id = $_GET['cust_id'] ?? '1'; 
$cust_admin = find_cust_admin_by_id($id);

?>

<?php $page_title = 'Show Cusotmer Admin'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custinfo/cust_admins/index.php'); ?>">&lArr; Back to Index</a>

  <div class="admin show">
    
    <h1>Username: <?php echo h($cust_admin['username']); ?></h1>

    <div class="attributes">
      <dl>
        <dt>First name</dt>
        <dd><?php echo h($cust_admin['first_name']); ?></dd>
      </dl>
      <dl>
        <dt>Last name</dt>
        <dd><?php echo h($cust_admin['last_name']); ?></dd>
      </dl>
      <dl>
        <dt>Email</dt>
        <dd><?php echo h($cust_admin['email']); ?></dd>
      </dl>
      <dl>
        <dt>Username</dt>
        <dd><?php echo h($cust_admin['username']); ?></dd>
      </dl>
    </div>

  </div>

</div>
<?php include(SHARED_PATH . '/staff_footer.php'); ?>