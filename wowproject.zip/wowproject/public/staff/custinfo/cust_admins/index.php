<?php

require_once('../../../../private/initialize.php');

require_login();


if(!isset($_SESSION['cust_id'])) {
  redirect_to(url_for('/staff/index.php'));
}
$cust_id = $_SESSION['cust_id'];
$customer = find_customer_by_id($cust_id);
$cust_admin = find_cust_admin_by_customer($customer);
$first_name = h(u($customer['fname']));
$last_name = h(u($customer['lname']));
?>

<?php $page_title = 'Customer Admins'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
  <a class="back-link" href="<?php echo url_for('/staff/custsearch.php'); ?>">&lArr; Back to Search Index</a>
  <div class="admins listing">
    <h1><?php echo name_format($first_name) . " " . name_format($last_name) . "'s Admin"?></h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/custinfo/cust_admins/new.php'); ?>">Create New Admin &rArr;</a>
    </div>

    <?php if(!isset($cust_admin)){
      $msg[]="No admin found for this customer.";
      echo display_messages($msg);
    } if (isset($cust_admin)) { ?>

    <table class="list">
      <tr>
        <th>ID</th>
        <th>First</th>
        <th>Last</th>
        <th>Email</th>
        <th>Username</th>
        <th>&nbsp;</th>
        <th>&nbsp;</th>
        <th>&nbsp;</th>
      </tr>

      <?php //while($cust_admin = mysqli_fetch_assoc($cust_admin_set)) { ?>
        <tr>
          <td><?php echo h($cust_admin['id']); ?></td>
          <td><?php echo h($cust_admin['first_name']); ?></td>
          <td><?php echo h($cust_admin['last_name']); ?></td>
          <td><?php echo h($cust_admin['email']); ?></td>
          <td><?php echo h($cust_admin['username']); ?></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/cust_admins/show.php?id=' . h(u($cust_admin['id']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/cust_admins/edit.php?id=' . h(u($cust_admin['id']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/cust_admins/delete.php?id=' . h(u($cust_admin['id']))); ?>">Delete</a></td>
        </tr>
      <?php  //} ?>
    </table>

  </div>

</div>
 <?php  } ?>
<?php //include(SHARED_PATH . '/staff_footer.php'); ?>
