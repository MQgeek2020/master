<?php require_once('../../../../private/initialize.php'); ?>

<?php

require_login();

$id = $_GET['id'] ?? '1';

$coupon = find_coupon_by_id($id);
?>

<?php $page_title = 'Show Coupon'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custinfo/coupon/index.php'); ?>">&laquo; Back to Index</a>

  <div class="coupon show">

  	<h1>Coupon No: <?php echo h($coupon['coupon_no']); ?></h1>

  	<div class="attributes">
    <?php $customer = find_customer_by_id($coupon['cust_id']); ?>
     <dl>
        <dt>Customer Name</dt>
        <dd><?php echo h($customer['fname']. " " .h($customer['lname'])); ?></dd>
      </dl>
      <dl>
        <dt>Coupon Type</dt>
        <dd><?php echo $coupon['coup_type'] == 'IND' ? 'Individual' : 'Corporation'; ?></dd>
      </dl>
      <dl>
        <dt>Discount</dt>
        <dd><?php echo h($coupon['discount']) . " %"; ?></dd>
      </dl>
      <dl>
        <dt>Start Date</dt>
        <dd><?php echo h($coupon['sta_date']); ?></dd>
      </dl>
      <dl>
        <dt>Expiration Date</dt>
        <dd><?php echo h($coupon['exp_date']); ?></dd>
      </dl>

   </div>

  </div>

</div>
<?php include(SHARED_PATH . '/staff_footer.php'); ?>