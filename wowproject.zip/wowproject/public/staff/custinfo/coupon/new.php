<?php

require_once('../../../../private/initialize.php');

require_login();

if(is_post_request()) {

  
  $coupon = [];
  $coupon['coup_type'] = $_POST['coup_type'] ?? '';
  $coupon['discount'] = $_POST['discount'] ?? '';
  $coupon['sta_date'] = $_POST['sta_date'] ?? '';
  $coupon['exp_date'] = $_POST['exp_date'] ?? '';
  //$coupon['usedate'] = $_POST['usedate'] ?? '';
  $coupon['cust_id'] = $_POST['cust_id'] ?? '';


  $result = insert_coupon($coupon);
  if($result === true){
    $new_id = mysqli_insert_id($db);
    redirect_to(url_for('/staff/custinfo/coupon/show.php?id=' . $new_id));
  }else{
    $errors = $result;
  }

} else {
  //display the blank form
  $coupon['coup_type'] = '';
  $coupon['discount'] = '';
  $coupon['sta_date'] = '';
  $coupon['exp_date'] = '';
  //$coupon['usedate'] = $_POST['usedate'] ?? '';
  $coupon['cust_id'] = '';
}
  
$cust_id = $_SESSION['cust_id'];
$customer = find_customer_by_id($cust_id);
$cust_type = h(u($customer['cust_type']));

?>

<?php $page_title = 'Create Coupon'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custinfo/coupon/index.php'); ?>">&lArr; Back to Index</a>

  <div class="coupon new">
    <h1>Create Coupon</h1>

    <?php echo display_errors($errors); ?>

    <form action="<?php echo url_for('/staff/custinfo/coupon/new.php'); ?>" method="post">
    <dl>
        <dt>Customer</dt>
        <dd>
          <select name="cust_id">
          <?php
            echo "<option value=\"{$customer['cust_id']}\"";
              if($coupon['cust_id'] == $customer['cust_id']) {
                echo " selected";
              }
              echo ">" . h($customer['cust_id']) . "--" . h($customer['fname']) . " " . h($customer['lname']) . "</option>";
          ?>
          </select>
        </dd>
      </dl>
      
      <dl>
        <dt>Coupon Type</dt>
        <dd>
         <?php if ($cust_type == 'I') { ?>
          <input type="radio" name="coup_type" <?php if (($cust_type!== null) && ($cust_type=="I")) echo "checked";?>  value="IND"/>Individual<br>
         <?php } elseif($cust_type == 'C') { ?>
          <input type="radio" name="coup_type" <?php if (($cust_type!== null) && ($cust_type=="C")) echo "checked";?>  value="COR"/>Corporation
          <?php }  ?>
        </dd>
      </dl>

      <dl>
        <dt>Discount</dt>
        <dd><input type="number" name="discount" value="" min="0" max="100" step="0.01"/></dd> %
      </dl>
      <dl>
        <dt>Start Date</dt>
        <dd><input type="date" name="sta_date" value="" /></dd>
      </dl>
      <dl>
        <dt>Expiration Date</dt>
        <dd><input type="date" name="exp_date" value="" /></dd>
      </dl>

      <br>
      <br>
      <div id="operations">
        <input type="submit" value="Create New Coupon" />
      </div>
    </form>

  </div>

</div>


<?php include(SHARED_PATH . '/staff_footer.php'); ?>
