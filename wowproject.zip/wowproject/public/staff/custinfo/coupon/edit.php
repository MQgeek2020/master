<?php

require_once('../../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/custinfo/coupon/index.php'));
}
$id = $_GET['id'];

if(is_post_request()) {

  // Handle form values sent by edit.php

  $coupon = [];
  $coupon['coupon_no'] = $id;
  $coupon['coup_type'] = $_POST['coup_type'] ?? '';
  $coupon['discount'] = $_POST['discount'] ?? '';
  $coupon['sta_date'] = $_POST['sta_date'] ?? '';
  $coupon['exp_date'] = $_POST['exp_date'] ?? '';
  $coupon['usedate'] = $_POST['usedate'] ?? '';
  $coupon['cust_id'] = $_POST['cust_id'] ?? '';

  $result = update_coupon($coupon);
  if($result === true) {
     redirect_to(url_for('/staff/custinfo/coupon/show.php?id=' . $id));
  } else {
    $errors = $result;
    //var_dump($errors);
  }

} else {

  $coupon = find_coupon_by_id($id);

}

$cust_id = $_SESSION['cust_id'];
$customer = find_customer_by_id($cust_id);
$cust_type = h($customer['cust_type']);

?>

<?php $page_title = 'Edit Coupon'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custinfo/coupon/index.php'); ?>">&lArr; Back to Index</a>

  <div class="coupon edit">
    <h1>Edit Coupon</h1>

    <?php echo display_errors($errors); ?>

    <form action="" method="post">
    <dl>
      <dt>Customer </dt>
        <dd>
          <select name="cust_id">
          <?php
              echo "<option value=\"{$customer['cust_id']}\"";
              if($coupon['cust_id'] == $customer['cust_id']) {
                echo " selected";
              }
              echo ">" . h($customer['cust_id']) . "--" . h($customer['fname']) . " " .h($customer['lname']).  "</option>";
          ?>
          </select>
        </dd>
      </dl>
      <dl>
        <dt>Coupon Type</dt>
        <dd>
        <?php if ($cust_type == 'I') { ?>
          <input type="radio" name="coup_type" <?php if (h($coupon['coup_type']!== null) && h($coupon['coup_type'])=="IND") echo "checked";?>  value="IND"/>Individual<br>
        <?php } elseif($cust_type == 'C') { ?>
          <input type="radio" name="coup_type" <?php if (h($coupon['coup_type']!== null) && h($coupon['coup_type'])=="COR") echo "checked";?>  value="COR"/>Corporation
        <?php }  ?>
        </dd>
      </dl>

      <dl>
        <dt>Discount</dt>
        <dd><input type="number" name="discount" value="<?php echo h($coupon['discount']); ?>" min="0" max="100" step = "0.01"/></dd> %
      </dl>
      <dl>
        <dt>Start Date</dt>
        <dd><input type="date" name="sta_date" value="<?php echo h($coupon['sta_date']); ?>" /></dd>
      </dl>
      <dl>
        <dt>Expiration Date</dt>
        <dd><input type="date" name="exp_date" value="<?php echo h($coupon['exp_date']); ?>" /></dd>
      </dl>

      <br>
      <div id="operations">
        <input type="submit" value="Edit Coupon" />
      </div>
      
    </form>

  </div>

</div>


<?php include(SHARED_PATH . '/staff_footer.php'); ?>
