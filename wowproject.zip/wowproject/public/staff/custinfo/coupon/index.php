<?php require_once('../../../../private/initialize.php'); ?>

<?php require_login();

  if(!isset($_SESSION['cust_id'])) {
  redirect_to(url_for('/staff/index.php'));
  }
  $cust_id = $_SESSION['cust_id'];
  $customer = find_customer_by_id($cust_id);
  $coupon_set = find_coupons_by_custid($cust_id);
  $coupon_count = mysqli_num_rows($coupon_set);
?>

<?php $page_title = 'Coupons'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
   <a class="back-link" href="<?php echo url_for('/staff/custsearch.php'); ?>">&lArr; Back to Search Index</a>
  
  <div class="coupons listing">
    <h1><?php echo name_format($customer['fname'])." ".name_format($customer['lname']). "'s Coupons"?></h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/custinfo/coupon/new.php'); ?>">Create New Coupon &rArr;</a>
    </div>

    <?php if($coupon_count == 0 ){
      $msg[] = "No coupon found.";
      echo display_messages($msg);

    } if ($coupon_count!= 0) { ?>

  	<table class="list">
  	  <tr>
        <th>Coupon No</th>
        <th>Coupon Type</th>
        <th>Discount in %</th>
        <th>Start Date</th>
        <th>Expiration Date</th>
  	    <th>Customer</th>
  	    <th>&nbsp;</th>
  	    <th>&nbsp;</th>
        <th>&nbsp;</th>
  	  </tr>

      <?php while($coupon = mysqli_fetch_assoc($coupon_set)) { ?>
      <?php $customer = find_customer_by_id($coupon['cust_id']); ?>
        <tr>
          <td><?php echo h($coupon['coupon_no']); ?></td>
          <td><?php echo $coupon['coup_type'] == 'IND' ? 'Individual' : 'Corporation'; ?></td>
          <td><?php echo h($coupon['discount']); ?></td>
          <td><?php echo h($coupon['sta_date']); ?></td>
          <td><?php echo h($coupon['exp_date']); ?></td>
    	    <td><?php echo h($customer['fname'])." " . h($customer['lname']); ?></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/coupon/show.php?id=' . h(u($coupon['coupon_no']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/coupon/edit.php?id=' . h(u($coupon['coupon_no']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/coupon/delete.php?id=' . h(u($coupon['coupon_no']))); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>

    <?php
      mysqli_free_result($coupon_set); }
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
