<?php

require_once('../../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/custinfo/custcor/index.php'));
}
$id = $_GET['id'];

if(is_post_request()) {

  // Handle form values sent by edit.php

  $custcor = [];
  $custcor['cust_id'] = $id;
  $custcor['corp_name'] = $_POST['corp_name'] ?? '';
  $custcor['register_no'] = $_POST['register_no'] ?? '';
  $custcor['emp_id'] = $_POST['emp_id'] ?? '';

  $result = update_custcor($custcor);
  if($result === true) {
    redirect_to(url_for('/staff/custinfo/custcor/show.php?id=' . $id));
  } else {
    $errors = $result;
    //var_dump($errors);
  }

} else {

  $custcor = find_custcor_by_id($id);

}

//$corporation_set = find_all_corporations();
$cust_id = $_SESSION['cust_id'];
$corporation = find_customer_by_id($cust_id);
?>

<?php $page_title = 'Edit Corporation'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custinfo/custcor/index.php'); ?>">&lArr; Back to Index</a>

  <div class="corporation edit">
    <h1>Edit Corporation</h1>

    <?php echo display_errors($errors); ?>

    <form action="" method="post">
      <dl>
        <dt>Customer Name</dt>
        <dd>
          <select name="cust_id">
          <?php
              echo "<option value=\"{$corporation['cust_id']}\"";
              if($custcor['cust_id'] == $corporation['cust_id']) {
                echo " selected";
              }
              echo ">" . h($corporation['cust_id']) . "--" . h($corporation['fname']) . " " . h($corporation['lname']). "</option>";
          ?>
          </select>
        </dd>
      </dl>
      <dl>
        <dt>Corp. Name</dt>
        <dd><input type="text" name="corp_name" value="<?php echo h($custcor['corp_name']); ?>" /></dd>
      </dl>
      <dl>
        <dt>Register Number</dt>
        <dd><input type="text" name="register_no" value="<?php echo h($custcor['register_no']); ?>" /></dd>
      </dl>
       <dl>
        <dt>Employee ID</dt>
        <dd><input type="number" name="emp_id" value="<?php echo h($custcor['emp_id']); ?>" min="0"/></dd>
      </dl>


      <div id="operations">
        <input type="submit" value="Edit Corporation" />
      </div>
    </form>

  </div>

</div>
<?php

//mysqli_free_result($corporation_set);

?>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
