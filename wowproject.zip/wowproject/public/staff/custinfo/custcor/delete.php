<?php

require_once('../../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/custinfo/custcor/index.php'));
}
$cust_id = $_GET['id'];

if(is_post_request()) {

  $result = delete_custcor($cust_id);
  redirect_to(url_for('/staff/custinfo/custcor/index.php'));

} else {
  $custcor = find_custcor_by_id($cust_id);
}

$customer = find_customer_by_id($custcor['cust_id']); 

?>

<?php $page_title = 'Delete Corporation Customer'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custinfo/custcor/index.php'); ?>">&laquo; Back to Index</a>

  <div class="Corporation delete">
    <h1>Delete Corporation Customer</h1>
    <p><h2>Are you sure you want to delete this corporation?</h2></p>
    <p class="item">
    <?php echo "<h3>Form parameters:</h3>";
            echo "Customer ID: ". h($custcor['cust_id']). "<br />" ;
            echo "Customer Name: ". h($customer['fname']). " " . h($customer['lname']). "<br />" ;   
            echo "Register No: " . h($custcor['register_no']). "<br />";
            echo "Employee ID " . h($custcor['emp_id']) . "<br />";
          ?>  
    </p>
     <br />
    <form action="<?php echo url_for('/staff/custinfo/custcor/delete.php?id=' . h(u($custcor['cust_id']))); ?>" method="post">
      <div id="operations">
        <input type="submit" name="commit" value="Delete Corporation" />
      </div>
    </form>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
