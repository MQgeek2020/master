<?php

require_once('../../../../private/initialize.php');

require_login();

if(!isset($_SESSION['cust_id'])) {
  redirect_to(url_for('/staff/index.php'));
  }
$cust_id = $_SESSION['cust_id'];

if(is_post_request()) {

  // Handle form values sent by new.php
  $invoice = [];
  $invoice['invno'] = $_POST['invno'] ?? '';
  $invoice['inv_date'] = $_POST['inv_date'] ?? '';
  $invoice['inv_amount'] = $_POST['amount'] ?? '';


  $result = insert_cust_invoice($invoice);
  if($result === true){
      //$new_id = mysqli_insert_id($db);
      $new_id = $invoice['invno'];
      redirect_to(url_for('/staff/custinfo/invoice/show.php?id=' . $new_id));
  }else{
      $errors = $result;
  }

} else {
  //display the blank form
  $invoice = [];
  $invoice['invno'] = '';
  $invoice['inv_date'] = '';
  $invoice['inv_amount'] = '';

}

$service_set = find_services_by_custid($cust_id);
$invoice_set = find_invoices_by_custid($cust_id);

?>

<?php $page_title = 'Create Invoice'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custinfo/invoice/index.php'); ?>">&lArr; Back to Index</a>

  <div class="invoice new">
    <h1>Create Invoice</h1>

     <?php echo display_errors($errors); ?>

    <form action="<?php echo url_for('/staff/custinfo/invoice/new.php'); ?>" method="post">
      <dl>
        <dt>Invoice No</dt>
        <dd>
          <select name="invno">
          <?php    foreach($service_set as $service) {
              echo "<option value=\"{$service['serv_no']}\"";
              if($invoice['invno'] == $service['serv_no']) {
                echo " selected";
              }
              echo ">{$service['serv_no']}</option>";
               }
          ?>
          </select>
        </dd>
      </dl>
      <dl>
        <dt>Invoice Date</dt>
        <dd><input type="date" name="inv_date" value="<?php echo $invoice['inv_date']; ?>" /></dd>
      </dl>
       <dl>
        <dt>Invoice Amount</dt>
        <dd><input type="number" name="amount" value="<?php echo $custcor['inv_amount']; ?>" min="0" step="0.01"/></dd>   /$
      </dl>
     
      <div id="operations">
        <input type="submit" value="Create Invoice" />
      </div>
    </form>

  </div>


     <?php
      mysqli_free_result($service_set);
      mysqli_free_result($invoice_set); 
    ?>
</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
