<?php require_once('../../../../private/initialize.php'); ?>

<?php

  require_login();
  
  //$invoice_set = find_all_invoices();

  if(!isset($_SESSION['cust_id'])) {
  redirect_to(url_for('/staff/index.php'));
  }
  $cust_id = $_SESSION['cust_id'];
  $customer = find_customer_by_id($cust_id);
  $fname = name_format($customer['fname']);
  $lname = name_format($customer['lname']);
  $invoice_set = find_invoices_by_custid($cust_id);
  $invoice_count = mysqli_num_rows($invoice_set);
?>

<?php $page_title = 'Invoices'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custsearch.php'); ?>">&lArr; Back to Search Index</a>
  
  <div class="invoices listing">
    <h1><?php echo h(u($fname)) . " " . h(u($lname)). "'s Invoices"?></h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/custinfo/invoice/new.php'); ?>">Create New Invoice &rArr;</a>
    </div>

    <?php if($invoice_count == 0 ){
      $msg[] = "No invoice found.";
      echo display_messages($msg);

    } if ($invoice_count!= 0) { ?>

  	<table class="list">
  	  <tr>
        <th>Invoice No.</th>
        <th>Invoice Date</th>
        <th>Amount</th>
  	    <th>&nbsp;</th>
  	    <th>&nbsp;</th>
        <th>&nbsp;</th>
  	  </tr>

      <?php while($invoice = mysqli_fetch_assoc($invoice_set)){ ?>
        <tr>
          <td><?php echo h($invoice['invno']); ?></td>
          <td><?php echo h($invoice['inv_date']); ?></td>
    	    <td><?php echo h($invoice['inv_amount']); ?></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/invoice/show.php?id=' . h(u($invoice['invno']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/invoice/edit.php?id=' . h(u($invoice['invno']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/invoice/delete.php?id=' . h(u($invoice['invno']))); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>
    <?php
      mysqli_free_result($invoice_set); }
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
