<?php

require_once('../../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/custinfo/invoice/index.php'));
}
$invno = $_GET['id'];

if(is_post_request()) {

  $result = delete_invoice($invno);
  redirect_to(url_for('/staff/custinfo/invoice/index.php'));

} else {
  $invoice = find_invoice_by_id($invno);
}

?>

<?php $page_title = 'Delete invoice'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custinfo/invoice/index.php'); ?>">&lArr; Back to Index</a>

  <div class="invoice delete">
    <h1>Delete Invoice</h1>
    <p><h2>Are you sure you want to delete this invoice?</h2></p>
    <p class="item">
      <?php echo "<h3>Form parameters:</h3>";
            echo "Invoice No: " . h($invoice['invno']) . "<br />";
            echo "Invoice Date: " . h($invoice['inv_date']) . "<br />";
            echo "Invoice Amount: " . h($invoice['inv_amount']) . " $" . "<br />";
       ?> 
    </p>
    <br/>
    <form action="<?php echo url_for('/staff/custinfo/invoice/delete.php?id=' . h(u($invoice['invno']))); ?>" method="post">
      <div id="operations">
        <input type="submit" name="commit" value="Delete invoice" />
      </div>
    </form>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
