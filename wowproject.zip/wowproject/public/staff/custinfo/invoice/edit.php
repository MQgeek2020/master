<?php

require_once('../../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/custinfo/invoice/index.php'));
}
$id = $_GET['id'];

if(is_post_request()) {

  // Handle form values sent by edit.php

  $invoice = [];
  $invoice['invno'] = $id;
  $invoice['inv_date'] = $_POST['inv_date'] ?? '';
  $invoice['inv_amount'] = $_POST['amount'] ?? '';

  $result = update_invoice($invoice);
  if($result === true) {
     redirect_to(url_for('/staff/custinfo/invoice/show.php?id=' . $id));
  } else {
    $errors = $result;
    //var_dump($errors);
  }

} else {

  $invoice = find_invoice_by_id($id);

}

?>

<?php $page_title = 'Edit Invoice'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custinfo/invoice/index.php'); ?>">&lArr; Back to Index</a>

  <div class="invoice edit">
    <h1>Edit Invoice</h1>
    <?php echo display_errors($errors); ?>

    <form action="" method="post">
      <dl>
        <dt>Invoice Date</dt>
        <dd><input type="date" name="inv_date" value="<?php echo h($invoice['inv_date']); ?>" /></dd>
      </dl>
      <dl>
        <dt>Invoice Amount</dt>
        <dd><input type="number" name="amount" value="<?php echo h($invoice['inv_amount']) ; ?>" min="0" step="0.01"/></dd>    /$
      </dl>
      
      
      <div id="operations">
        <input type="submit" value="Edit Invoice" />
      </div>
    </form>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
