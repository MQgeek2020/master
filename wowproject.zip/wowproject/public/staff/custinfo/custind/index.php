<?php require_once('../../../../private/initialize.php'); ?>

<?php

  //$custind_set = find_all_custinds();
  if(!isset($_SESSION['cust_id'])) {
  redirect_to(url_for('/staff/index.php'));
  }

  $cust_id = $_SESSION['cust_id'];

  $individual = find_custind_by_id($cust_id);
?>

<?php $page_title = 'IndividualCustomers'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custsearch.php'); ?>">&lArr; Back to Search Index</a>

  <div class="Individuals listing">
    <h1>Individual Details</h1>

  	<table class="list">
  	  <tr>
        <th>Customer ID</th>
        <th>Individual Name</th>
  	    <th>Driver License Number</th>
        <th>Insurance Company Name</th>
        <th>Insurance Policy Number</th>
  	    <th>&nbsp;</th>
  	    <th>&nbsp;</th>
        <th>&nbsp;</th>
  	  </tr>

      <?php //while($individual = mysqli_fetch_assoc($custind_set)) { ?>
        <?php $customer = find_customer_by_id($individual['cust_id']); ?>
        <tr>
          <td><?php echo h($individual['cust_id']); ?></td>
          <td><?php echo h($customer['fname']). " " . h($customer['lname']); ?></td>
          <td><?php echo h($individual['DLN']); ?></td>
          <td><?php echo h($individual['INSCN']); ?></td>
          <td><?php echo h($individual['INSPN']); ?></td>
          
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/custind/show.php?id=' . h(u($individual['cust_id']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/custind/edit.php?id=' . h(u($individual['cust_id']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/custind/delete.php?id=' . h(u($individual['cust_id']))); ?>">Delete</a></td>
    	  </tr>
      <?php //} ?>
  	</table>
    <?php
      //mysqli_free_result($custind_set);
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
