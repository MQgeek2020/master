
<?php

require_once('../../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/custinfo/customer/index.php'));
}
$id = $_GET['id'];

if(is_post_request()) {

  // Handle form values sent by edit.php

  $customer = [];
  $customer['cust_id'] = $id;
  $customer['cust_type'] = $_POST['cust_type'] ?? '';
  $customer['fname'] = $_POST['fname'] ?? '';
  $customer['lname'] = $_POST['lname'] ?? '';
  $customer['state'] = $_POST['state'] ?? '';
  $customer['city'] = $_POST['city'] ?? '';
  $customer['st_addr'] = $_POST['street'];
  $customer['apt'] = $_POST['apartment'] ?? '';
  $customer['zipcode'] = $_POST['zipcode'] ?? '';
  $customer['email'] = $_POST['email'] ?? '';
  $customer['phone'] = $_POST['phone'];
 
  $result = update_customer($customer);
  if($result === true) {
    redirect_to(url_for('/staff/custinfo/customer/show.php?id=' . $id));
  } else {
    $errors = $result;
    //var_dump($errors);
  }

} else {

  $customer = find_customer_by_id($id);

}
?>

<?php $page_title = 'Edit Customer'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custinfo/customer/index.php'); ?>">&lArr; Back to List</a>

  <div class="customer edit">
    <h1>Edit Profile</h1>

    <?php echo display_errors($errors); ?>

    <form action="" method="post">
     
     <dl>
        <dt>CustType</dt>
        <dd>
          <input type="radio" name="cust_type" value="I" <?php if (h($customer['cust_type'])!== null && h($customer['cust_type'])=="I") echo "checked";?>>Individual<br>
          <input type="radio" name="cust_type" value="C" <?php if (h($customer['cust_type'])!== null && h($customer['cust_type'])=="C") echo "checked";?>>Corporation 
        </dd>
      </dl>
      <dl>
        <dl>
        <dt>First Name:</dt>
        <dd><input type="text" name="fname" value="<?php echo h($customer['fname']); ?>" /></dd>
      </dl>
      <dl>
        <dt>Last Name</dt>
        <dd><input type="text" name="lname" value="<?php echo h($customer['lname']); ?>" /></dd>
      </dl>
        <dt>State</dt>
        <dd><input type="text" name="state" value="<?php echo h($customer['state']); ?>" /></dd>
      </dl>
      <dl>
        <dt>City</dt>
        <dd><input type="text" name="city" value="<?php echo h($customer['city']); ?>" /></dd>
      </dl>
       <dl>
        <dt>Street</dt>
        <dd><input type="text" name="street" value="<?php echo h($customer['st_addr']); ?>" /></dd>
      </dl>
       <dl>
        <dt>Apartment</dt>
        <dd><input type="text" name="apartment" value="<?php echo h($customer['apt']); ?>" /></dd>(Optional)
      </dl>
       <dl>
        <dt>Zipcode</dt>
        <dd><input type="number" name="zipcode" value="<?php echo h($customer['zipcode']); ?>" min="0"/></dd>
      </dl>
      <dl>
        <dt>Email</dt>
        <dd><input type="email" name="email" value="<?php echo h($customer['email']); ?>" /></dd>
      </dl>
      <dl>
        <dt>Phone</dt>
        <dd><input type="text" name="phone" value="<?php echo h($customer['phone']); ?>" /></dd>
      </dl>
      
      
      <div id="operations">
        <input type="submit" value="Edit Customer" />
      </div>
    </form>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
