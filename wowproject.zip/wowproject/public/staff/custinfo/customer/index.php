<?php require_once('../../../../private/initialize.php'); ?>

<?php

  require_login();
  if(!isset($_SESSION['cust_id'])) {
  redirect_to(url_for('/staff/index.php'));
  }
  $cust_id = $_SESSION['cust_id'];

  $customer = find_customer_by_id($cust_id);

?>

<?php $page_title = 'Customers'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custsearch.php'); ?>">&lArr; Back to Search Index</a>

  <div class="customers listing">
    <h1><?php echo name_format($customer['fname']) . " " . name_format($customer['lname']). "'s Profile"?></h1>


  	<table class="list">
  	  <tr>
        <th>ID</th>
        <th>CustType</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>State</th>
  	    <th>City</th>
        <th>Street</th>
        <th>Apartment</th>
        <th>Zipcode</th>
        <th>Email</th>
        <th>Phone</th>
  	    <th>&nbsp;</th>
  	    <th>&nbsp;</th>
        <th>&nbsp;</th>
  	  </tr>

      <?php //while($customer = mysqli_fetch_assoc($customer_set)) { ?>
        <tr>
          <td><?php echo h($customer['cust_id']); ?></td>
          <td><?php echo h($customer['cust_type']) == 'I' ? 'Individual' : 'Corporation'; ?></td>
          <td><?php echo h($customer['fname']); ?></td>
          <td><?php echo h($customer['lname']); ?></td>
          <td><?php echo h($customer['state']); ?></td>
          <td><?php echo h($customer['city']); ?></td>
          <td><?php echo h($customer['st_addr']); ?></td>
          <td><?php echo h($customer['apt']) == 0 ? 'NULL' : h($customer['apt']); ?></td>
          <td><?php echo h($customer['zipcode']); ?></td>
          <td><?php echo h($customer['email']); ?></td>
          <td><?php echo h($customer['phone']); ?></td>
          
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/customer/show.php?id=' . h(u($customer['cust_id']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/customer/edit.php?id=' . h(u($customer['cust_id']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/customer/delete.php?id=' . h(u($customer['cust_id']))); ?>">Delete</a></td>
    	  </tr>
      <?php //} ?>
  	</table>
    <?php
     //mysqli_free_result($customer_set);
     ?>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
