<?php require_once('../../../../private/initialize.php'); ?>

<?php

  require_login();
  
  //$service_set = find_all_services();

  if(!isset($_SESSION['cust_id'])) {
  redirect_to(url_for('/staff/index.php'));
  }
  $cust_id = $_SESSION['cust_id'];
  $customer = find_customer_by_id($cust_id);
  $service_set = find_services_by_custid($cust_id);
  $service_count = mysqli_num_rows($service_set);
?>

<?php $page_title = 'Servicess'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
  <a class="back-link" href="<?php echo url_for('/staff/custsearch.php'); ?>">&lArr; Back to Search Index</a>

  <div class="services listing">
    <h1><?php echo name_format($customer['fname'])." " . name_format($customer['lname']). "'s Services"?></h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/custinfo/service/new.php'); ?>">Create New Service &rArr;</a>
    </div>

    <?php if($service_count == 0 ){
      $msg[] = "No service found.";
      echo display_messages($msg);

    } elseif ($service_count!= 0) { ?>

  	<table class="list">
  	  <tr>
        <th>Service No</th>
        <th>Scheduled Time</th>
        <th>Pickup Date</th>
  	    <th>Droff Date</th>
        <th>Start Odometer</th>
        <th>End Odometer</th>
        <th>Daily Odolimit</th>
        <th>Pickup Location</th>
        <th>Dropoff Location</th>
        <th>Vehicle ID</th>
        <th>Customer Name</th>
        <th>Invoice No</th>
        <th>Coupon No</th>
  	    <th>&nbsp;</th>
  	    <th>&nbsp;</th>
        <th>&nbsp;</th>
  	  </tr>

      <?php while($service = mysqli_fetch_assoc($service_set)) { ?>
        <?php $customer = find_customer_by_id($service['cust_id']); ?>
        <tr>
          <td><?php echo h($service['serv_no']); ?></td>
          <td><?php echo h($service['sche_time']); ?></td>
    	    <td><?php echo h($service['pickup_date']); ?></td>
          <td><?php echo h($service['droff_date']); ?></td>
          <td><?php echo h($service['sta_odo']); ?></td>
          <td><?php echo h($service['end_odo']); ?></td>
          <td><?php echo h($service['odolimit']); ?></td>
          <td><?php echo h($service['pickup_loc']); ?></td>
          <td><?php echo h($service['droff_loc']); ?></td>
          <td><?php echo h($service['veh_id']); ?></td>
          <td><?php echo h($customer['fname']. " ". h($customer['lname'])); ?></td>
          <td><?php echo h($service['invno']); ?></td>
          <td><?php echo h($service['coupon_no']) == 0 ? 'NULL' : h($service['coupon_no']); ?></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/service/show.php?id=' . h(u($service['serv_no']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/service/edit.php?id=' . h(u($service['serv_no']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custinfo/service/delete.php?id=' . h(u($service['serv_no']))); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>

     <?php
      mysqli_free_result($service_set); }
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
