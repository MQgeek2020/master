<?php require_once('../../../private/initialize.php'); ?>

<?php

require_login();

$id = $_GET['id'] ?? '1';

$service = find_service_by_id($id);
?>

<?php $page_title = 'Show Service'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <div class="service show">
    <a class="back-link" href="<?php echo url_for('/staff/service/index.php'); ?>">&laquo; Back to List</a>
    <?php $customer = find_customer_by_id($service['cust_id']); ?>

  	<h1>Service No: <?php echo h($service['serv_no']); ?></h1>

  	<div class="attributes">
      <dl>
        <dt>Customer Name</dt>
        <dd><?php echo name_format(h($customer['fname'])) . "  ". name_format(h($customer['lname'])); ?></dd>
      </dl>
      <dl>
        <dt>Scheduled Time</dt>
        <dd><?php echo h($service['sche_time']); ?></dd>
      </dl>
      <dl>
        <dt>Pickup Date</dt>
        <dd><?php echo h($service['pickup_date']); ?></dd>
      </dl>
      <dl>
        <dt>Dropoff Date</dt>
        <dd><?php echo h($service['droff_date']); ?></dd>
      </dl>
      <dl>
        <dt>Start Odometer</dt>
        <dd><?php echo h($service['sta_odo']) . "  miles"; ?></dd>
      </dl>
      <dl>
        <dt>End Odometer</dt>
        <dd><?php echo h($service['end_odo']) . "  miles"; ?></dd>
      </dl>
      <dl>
        <dt>Daily limit</dt>
        <dd><?php echo h($service['odolimit']). "   miles/day"; ?></dd>
      </dl>
      <dl>
        <dt>Pickup Location</dt>
        <dd><?php echo h($service['pickup_loc']); ?></dd>
      </dl>
      <dl>
        <dt>Dropoff Location</dt>
        <dd><?php echo h($service['droff_loc']); ?></dd>
      </dl>
      <dl>
        <dt>Vehicle ID</dt>
        <dd><?php echo h($service['veh_id']); ?></dd>
      </dl>
       <dl>
        <dt>Invoice No</dt>
        <dd><?php echo h($service['invno']); ?></dd>
      </dl>
       <dl>
        <dt>Coupon No</dt>
        <dd><?php echo h($service['coupon_no']) == 0 ? 'NULL' : h($service['coupon_no']); ?></dd>
      </dl>

    </div>


  </div>

</div>
<?php include(SHARED_PATH . '/staff_footer.php'); ?>