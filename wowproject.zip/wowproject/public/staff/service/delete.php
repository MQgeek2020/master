 <?php

require_once('../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/service/index.php'));
}
$serv_no = $_GET['id'];

if(is_post_request()) {

  $result = delete_service($serv_no);
  redirect_to(url_for('/staff/service/index.php'));

} else {
  $service = find_service_by_id($serv_no);
}


$customer = find_customer_by_id($service['cust_id']); 

?>

<?php $page_title = 'Delete Service'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/service/index.php'); ?>">&laquo; Back to List</a>

  <div class="service delete">
    <h1>Delete Service</h1>
    <p><h2>Are you sure you want to delete this service?</h2></p>
    <p class="item">
      <?php echo "<h3>Form parameters:</h3>";
            echo "Service No: " . h($service['serv_no']) . "<br />";
            echo "Customer Name: ". name_format(h($customer['fname'])). " " . name_format(h($customer['lname'])). "<br />" ;
            echo "Scheduled Time: " . h($service['sche_time']) . "<br />";
            echo "Pickup Date: " . h($service['pickup_date']) . "<br />";
            echo "Dropoff Date: " . h($service['droff_date']) . "<br />";
            echo "Start Odolimit: " . h($service['sta_odo']) . "   /mile" .  "<br />";
            echo "End Odolimit: " . h($service['end_odo']) . "   /mile" . "<br />";
            echo "Odolimit: " . h($service['odolimit']) . "  mile/day" . "<br />";
            echo "Pickup Location: " . h($service['pickup_loc']) . "<br />";
            echo "Dropoff Location: " . h($service['droff_loc']) . "<br />";
            echo "Vehicle ID: " . h($service['veh_id']) . "<br />";
            echo "Customer ID: " . h($service['cust_id']) . "<br />";
            echo "Invoice No: " . h($service['invno']) . "<br />";
            echo "Coupon No: " . h($service['coupon_no']) . "<br />";

      ?>
      </p>
     <br />
    <form action="<?php echo url_for('/staff/service/delete.php?id=' . h(u($service['serv_no']))); ?>" method="post">
      <div id="operations">
        <input type="submit" name="commit" value="Delete Service" />
      </div>
    </form>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
