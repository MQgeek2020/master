<?php require_once('../../../private/initialize.php'); ?>

<?php  require_login();


$id = $_GET['id'] ?? '1';

$custcor = find_custcor_by_id($id);

?>

<?php $page_title = 'Show Corporation Customer'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custcor/index.php'); ?>">&laquo; Back to List</a>

  <div class="Corporation show">
    <?php $customer = find_customer_by_id($custcor['cust_id']); ?>

    <h1>Customer ID: <?php echo h($custcor['cust_id']); ?></h1>

    <div class="attributes">
      <dl>
        <dt>Customer Name</dt>
        <dd><?php echo h($customer['fname']) . " " . h($customer['lname']); ?></dd>
      </dl>
       <dl>
        <dt>Corp. Name</dt>
        <dd><?php echo h($custcor['corp_name']); ?></dd>
      </dl>
      <dl>
        <dt>Register Number</dt>
        <dd><?php echo h($custcor['register_no']); ?></dd>
      </dl>
       <dl>
        <dt>Employee ID</dt>
        <dd><?php echo h($custcor['emp_id']); ?></dd>
      </dl>
  </div>

  </div>

</div>
<?php include(SHARED_PATH . '/staff_footer.php'); ?>