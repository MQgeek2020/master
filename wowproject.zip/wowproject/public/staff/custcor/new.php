<?php

require_once('../../../private/initialize.php');

require_login();

if(is_post_request()) {

  // Handle form values sent by new.php

  $custcor = [];
  $custcor['cust_id'] = $_POST['cust_id'] ?? '';
  $custcor['corp_name'] = $_POST['corp_name'] ?? '';
  $custcor['register_no'] = $_POST['register_no'] ?? '';
  $custcor['emp_id'] = $_POST['emp_id'] ?? '';

  $result = insert_custcor($custcor);
  if($result === true){
      $new_id = mysqli_insert_id($db);
      redirect_to(url_for('/staff/custcor/show.php?id=' . $new_id));
  }else{
      $errors = $result;
  }

} else {
  //display the blank form
  $custcor = [];
  $custcor['cust_id'] = '';
  $custcor['corp_name'] =  '';
  $custcor['register_no'] = '';
  $custcor['emp_id'] =  '';

}

$corporation_set = find_all_corporations();

?>

<?php $page_title = 'Create New Corporation'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custcor/index.php'); ?>">&laquo; Back to List</a>

  <div class="Corporation new">
    <h1>Create Corporation</h1>

     <?php echo display_errors($errors); ?>

    <form action="<?php echo url_for('/staff/custcor/new.php'); ?>" method="post">
      <dl>
        <dt>Customer Name</dt>
        <dd>
          <select name="cust_id">
          <?php
            foreach($corporation_set as $corporation) {
              echo "<option value=\"{$corporation['cust_id']}\"";
              if($custcor['cust_id'] == $corporation['cust_id']) {
                echo " selected";
              }
              echo ">" . h($corporation['cust_id']) . "--" . h($corporation['fname'])." " . h($corporation['lname']). "</option>";
            }
          ?>
          </select>
        </dd>
      </dl>
      <dl>
        <dt>Corp. Name</dt>
        <dd><input type="text" name="corp_name" value="<?php echo $custcor['corp_name']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Register Number</dt>
        <dd><input type="text" name="register_no" value="<?php echo $custcor['register_no']; ?>" /></dd>
      </dl>
       <dl>
        <dt>Employee ID</dt>
        <dd><input type="number" name="emp_id" value="<?php echo $custcor['emp_id']; ?>" min="0"/></dd>
      </dl>

      <div id="operations">
        <input type="submit" value="Create New Corporation" />
      </div>
    </form>

  </div>
</div>
<?php

/*
     <dl>
        <dt>Customer ID</dt>
        <dd><input type="number" name="cust_id" value="<?php echo $custcor['cust_id']; ?>" min="0"/></dd>
      </dl>


*/
      
mysqli_free_result($corporation_set);

?>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
