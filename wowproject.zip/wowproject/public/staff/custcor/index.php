<?php require_once('../../../private/initialize.php'); ?>

<?php  

  require_login();

  $custcor_set = find_all_custcors();
?>

<?php $page_title = 'Corporations'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

   <a class="action" href="<?php echo url_for('/staff/index.php'); ?>"> &laquo; Back to Main Menu</a>

  <div class="corporations listing">
    <h1>Corporations</h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/custcor/new.php'); ?>">Create New Corporation</a>
    </div>

  	<table class="list">
  	  <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Corporation</th>
        <th>Register Number</th>
  	    <th>Employee ID</th>
  	    <th>&nbsp;</th>
  	    <th>&nbsp;</th>
        <th>&nbsp;</th>
  	  </tr>

      <?php while($corporation = mysqli_fetch_assoc($custcor_set)) { ?>
      <?php $customer = find_customer_by_id($corporation['cust_id']); ?>
        <tr>
          <td><?php echo h($corporation['cust_id']); ?></td>
          <td><?php echo h($customer['fname']) . " " . h($customer['lname']); ?></td>
          <td><?php echo h($corporation['corp_name']); ?></td>
          <td><?php echo h($corporation['register_no']); ?></td>
    	    <td><?php echo h($corporation['emp_id']); ?></td>
          <td><a class="action" href="<?php echo url_for('/staff/custcor/show.php?id=' . h(u($corporation['cust_id']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custcor/edit.php?id=' . h(u($corporation['cust_id']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custcor/delete.php?id=' . h(u($corporation['cust_id']))); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>
    <?php
      mysqli_free_result($custcor_set);
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
