<?php require_once('../../private/initialize.php'); ?>

<?php require_login(); 

if(!isset($_SESSION['cust_id'])) {
  redirect_to(url_for('/staff/index.php'));
}
$cust_id = $_SESSION['cust_id'];
$customer = find_customer_by_id($cust_id);
$cust_type = $customer['cust_type'];

if($cust_type == "I"){ 

  $custind = find_custind_by_custid($cust_id);
  $custind_count = mysqli_num_rows($custind);

} if ($cust_type == "C"){
  
  $custcor = find_custcor_by_custid($cust_id);
  $custcor_count = mysqli_num_rows($custcor);
}

?>

<?php $page_title = 'Staff Menu'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>


<div id="content">
   <a class="back-link" href="<?php echo url_for('/staff/index.php'); ?>">&lArr; Back to Main Menu</a>
  <div id="main-menu">
    <h2>Customer Info</h2>
    <p class="item"><?php 
        echo "<h3>Customer ID: " . h(u($cust_id)) . "<br />";
        echo "Customer Name: " . name_format(h($customer['fname'])) . " " . name_format(h($customer['lname'])). "<br />";
        echo "Customer Type: " . (h(u($cust_type))=="I" ? "Individual" : "Corporation") . "<h3><br />";
    ?></p>
    <ul>
      <li><a href="<?php echo url_for('/staff/custinfo/cust_admins/index.php'); ?>">Admin</a></li>
      <li><a href="<?php echo url_for('/staff/custinfo/customer/index.php'); ?>">Profile</a></li>
      <?php if(($cust_type == "I") && ($custind_count!=0)) {   ?>
      <li><a href="<?php echo url_for('/staff/custinfo/custind/index.php'); ?>">Individual</a></li>
     <?php } elseif(($cust_type == "C") && ($custcor_count!=0)) {   ?>
      <li><a href="<?php echo url_for('/staff/custinfo/custcor/index.php'); ?>">Corporation</a></li>
    <?php } ?>
      <li><a href="<?php echo url_for('/staff/custinfo/coupon/index.php'); ?>">Coupon</a></li>
      <li><a href="<?php echo url_for('/staff/custinfo/payment/index.php'); ?>">Payment</a></li>
      <li><a href="<?php echo url_for('/staff/custinfo/service/index.php'); ?>">Service</a></li>
      <li><a href="<?php echo url_for('/staff/custinfo/invoice/index.php'); ?>">Invoice</a></li>
      <li><a href="<?php echo url_for('/staff/custinfo/invpay/index.php'); ?>">InvoicePayStatus</a></li>
      

    </ul>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
