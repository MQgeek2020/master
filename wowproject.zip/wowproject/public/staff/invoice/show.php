<?php require_once('../../../private/initialize.php'); ?>

<?php 

require_login();

$id = $_GET['id'] ?? '1'; 

$invoice = find_invoice_by_id($id)
?>

<?php $page_title = 'Show Invoice'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/invoice/index.php'); ?>">&laquo; Back to List</a>

  <div class="Invoice show">

    <h1>Invoice No: <?php echo h($invoice['invno']); ?></h1>

    <div class="attributes">

      <dl>
        <dt>Invoice Date</dt>
        <dd><?php echo h($invoice['inv_date']); ?></dd>
      </dl>
      <dl>
        <dt>Invoice Amount</dt>
        <dd><?php echo h($invoice['inv_amount'])."  $"; ?></dd>   
      </dl>


   </div>

  </div>

</div>
<?php include(SHARED_PATH . '/staff_footer.php'); ?>