<?php require_once('../../../private/initialize.php'); ?>

<?php

  require_login();
  
  $invoice_set = find_all_invoices();
?>

<?php $page_title = 'Invoices'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

 <a class="action" href="<?php echo url_for('/staff/index.php'); ?>"> &laquo; Back to Main Menu</a>
  
  <div class="invoices listing">
    <h1>Invoices</h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/invoice/new.php'); ?>">Create New Invoice</a>
    </div>

  	<table class="list">
  	  <tr>
        <th>Invoice No.</th>
        <th>Invoice Date</th>
        <th>Amount</th>
  	    <th>&nbsp;</th>
  	    <th>&nbsp;</th>
        <th>&nbsp;</th>
  	  </tr>

      <?php while($invoice = mysqli_fetch_assoc($invoice_set)){ ?>
        <tr>
          <td><?php echo h($invoice['invno']); ?></td>
          <td><?php echo h($invoice['inv_date']); ?></td>
    	    <td><?php echo h($invoice['inv_amount']); ?></td>
          <td><a class="action" href="<?php echo url_for('/staff/invoice/show.php?id=' . h(u($invoice['invno']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/invoice/edit.php?id=' . h(u($invoice['invno']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/invoice/delete.php?id=' . h(u($invoice['invno']))); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>
    <?php
      mysqli_free_result($invoice_set);
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
