<?php

require_once('../../../private/initialize.php');

require_login();

if(is_post_request()) {

  // Handle form values sent by new.php
  $invoice = [];
  $invoice['inv_date'] = $_POST['inv_date'] ?? '';
  $invoice['inv_amount'] = $_POST['amount'] ?? '';


  $result = insert_invoice($invoice);
  if($result === true){
      $new_id = mysqli_insert_id($db);
      redirect_to(url_for('/staff/invoice/show.php?id=' . $new_id));
  }else{
      $errors = $result;
  }

} else {
  //display the blank form
  $invoice = [];
  $invoice['inv_date'] = '';
  $invoice['inv_amount'] = '';

}

?>

<?php $page_title = 'Create Invoice'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/invoice/index.php'); ?>">&laquo; Back to List</a>

  <div class="invoice new">
    <h1>Create Invoice</h1>

     <?php echo display_errors($errors); ?>

    <form action="<?php echo url_for('/staff/invoice/new.php'); ?>" method="post">
      <dl>
        <dt>Invoice Date</dt>
        <dd><input type="date" name="inv_date" value="<?php echo $invoice['inv_date']; ?>" /></dd>
      </dl>
       <dl>
        <dt>Invoice Amount</dt>
        <dd><input type="number" name="amount" value="<?php echo $custcor['inv_amount']; ?>" min="0" step="0.01"/></dd>   /$
      </dl>
     
      <div id="operations">
        <input type="submit" value="Create Invoice" />
      </div>
    </form>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
