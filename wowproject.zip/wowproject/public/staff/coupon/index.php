<?php require_once('../../../private/initialize.php'); ?>

<?php require_login();

  $coupon_set = find_all_coupons();
?>

<?php $page_title = 'Coupons'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

   <a class="action" href="<?php echo url_for('/staff/index.php'); ?>"> &laquo; Back to Main Menu</a>
   
  <div class="coupons listing">
    <h1>Coupons</h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/coupon/new.php'); ?>">Create New Coupon</a>
    </div>

  	<table class="list">
  	  <tr>
        <th>Coupon No</th>
        <th>Coupon Type</th>
        <th>Discount in %</th>
        <th>Start Date</th>
        <th>Expiration Date</th>
  	    <th>Customer</th>
  	    <th>&nbsp;</th>
  	    <th>&nbsp;</th>
        <th>&nbsp;</th>
  	  </tr>

      <?php while($coupon = mysqli_fetch_assoc($coupon_set)) { ?>
      <?php $customer = find_customer_by_id($coupon['cust_id']); ?>
        <tr>
          <td><?php echo h($coupon['coupon_no']); ?></td>
          <td><?php echo $coupon['coup_type'] == 'IND' ? 'Individual' : 'Corporation'; ?></td>
          <td><?php echo h($coupon['discount']); ?></td>
          <td><?php echo h($coupon['sta_date']); ?></td>
          <td><?php echo h($coupon['exp_date']); ?></td>
    	    <td><?php echo h($customer['fname'])." " . h($customer['lname']); ?></td>
          <td><a class="action" href="<?php echo url_for('/staff/coupon/show.php?id=' . h(u($coupon['coupon_no']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/coupon/edit.php?id=' . h(u($coupon['coupon_no']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/coupon/delete.php?id=' . h(u($coupon['coupon_no']))); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>

    <?php
      mysqli_free_result($coupon_set);
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
