<?php

require_once('../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/coupon/index.php'));
}
$coupon_no = $_GET['id'];

if(is_post_request()) {

  $result = delete_coupon($coupon_no);
  redirect_to(url_for('/staff/coupon/index.php'));

} else {
  $coupon = find_coupon_by_id($coupon_no);
}

$customer = find_customer_by_id($coupon['cust_id']); 

?>

<?php $page_title = 'Delete Coupon'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/coupon/index.php'); ?>">&laquo; Back to List</a>

  <div class="coupon delete">

    <h1>Delete Coupon</h1>
    <p><h2>Are you sure you want to delete this coupon?</h2></p>
    <p class="item">
      <?php echo "<h3>Form parameters:</h3>";
            echo "Coupon No: ". h($coupon['coupon_no']). "<br />" ; 
            echo "Coupon Type: " . (h($coupon['coup_type'])=="IND" ? "Individual" : "Corporation"). "<br />";
            echo "Discount: " . h($coupon['discount']) . " %". "<br />";
            echo "Start Date: " . h($coupon['sta_date']) . "<br />";
            echo "Exp. Date: " . h($coupon['exp_date']) . "<br />";
            //echo "Used Date: " . h($coupon['usedate']) . "<br />";
            echo "Customer ID: " . h($coupon['cust_id']). "<br />";
            echo "Customer Name: ". h($customer['fname']). " " . h($customer['lname']). "<br />" ; 
          ?>    
    </p>
    <br/>
    <form action="<?php echo url_for('/staff/coupon/delete.php?id=' . h(u($coupon['coupon_no']))); ?>" method="post">
      <div id="operations">
        <input type="submit" name="commit" value="Delete Coupon" />
      </div>
    </form>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
