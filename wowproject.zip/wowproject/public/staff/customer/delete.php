<?php

require_once('../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/customer/index.php'));
}
$cust_id = $_GET['id'];

if(is_post_request()) {

  $result = delete_customer($cust_id);
  redirect_to(url_for('/staff/customer/index.php'));

} else {
  $customer = find_customer_by_id($cust_id);
}

?>

<?php $page_title = 'Delete Customer'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/customer/index.php'); ?>">&laquo; Back to List</a>

  <div class="customer delete">
    <h1>Delete Customer</h1>
    <p><h2>Are you sure you want to delete this customer?</h2></p>
    <p class="item">
       <?php echo "<h3>Form parameters:</h3>";
            echo "Customer ID: " . h($customer['cust_id']). "<br />"; 
            echo "Customer Type: " . (h($customer['cust_type'])=="I" ? "Individual" : "Corporation") . "<br />"; 
            echo "First Name: " . h($customer['fname']) .  "<br />";
            echo "Last Name: " . h($customer['lname']) . "<br />";
            echo "State: " . h($customer['state']) . "<br />";
            echo "City: " . h($customer['city']) . "<br />";
            echo "Street: " . h($customer['st_addr']) . "<br />";
            echo "Apartment: " . h($customer['apt']) . "<br />";
            echo "Zipcode: " . h($customer['zipcode']) . "<br />";
            echo "Email: " . h($customer['email']) . "<br />";
            echo "Phone: " . h($customer['phone']) . "<br />";
          ?>    
       </p>
    <br/>
    <form action="<?php echo url_for('/staff/customer/delete.php?id=' . h(u($customer['cust_id']))); ?>" method="post">
      <div id="operations">
        <input type="submit" name="commit" value="Delete Customer" />
      </div>
    </form>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
