<?php require_once('../../../private/initialize.php'); ?>

<?php

  require_login();
  
  $customer_set = find_all_customers();
?>

<?php $page_title = 'Customers'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="action" href="<?php echo url_for('/staff/index.php'); ?>"> &laquo; Back to Main Menu</a>

  <div class="customers listing">
    <h1>Customers</h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/customer/new.php'); ?>">Create New Customer</a>
    </div>

  	<table class="list">
  	  <tr>
        <th>ID</th>
        <th>CustType</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>State</th>
  	    <th>City</th>
        <th>Street</th>
        <th>Apartment</th>
        <th>Zipcode</th>
        <th>Email</th>
        <th>Phone</th>
  	    <th>&nbsp;</th>
  	    <th>&nbsp;</th>
        <th>&nbsp;</th>
  	  </tr>

      <?php while($customer = mysqli_fetch_assoc($customer_set)) { ?>
        <tr>
          <td><?php echo h($customer['cust_id']); ?></td>
          <td><?php echo h($customer['cust_type']) == 'I' ? 'Individual' : 'Corporation'; ?></td>
          <td><?php echo h($customer['fname']); ?></td>
          <td><?php echo h($customer['lname']); ?></td>
          <td><?php echo h($customer['state']); ?></td>
          <td><?php echo h($customer['city']); ?></td>
          <td><?php echo h($customer['st_addr']); ?></td>
          <td><?php echo h($customer['apt']) == 0 ? 'NULL' : h($customer['apt']); ?></td>
          <td><?php echo h($customer['zipcode']); ?></td>
          <td><?php echo h($customer['email']); ?></td>
          <td><?php echo h($customer['phone']); ?></td>
          
          <td><a class="action" href="<?php echo url_for('/staff/customer/show.php?id=' . h(u($customer['cust_id']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/customer/edit.php?id=' . h(u($customer['cust_id']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/customer/delete.php?id=' . h(u($customer['cust_id']))); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>
    <?php
     mysqli_free_result($customer_set);
     ?>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
