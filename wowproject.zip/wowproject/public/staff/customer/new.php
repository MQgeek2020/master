<?php

require_once('../../../private/initialize.php');

require_login();

if(is_post_request()) {

  // Handle form values sent by new.php
  // Single page post submission
  
  $customer = [];
  $customer['cust_type'] = $_POST['CustType'] ?? '';
  $customer['fname'] = $_POST['fname'] ?? '';
  $customer['lname'] = $_POST['lname'] ?? '';
  $customer['state'] = $_POST['state'] ?? '';
  $customer['city'] = $_POST['city'] ?? '';
  $customer['st_addr'] = $_POST['street'] ?? '';
  $customer['apt'] = $_POST['apartment'] ?? '';
  $customer['zipcode'] = $_POST['zipcode'] ?? '';
  $customer['email'] = $_POST['email'] ?? '';
  $customer['phone'] = $_POST['phone'] ?? '';

 
  $result = insert_customer($customer);
  if($result === true){
      $new_id = mysqli_insert_id($db);
      redirect_to(url_for('/staff/customer/show.php?id=' . $new_id));
  }else{
      $errors = $result;
  }

} else {
  //display the blank form
  $customer = [];
  $customer['cust_type'] = '';
  $customer['fname'] = '';
  $customer['lname'] = '';
  $customer['state'] = '';
  $customer['city'] = '';
  $customer['st_addr'] = '';
  $customer['apt'] = '';
  $customer['zipcode'] = '';
  $customer['email'] =  '';
  $customer['phone'] = '';

}

?>



<?php $page_title = 'Create Customer'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>


<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/customer/index.php'); ?>">&laquo; Back to List</a>

  <div class="customer new">
    <h1>Create Customer</h1>

    <?php echo display_errors($errors); ?>

    <?php /* <form action="<?php echo url_for('/staff/customer/create.php'); ?>" method="post"> */?>
    <form action="<?php echo url_for('/staff/customer/new.php');?>" method="post">

      <dl>
        <dt>CustType</dt>
        <dd>
          <input type="radio" name="CustType" value="I" <?php if(h($customer['cust_type']) == 'I') echo "checked"; ?>/>Individual<br>
          <input type="radio" name="CustType" value="C" <?php if(h($customer['cust_type']) == 'C') echo "checked"; ?>/>Corporation
        </dd>
      </dl>
      <dl>
        <dt>First Name:</dt>
        <dd><input type="text" name="fname" value="<?php echo $customer['fname']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Last Name</dt>
        <dd><input type="text" name="lname" value="<?php echo $customer['lname']; ?>" /></dd>
      </dl>
      <dl>
        <dt>State</dt>
        <dd><input type="text" name="state" value="<?php echo $customer['state']; ?>" /></dd>
      </dl>
      <dl>
        <dt>City</dt>
        <dd><input type="text" name="city" value="<?php echo $customer['city']; ?>" /></dd>
      </dl>
       <dl>
        <dt>Street</dt>
        <dd><input type="text" name="street" value="<?php echo $customer['st_addr']; ?>" /></dd>
      </dl>
       <dl>
        <dt>Apartment</dt>
        <dd><input type="text" name="apartment" value="<?php echo $customer['apt']; ?>" /></dd>(Optional)
      </dl>
       <dl>
        <dt>Zipcode</dt>
        <dd><input type="number" name="zipcode" value="<?php echo $customer['zipcode']; ?>" min="0"/></dd>
      </dl>
      <dl>
        <dt>Email</dt>
        <dd><input type="email" name="email" value="<?php echo $customer['email']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Phone</dt>
        <dd><input type="text" name="phone" value="<?php echo $customer['phone']; ?>" /></dd>

        <br><br>
      <div id="operations">
        <input type="submit" value="Create Customer" />
      </div>
    </form>

  </div>
</div>
<br>


<?php

/*if (is_post_request()) {

  if (!empty($typeErr)||!empty($stateErr)||!empty($cityErr)||!empty($streetErr)||!empty($zipcodeErr)||!empty($emailErr)||
    !empty($phoneErr))
  {
    
    //redirect_to(url_for('/staff/customer/new.php'));
    
    echo "<h2>Your input:</h2>";
    echo "Form parameters<br />";
    echo "Customer type: " . $type . "<br />";
    echo "State: " . $state . "<br />";
    echo "City: " . $city . "<br />";
    echo "Street: " . $street . "<br />";
    echo "Apartment: " . $apt . "<br />";
    echo "Zipcode: " . $zipcode . "<br />";
    echo "Email: " . $email . "<br />";
    echo "Phone: " . $phone . "<br />";

     } else {

      if ($type == "Individual") {
      redirect_to(url_for('/staff/custind/new.php'));
       } else {
        redirect_to(url_for('/staff/custcor/new.php'));
       }
     }
  
}
*/
?>


<?php include(SHARED_PATH . '/staff_footer.php'); ?>
