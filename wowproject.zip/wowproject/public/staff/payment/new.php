<?php

require_once('../../../private/initialize.php');

require_login();

if(is_post_request()) {

  // Handle form values sent by new.php

  $payment = [];
  $payment['card_no'] = $_POST['card_no'] ?? '';
  $payment['method'] = $_POST['method'] ?? '';
  $payment['cust_id']= $_POST['cust_id'] ?? '';

  $result = insert_payment($payment);
  if($result === true){
      $new_id = mysqli_insert_id($db);
      redirect_to(url_for('/staff/payment/show.php?id=' . $new_id));
  }else{
      $errors = $result;
  }

} else {
  //display the blank form
  $payment = [];
  $payment['card_no'] = '';
  $payment['method'] = '';
  $payment['cust_id']= '';

}

$customer_set = find_all_customers();

?>

<?php $page_title = 'Create Payment'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/payment/index.php'); ?>">&laquo; Back to List</a>

  <div class="payment new">
    <h1>Create Payment</h1>

    <?php echo display_errors($errors); ?>
    <form action="<?php echo url_for('/staff/payment/new.php'); ?>" method="post">
    <dl>
        <dt>Customer Name</dt>
        <dd>
          <select name="cust_id">
          <?php
            foreach($customer_set as $customer) {
              echo "<option value=\"{$customer['cust_id']}\"";
              if($payment['cust_id'] == $customer['cust_id']) {
                echo " selected";
              }
              echo ">" . h($customer['cust_id']) . "--" . h($customer['fname']) . " " .h($customer['lname']) . "</option>";
            }
          ?>
          </select>
        </dd>
      </dl>
      <dl>
        <dt>Card Number</dt>
        <dd><input type="text" name="card_no" value="" /></dd>
      </dl>

      <dl>
        <dt>Method</dt>
        <dd>
          <input type="radio" name="method" value="C">Credit Card<br>
          <input type="radio" name="method" value="D">Debit Card<br>
          <input type="radio" name="method" value="G">Gift Card<br>
        </dd>
      </dl>

      <br>
      <div id="operations">
        <input type="submit" value="Create New Payment" />
      </div>
    </form>

  </div>

</div>
<?php
/*    <dl>
        <dt>Customer ID</dt>
        <dd><input type="number" name="cust_id" value="" min="1"/></dd>
      </dl>

*/

mysqli_free_result($customer_set);

?>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
