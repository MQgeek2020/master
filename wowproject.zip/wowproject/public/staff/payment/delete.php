<?php

require_once('../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/payment/index.php'));
}
$payno = $_GET['id'];

if(is_post_request()) {

  $result = delete_payment($payno);
  redirect_to(url_for('/staff/payment/index.php'));

} else {
  $payment = find_payment_by_id($payno);
}

$customer = find_customer_by_id($payment['cust_id']); 

?>

<?php $page_title = 'Delete Payment'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/payment/index.php'); ?>">&laquo; Back to List</a>

  <div class="payment delete">
    <h1>Delete Payment</h1>
    <p><h2>Are you sure you want to delete this payment?</h2></p>
    <p class="item">
      <?php  echo "<h3>Form parameters:</h3>";
             echo "Payment No: " . h($payment['payno']). "<br />";
             echo "Card Number: " . h($payment['card_no']) . "<br />";
             echo "Payment Method: " . h($payment['method']) . "<br />";
             echo "Customer ID: " . h($payment['cust_id']) . "<br />";
             echo "Customer Name: ". name_format(h($customer['fname'])). " " . name_format(h($customer['lname'])). "<br />" ; 
          ?> 
      </p>
    <br />
    <form action="<?php echo url_for('/staff/payment/delete.php?id=' . h(u($payment['payno']))); ?>" method="post">
      <div id="operations">
        <input type="submit" name="commit" value="Delete Payment" />
      </div>
    </form>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
