<?php require_once('../../../private/initialize.php'); ?>

<?php
  
  require_login();
  
  $payment_set = find_all_payments();
?>

<?php $page_title = 'Payments'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
   
  <a class="action" href="<?php echo url_for('/staff/index.php'); ?>"> &laquo; Back to Main Menu</a>

  <div class="payments listing">
    <h1>Payments</h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/payment/new.php'); ?>">Create New Payment</a>
    </div>

  	<table class="list">
  	  <tr>
        <th>Payment No</th>
        <th>Card Number</th>
        <th>Method</th>
  	    <th>Customer Name</th>
  	    <th>&nbsp;</th>
  	    <th>&nbsp;</th>
        <th>&nbsp;</th>
  	  </tr>

      <?php while($payment = mysqli_fetch_assoc($payment_set)) { ?>
      <?php $customer = find_customer_by_id($payment['cust_id']); ?>
        <tr>
          <td><?php echo h($payment['payno']); ?></td>
          <td><?php echo h($payment['card_no']); ?></td>
          <td>
            <?php if($payment['method'] == 'G'){
                  echo 'Gift';
             } else{
              echo $payment['method'] == 'C' ? 'Credit' : 'Debit';  }
              
              ?> </td>

    	    <td><?php echo h($customer['fname']. " " . h($customer['lname'])); ?></td>
          <td><a class="action" href="<?php echo url_for('/staff/payment/show.php?id=' . h(u($payment['payno']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/payment/edit.php?id=' . h(u($payment['payno']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/payment/delete.php?id=' . h(u($payment['payno']))); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>
    <?php
      mysqli_free_result($payment_set);
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
