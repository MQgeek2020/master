<?php

require_once('../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/vehtype/index.php'));
}
$id = $_GET['id'];

if(is_post_request()) {

  // Handle form values sent by edit.php

  $vehicle = [];
  $vehicle['veh_id'] = $id;
  $vehicle['make'] = $_POST['make'] ?? '';
  $vehicle['model'] = $_POST['model'] ?? '';
  $vehicle['vyear'] = $_POST['year'] ?? '';
  $vehicle['VIN'] = $_POST['VIN'];
  $vehicle['LPN'] = $_POST['LPN'] ?? '';
  $vehicle['vclass_id'] = $_POST['vclass_id'] ?? '';
  $vehicle['loc_id'] = $_POST['loc_id'] ?? '';

  $result = update_vehicle($vehicle);
  if($result === true) {
    redirect_to(url_for('/staff/vehtype/show.php?id=' . $id));
  } else {
    $errors = $result;
    //var_dump($errors);
  }

} else {

  $vehicle = find_vehicle_by_id($id);

}

$vclass_set = find_all_vclasses();
$office_set = find_all_offices();

?>

<?php $page_title = 'Edit Vehicle'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

    <a class="back-link" href="<?php echo url_for('/staff/vclass/show.php?id=' . h(u($vehicle['vclass_id']))); ?>">&laquo; Back to Vehicle Type</a>

  <div class="vehicle edit">
    <h1>Edit Vehicle</h1>
    <?php echo display_errors($errors); ?>

    <form action="" method="post">

     <dl>
        <dt>Vehicle Type</dt>
        <dd>
          <select name="vclass_id">
          <?php
            foreach($vclass_set as $vclass) {
              echo "<option value=\"{$vclass['vclass_id']}\"";
              if($vehicle['vclass_id'] == $vclass['vclass_id']) {
                echo " selected";
              }
              echo ">" . h($vclass['vclass_id']) . "--" . h($vclass['vc_name']) . "</option>";
            }
          ?>
          </select>
        </dd>
      </dl>
      
      <dl>
        <dt>Make</dt>
        <dd><input type="text" name="make" value="<?php echo h($vehicle['make']); ?>" /></dd>
      </dl>
       <dl>
        <dt>Model</dt>
        <dd><input type="text" name="model" value="<?php echo h($vehicle['model']); ?>" /></dd>
      </dl>
     
      <dl>
        <dt>Year of Production</dt>
        <dd><input type="number" name="year" value="<?php echo h($vehicle['vyear']); ?>" min="1900" max="9999"></dd>
      </dl>
      <dl>
        <dt>Vehicle Identification Number</dt>
        <dd><input type="text" name="VIN" value="<?php echo h($vehicle['VIN']); ?>" /></dd>
      </dl>
     
      <dl>
        <dt>License Plate Number</dt>
        <dd><input type="text" name="LPN" value="<?php echo h($vehicle['LPN']); ?>" /></dd>
      </dl>
      
      <dl>
        <dt>Office ID</dt>
        <dd>
          <select name="loc_id">
          <?php
            foreach($office_set as $office) {
              echo "<option value=\"{$office['loc_id']}\"";
              if($vehicle['loc_id'] == $office['loc_id']) {
                echo " selected";
              }
              echo ">" . h($office['loc_id']) . "--" . h($office['loc_state'])  . "--" . h($office['loc_city']). " </option>";
            }
          ?>
          </select>
        </dd>
      </dl>

      <br>

      <div id="operations">
        <input type="submit" value="Edit Vehicle" />
      </div>
    </form>

  </div>

</div>

<?php

mysqli_free_result($vclass_set);
mysqli_free_result($office_set);

?>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
