<?php require_once('../../../private/initialize.php'); ?>

<?php

require_login();

$id = $_GET['id'] ?? '1'; 

$invpay = find_invpay_by_id($id);
?>

<?php $page_title = 'Show Invoice Payment'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/invpay/index.php'); ?>">&laquo; Back to List</a>

  <div class="invpay show">

    <h1>Transaction ID: <?php echo h($invpay['txn_id']); ?></h1>

    <div class="attributes">
    	<dl>
        <dt>Invoice No</dt>
        <dd><?php echo h($invpay['invno']); ?></dd>
      </dl>
      <dl>
        <dt>Payment No</dt>
        <dd><?php echo h($invpay['payno']); ?></dd>
      </dl>
      <dl>
        <dt>Transaction Date</dt>
        <dd><?php echo h($invpay['pay_date']); ?></dd>
      </dl>
      <dl>
        <dt>Payment Amount</dt>
        <dd><?php echo h($invpay['pay_amount']) . "  $"; ?></dd>
      </dl>
      <dl>
        <dt>Status</dt>
         <dd><?php if($invpay['pay_status'] == 'CLEARED'){
                  echo 'Cleared';
             } else{
              echo $invpay['pay_status'] == 'UNCLEARED' ? 'Uncleared' : 'Unpaid';  }
              
              ?> </td>
           <dd>
      </dl>   
   </div>
  </div>
</div>
<?php include(SHARED_PATH . '/staff_footer.php'); ?>