<?php require_once('../../../private/initialize.php'); ?>

<?php

require_login();

$id = $_GET['id'] ?? '1';

$vehicle = find_vehicle_by_id($id);
?>

<?php $page_title = 'Show Vehicle'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/office/show.php?id=' . h(u($vehicle['loc_id']))); ?>">&laquo; Back to Office</a>

  <div class="vehicle show">

    <h1>Vehicle ID: <?php echo h($vehicle['veh_id']); ?></h1>

    <div class="attributes">
      <?php $vclass = find_vclass_by_id($vehicle['vclass_id']); ?>
       <dl>
        <dt>Vehicle Type</dt>
        <dd><?php echo h($vclass['vc_name']); ?></dd>
      </dl>
       <dl>
        <dt>Vehicle Make</dt>
        <dd><?php echo h($vehicle['make']); ?></dd>
      </dl>
       <dl>
        <dt>Vehicle Model</dt>
        <dd><?php echo h($vehicle['model']); ?></dd>
      </dl>
     
      <dl>
        <dt>Year of Production</dt>
        <dd><?php echo h($vehicle['vyear']); ?></dd>
      </dl>
      <dl>
        <dt>Vehicle Identification Number</dt>
        <dd><?php echo h($vehicle['VIN']); ?></dd>
      </dl>
      <dl>
        <dt>License Plate number</dt>
        <dd><?php echo h($vehicle['LPN']); ?></dd>
      </dl>     
      <dl>
        <dt>Office ID</dt>
        <dd><?php echo h($vehicle['loc_id']); ?></dd>
      </dl>
    </div>
  </div>

</div>

<?php
/*<dl>
        <dt>Price</dt>
        <dd><?php echo h($vehicle['price'])."  $"; ?></dd>  
      </dl>
      <dl>
        <dt>Fuel Comsumption Rate</dt>
        <dd><?php echo h($vehicle['fuel'])."  gals/100 miles"; ?></dd>  
      </dl>
      <dl>
        <dt>Vehicle Class ID</dt>
        <dd><?php echo h($vehicle['vclass_id']); ?></dd>
      </dl>   
      */
?>


<?php include(SHARED_PATH . '/staff_footer.php'); ?>