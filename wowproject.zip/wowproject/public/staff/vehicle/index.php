
<?php require_once('../../../private/initialize.php'); ?>

<?php

  require_login();

  $vehicle_set = find_all_vehicles();
?>

<?php $page_title = 'Vehicles'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

 <a class="action" href="<?php echo url_for('/staff/index.php'); ?>"> &laquo; Back to Main Menu</a>

  <div class="vehicles listing">
    <h1>Vehicles</h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/vehicle/new.php'); ?>">Create New Vehicle</a>
    </div>

  	<table class="list">
  	  <tr>
        <th>Vehicle ID</th>
        <th>Make</th>
        <th>Model</th>
  	    <th>Year</th>
        <th>Vehicle Identification Number</th>
        <th>License Plate number</th>
        <th>Vehcle Class</th>
        <th>Office ID</th>
  	    <th>&nbsp;</th>
  	    <th>&nbsp;</th>
        <th>&nbsp;</th>
  	  </tr>

      <?php while($vehicle = mysqli_fetch_assoc($vehicle_set))  { ?>
      <?php $vclass = find_vclass_by_id($vehicle['vclass_id']); ?>
        <tr>
          <td><?php echo h($vehicle['veh_id']); ?></td>
          <td><?php echo h($vehicle['make']); ?></td>       
    	    <td><?php echo h($vehicle['model']); ?></td>
          <td><?php echo h($vehicle['vyear']); ?></td>
          <td><?php echo h($vehicle['VIN']); ?></td>       
          <td><?php echo h($vehicle['LPN']); ?></td>     
          <td><?php echo h($vclass['vc_name']); ?></td>
          <td><?php echo h($vehicle['loc_id']); ?></td>
          <td><a class="action" href="<?php echo url_for('/staff/vehicle/show.php?id=' . h(u($vehicle['veh_id']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/vehicle/edit.php?id=' . h(u($vehicle['veh_id']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/vehicle/delete.php?id=' . h(u($vehicle['veh_id']))); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>
    <?php
      mysqli_free_result($vehicle_set);
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
