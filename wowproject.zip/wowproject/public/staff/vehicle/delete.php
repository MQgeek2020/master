<?php

require_once('../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/vehicle/index.php'));
}
$veh_id = $_GET['id'];

$vehicle = find_vehicle_by_id($veh_id);

if(is_post_request()) {

  $result = delete_vehicle($veh_id);
  redirect_to(url_for('/staff/office/show.php?id=' . h(u($vehicle['loc_id']))));

}

$vclass = find_vclass_by_id($vehicle['vclass_id']);

?>

<?php $page_title = 'Delete Subject'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/office/show.php?id=' . h(u($vehicle['loc_id']))); ?>">&laquo; Back to Office</a>

  <div class="vehicle delete">
    <h1>Delete Vehicle</h1>
    <p><h2>Are you sure you want to delete this vehicle?</h2></p>
    <p class="item">
      <?php echo "<h3>Form parameters:</h3>";
            echo "Vehicle ID: " . h($vehicle['veh_id']) . "<br />";
            echo "Vehicle Type: ". h($vclass['vc_name']). "<br />" ; 
            echo "Vehicle Make: " . h($vehicle['make']) . "<br />";
            echo "Vehicle Model: " . h($vehicle['model']) . "<br />";
            echo "Year: " . h($vehicle['vyear']) . "<br />";
            echo "Identification No: " . h($vehicle['VIN']) . "<br />";
            echo "License Plate No: " . h($vehicle['LPN']) . "<br />";
            echo "Vehicle Class ID: " . h($vehicle['vclass_id']) . "<br />";
            echo "Office ID: " . h($vehicle['loc_id']) . "<br />";
      ?></p>
     <br />
    <form action="<?php echo url_for('/staff/vehicle/delete.php?id=' . h(u($vehicle['veh_id']))); ?>" method="post">
      <div id="operations">
        <input type="submit" name="commit" value="Delete Vehicle" />
      </div>
    </form>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
