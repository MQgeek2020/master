<?php require_once('../../private/initialize.php'); ?>

<?php require_login(); 

$errors = [];
$firstname = '';
$lastname = '';


if(is_post_request()) {

  $firstname = $_POST['firstname'] ?? '';
  $lastname = $_POST['lastname'] ?? '';

  // Validations
  // FirstName
  if(is_blank($firstname)) {
      $errors[] = "First Name cannot be blank.";
    }elseif(is_numeric($firstname)){
      $errors[] = "First Name cannot be Numeric!";
    }elseif(has_special_charac($firstname)){
      $errors[] = "First Name cannot contain special characters.";
    }elseif(!has_length($firstname, ['min' => 2, 'max' => 30])) {
      $errors[] = "First Name must be between 2 and 30 characters.";
    }elseif(is_blank(has_first_name($firstname))) {
      $errors[] = "First Name does not exist.";
  }
 

  // LastName
  if(is_blank($lastname)) {
      $errors[] = "Last Name cannot be blank.";
    } elseif(is_numeric($lastname)){
      $errors[] = "Last Name cannot be Numeric!";
    }elseif(has_special_charac($lastname)){
      $errors[] = "Last Name cannot contain special characters.";
    }elseif(!has_length($lastname, ['min' => 2, 'max' => 30])) {
      $errors[] = "Last Name must be between 2 and 30 characters.";
    }elseif(is_blank(has_last_name($lastname))) {
      $errors[] = "Last Name does not exist. ";
  }


  // if there were no errors, jump to page custsearch.php
  if(empty($errors)) {

    $customer = find_customer_by_custname($firstname,$lastname);
    $custid = $customer['cust_id'];
    $_SESSION['cust_id'] = $custid;
    //echo $custid;
    redirect_to(url_for('/staff/custsearch.php?cust_id='. h(u($custid))));

    } else {
        //display errors
        //$errors[] = $login_failure_msg;
  }

}


?>

<?php $page_title = 'Staff Menu'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
  <div id="main-menu">
    <h2>Main Menu</h2>
    <ul>
      <li><b>Admin Management</b></li>
      <li><a href="<?php echo url_for('/staff/admins/index.php'); ?>">Staff Admins</a></li>
      <li><a href="<?php echo url_for('/staff/cust_admins/index.php'); ?>">Customer Admins</a></li><br>

      <li><b>WOW Offices</b></li>
      <li><a href="<?php echo url_for('/staff/office/index.php'); ?>">Office Locations</a></li>
      <li><a href="<?php echo url_for('/staff/vclass/index.php'); ?>">Vehicle Types</a></li><br>
      
      <li><b>Customers</b></li>
      <li><a href="<?php echo url_for('/staff/customer/index.php'); ?>">Profiles</a></li>
      <li><a href="<?php echo url_for('/staff/custind/index.php'); ?>">Individual</a></li>
      <li><a href="<?php echo url_for('/staff/custcor/index.php'); ?>">Corporation</a></li>
      <li><a href="<?php echo url_for('/staff/coupon/index.php'); ?>">Coupon</a></li>
      <li><a href="<?php echo url_for('/staff/payment/index.php'); ?>">Payment</a></li><br>

      <li><b>WOW Services</b></li>
      <li><a href="<?php echo url_for('/staff/service/index.php'); ?>">Service</a></li>
      <li><a href="<?php echo url_for('/staff/invoice/index.php'); ?>">Invoice</a></li>
      <li><a href="<?php echo url_for('/staff/invpay/index.php'); ?>">InvoicePayStatus</a></li>
      
    </ul>
  </div>
    <div id="main-menu">
      <h2>Search by Customer</h2>
      <?php echo display_errors($errors); ?>

  <form action="index.php" method="post">
      <dl>
        <dt>FirstName:</dt>
        <dd><input type="text" name="firstname" value="<?php echo h($firstname); ?>" /></dd>
      </dl>
      <dl>
        <dt>LastName:</dt>
        <dd><input type="text" name="lastname" value="<?php echo h($lastname); ?>" /><br /></dd>
      </dl>
       <div id="operations">
       <input type="submit" name="submit" value="Search"  />
      </div>
  </form>

   </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
