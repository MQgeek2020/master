<?php require_once('../../../private/initialize.php'); ?>

<?php
  /*$individuals = [
    ['id' => '1', 'fname' => 'MIKE', 'lname' => 'GREEN', 'DLN' => 'LC001', 'INSCN' => 'SCN001', 'INSPN' => 'SPN001'],
    ['id' => '3', 'fname' => 'SMITH', 'lname' => 'WHITE', 'DLN' => 'LC003', 'INSCN' => 'SCN003', 'INSPN' => 'SPN003'],
    ['id' => '4', 'fname' => 'WARD', 'lname' => 'WOOD', 'DLN' => 'LC004', 'INSCN' => 'SCN004', 'INSPN' => 'SPN004'],
   
  ];*/
  $custind_set = find_all_custinds();
?>

<?php $page_title = 'IndividualCustomers'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
  
   <a class="action" href="<?php echo url_for('/staff/index.php'); ?>"> &laquo; Back to Main Menu</a>
   
  <div class="Individuals listing">
    <h1>Individual Customer</h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/custind/new.php'); ?>">Create New Individual Customer</a>
    </div>

  	<table class="list">
  	  <tr>
        <th>Customer ID</th>
        <th>Individual Name</th>
  	    <th>Driver License Number</th>
        <th>Insurance Company Name</th>
        <th>Insurance Policy Number</th>
  	    <th>&nbsp;</th>
  	    <th>&nbsp;</th>
        <th>&nbsp;</th>
  	  </tr>

      <?php while($individual = mysqli_fetch_assoc($custind_set)) { ?>
        <?php $customer = find_customer_by_id($individual['cust_id']); ?>
        <tr>
          <td><?php echo h($individual['cust_id']); ?></td>
          <td><?php echo h($customer['fname']). " " . h($customer['lname']); ?></td>
          <td><?php echo h($individual['DLN']); ?></td>
          <td><?php echo h($individual['INSCN']); ?></td>
          <td><?php echo h($individual['INSPN']); ?></td>
          
          <td><a class="action" href="<?php echo url_for('/staff/custind/show.php?id=' . h(u($individual['cust_id']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custind/edit.php?id=' . h(u($individual['cust_id']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/custind/delete.php?id=' . h(u($individual['cust_id']))); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>
    <?php
      mysqli_free_result($custind_set);
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
