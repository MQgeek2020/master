<?php

require_once('../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/custind/index.php'));
}
$cust_id = $_GET['id'];

if(is_post_request()) {

  $result = delete_custind($cust_id);
  redirect_to(url_for('/staff/custind/index.php'));

} else {
  $custind = find_custind_by_id($cust_id);
}

$customer = find_customer_by_id($custind['cust_id']); 

?>

<?php $page_title = 'Delete Individual Customer'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custind/index.php'); ?>">&laquo; Back to List</a>

  <div class="Individual delete">
    <h1>Delete Individual Customer</h1>
    <p><h2>Are you sure you want to delete this individual?</h2></p>
    <p class="item">
      <?php echo "<h3>Form parameters:</h3>";
            echo "Customer ID: " . h($custind['cust_id']). "<br />";
            echo "Customer Name: ". h($customer['fname']). " " . h($customer['lname']). "<br />" ;   
            echo "Driver License Number: ". h($custind['DLN']). "<br />" ;  
            echo "Insurance Company Name: " . h($custind['INSCN']) . "<br />";
            echo "Insurance Policy Number: " . h($custind['INSPN']) . "<br />";
          ?>    
    </p>
    <br/s>
    <form action="<?php echo url_for('/staff/custind/delete.php?id=' . h(u($custind['cust_id']))); ?>" method="post">
      <div id="operations">
        <input type="submit" name="commit" value="Delete Individual" />
      </div>
    </form>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
