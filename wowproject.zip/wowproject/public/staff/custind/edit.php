<?php

require_once('../../../private/initialize.php');

require_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/custind/index.php'));
}
$id = $_GET['id'];

if(is_post_request()) {

  // Handle form values sent by edit.php

  $custind = [];
  $custind['cust_id'] = $id;
  $custind['DLN'] = $_POST['DLN'] ?? '';
  $custind['INSCN'] = $_POST['INSCN'] ?? '';
  $custind['INSPN'] = $_POST['INSPN'] ?? '';

  $result = update_custind($custind);
  if($result === true) {
    redirect_to(url_for('/staff/custind/show.php?id=' . $id));
  } else {
    $errors = $result;
    //var_dump($errors);
  }

} else {

  $custind = find_custind_by_id($id);

}

$individual_set = find_all_individuals();

?>

<?php $page_title = 'Edit Individual customer'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custind/index.php'); ?>">&laquo; Back to List</a>

  <div class="Individual customer edit">
    <h1>Edit Individual Customer</h1>
    <?php echo display_errors($errors); ?>

    <form action="" method="post">
    <dl>
        <dt>Customer Name</dt>
        <dd>
          <select name="cust_id">
          <?php
            foreach($individual_set as $individual) {
              echo "<option value=\"{$individual['cust_id']}\"";
              if($custind['cust_id'] == $individual['cust_id']) {
                echo " selected";
              }
              echo ">". h($individual['cust_id']) . "--" . h($individual['fname'])." ". h($individual['lname']) . "</option>";
            }
          ?>
          </select>
        </dd>
      </dl>
        <dt>Driver License Number</dt>
        <dd><input type="text" name="DLN" value="<?php echo h($custind['DLN']); ?>" /></dd>
      </dl>
       <dl>
        <dt>Insurance Company Name</dt>
        <dd><input type="text" name="INSCN" value="<?php echo h($custind['INSCN']); ?>" /></dd>
      </dl>
       <dl>
        <dt>Insurance Policy Number</dt>
        <dd><input type="text" name="INSPN" value="<?php echo h($custind['INSPN']); ?>" /></dd>
      </dl>
      
      
      <div id="operations">
        <input type="submit" value="Edit Individual Customer" />
      </div>
    </form>

  </div>

</div>
<?php
/*
<dl>
    <dt>Customer ID</dt>
        <dd><input type="number" name="cust_id" value="<?php echo h($custind['cust_id']); ?>" min="0"/></dd>
      </dl>
  <dl>


*/
mysqli_free_result($individual_set);

?>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
