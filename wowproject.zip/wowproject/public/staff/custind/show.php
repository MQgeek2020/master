<?php require_once('../../../private/initialize.php'); ?>

<?php

require_login();

$id = $_GET['id'] ?? '1';

$custind = find_custind_by_id($id);
?>

<?php $page_title = 'Show Individual Customer'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custind/index.php'); ?>">&laquo; Back to List</a>

  <div class="Individual Customer show">
    <?php $customer = find_customer_by_id($custind['cust_id']); ?>

    <h1>Customer ID: <?php echo h($custind['cust_id']); ?></h1>

    <div class="attributes">
      <dl>
        <dt>Customer Name</dt>
        <dd><?php echo h($customer['fname']). " " . h($customer['lname']); ?></dd>
      </dl>
      <dl>
        <dt>Driver License Number</dt>
        <dd><?php echo h($custind['DLN']); ?></dd>
      </dl>
       <dl>
        <dt>Insurance Company Name</dt>
        <dd><?php echo h($custind['INSCN']); ?></dd>
      </dl>
       <dl>
        <dt>Insurance Policy Number</dt>
        <dd><?php echo h($custind['INSPN']); ?></dd>
      </dl>

    </div>
  </div>

</div>
<?php include(SHARED_PATH . '/staff_footer.php'); ?>