<?php

require_once('../../../private/initialize.php');

require_login();

if(is_post_request()) {

  // Handle form values sent by new.php

  $custind = [];
  $custind['cust_id'] = $_POST['cust_id'] ?? '';
  $custind['DLN'] = $_POST['DLN'] ?? '';
  $custind['INSCN'] = $_POST['INSCN'] ?? '';
  $custind['INSPN'] = $_POST['INSPN'] ?? '';


  $result = insert_custind($custind);
  if($result === true){
      $new_id = mysqli_insert_id($db);
      redirect_to(url_for('/staff/custind/show.php?id=' . $new_id));
  }else{
      $errors = $result;
  }

} else {
  //display the blank form
  $custind = [];
  $custind['cust_id'] = '';
  $custind['DLN'] = '';
  $custind['INSCN'] = '';
  $custind['INSPN'] = '';

}

$individual_set = find_all_individuals();

?>

<?php $page_title = 'Create Individual'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/custind/index.php'); ?>">&laquo; Back to List</a>

  <div class="Individual new">
    <h1>Create Individual</h1>

    <?php echo display_errors($errors); ?>

    <form action="<?php echo url_for('/staff/custind/new.php'); ?>" method="post">
     <dl>
        <dt>Customer Name</dt>
        <dd>
          <select name="cust_id">
          <?php
            foreach($individual_set as $individual) {
              echo "<option value=\"{$individual['cust_id']}\"";
              if($custind['cust_id'] == $individual['cust_id']) {
                echo " selected";
              }
              echo ">" . h($individual['cust_id']) . "--" . h($individual['fname']). " ". h($individual['lname']) . "</option>";
            }
          ?>
          </select>
        </dd>
      </dl>
       <dl>
        <dt>Driver License Number</dt>
        <dd><input type="text" name="DLN" value="<?php echo $custind['DLN']; ?>" /></dd>
      </dl>
       <dl>
        <dt>Insurance Company Name</dt>
        <dd><input type="text" name="INSCN" value="<?php echo $custind['INSCN']; ?>" /></dd>
      </dl>
       <dl>
        <dt>Insurance Policy Number</dt>
        <dd><input type="text" name="INSPN" value="<?php echo $custind['INSPN']; ?>" /></dd>
      </dl>
      
      <div id="operations">
        <input type="submit" value="Create Individual Customer" />
      </div>
    </form>

  </div>

</div>
<?php
/* 
  
      <dl>
        <dt>Customer ID</dt>
        <dd><input type="number" name="cust_id" value="<?php echo $custind['cust_id']; ?>" min="0"/></dd>
      </dl>

*/
mysqli_free_result($individual_set);
?>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
