<?php require_once('../../../private/initialize.php'); ?>

<?php

require_cust_login();

if(!isset($_GET['serv_no'])||!isset($_GET['cust_id'])) {
  redirect_to(url_for('/homepage/service/index.php'));
}
$serv_no = $_GET['serv_no'];
$cust_id = $_GET['cust_id'];

$service = find_service_by_id($serv_no);

?>

<?php $page_title = 'Show Service'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>


<div id="content">
  
  <div class="service show">
    <a class="back-link" href="<?php echo url_for('/homepage/service/index.php?id=' . h(u($cust_id))); ?>">&laquo; Back to Services Index</a>

    <?php $customer = find_customer_by_id($service['cust_id']); ?>
    <?php $vehicle = find_vehicle_by_id($service['veh_id']); ?>
    <?php $vclass = find_vclass_by_id($vehicle['vclass_id']); ?>

  	<h1>Service No: <?php echo h($service['serv_no']); ?></h1>

  	<div class="attributes">
      <dl>
        <dt>Customer Name</dt>
        <dd><?php echo name_format(h($customer['fname'])) . "  ". name_format(h($customer['lname'])); ?></dd>
      </dl>
      <dl>
        <dt>Scheduled Time</dt>
        <dd><?php echo h($service['sche_time']); ?></dd>
      </dl>
      <dl>
        <dt>Pickup Date</dt>
        <dd><?php echo h($service['pickup_date']); ?></dd>
      </dl>
      <dl>
        <dt>Dropoff Date</dt>
        <dd><?php echo h($service['droff_date']); ?></dd>
      </dl>
      <dl>
        <dt>Start Odometer</dt>
        <dd><?php echo h($service['sta_odo']) . "  miles"; ?></dd>
      </dl>
      <dl>
        <dt>End Odometer</dt>
        <dd><?php echo h($service['end_odo']) . "  miles"; ?></dd>
      </dl>
      <dl>
        <dt>Daily limit</dt>
        <dd><?php echo h($service['odolimit']). "   miles/day"; ?></dd>
      </dl>
      <dl>
        <dt>Pickup Location</dt>
        <dd><?php echo h($service['pickup_loc']); ?></dd>
      </dl>
      <dl>
        <dt>Dropoff Location</dt>
        <dd><?php echo h($service['droff_loc']); ?></dd>
      </dl>
      <dl>
        <dt>Vehicle</dt>
        <dd><?php echo h($vehicle['make']). "-- " . h($vehicle['model']); ?></dd>
      </dl>
        <dl>
        <dt>Vehicle Type</dt>
        <dd><?php echo h($vclass['vc_name']); ?></dd>
      </dl>
       <dl>
        <dt>License Plate Number</dt>
        <dd><?php echo h($vehicle['LPN']); ?></dd>
      </dl>
      </dl>
        <dl>
        <dt>Rent Charge Rate</dt>
        <dd><?php echo h($vclass['rent_charge']). " $/day"; ?></dd>
      </dl>
      </dl>
        <dl>
        <dt>Extra Charge Rate</dt>
        <dd><?php echo h($vclass['extra_charge']). " $/mile"; ?></dd>
      </dl>
       <dl>
        <dt>Invoice No</dt>
        <dd><?php echo h($service['invno']); ?></dd>
      </dl>
       <dl>
        <dt>Coupon No</dt>
        <dd><?php echo h($service['coupon_no']) == 0 ? 'NULL' : h($service['coupon_no']); ?></dd>
      </dl>

    </div>


  </div>

</div>
<br>
<?php include(SHARED_PATH . '/staff_footer.php'); ?>