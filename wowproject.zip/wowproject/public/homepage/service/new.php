<?php

require_once('../../../private/initialize.php');

require_cust_login();

/*if(!isset($_SESSION['username'])) {
  redirect_to(url_for('/homepage/login.php'));*/

$username = $_SESSION['cust_username'];

$cust_admin = find_cust_admin_by_username($username);
$customer = find_customer_by_cust_admin($cust_admin);
$cust_id = $customer['cust_id'];

$coupon_set = find_coupons_by_custid($cust_id);

$payment_set = find_payments_by_custid($cust_id);
$payment_count = mysqli_num_rows($payment_set);


if(is_post_request()) {

  // Handle form values sent by new.php
  // Single page post submission

  $service = [];
  $service['sche_time'] = $_POST['sche_time'] ?? '';
  $service['pickup_date'] = $_POST['pickup_date'] ?? '';
  $service['droff_date'] = $_POST['droff_date'] ?? '';
  $service['sta_odo'] = $_POST['sta_odo'];
  $service['end_odo'] = $_POST['end_odo'];
  $service['odolimit'] = $_POST['odolimit'] ?? '';
  $service['pickup_loc'] = $_POST['pickup_loc'] ?? '';
  $service['droff_loc'] = $_POST['droff_loc'] ?? '';
  $service['veh_id'] = $_POST['veh_id'] ?? '';
  $service['cust_id'] = $_POST['cust_id'] ?? '';
  $service['invno'] = $_POST['invno'] ?? '';
  $service['coupon_no'] = $_POST['coupon_no'] ?? '';

  $result = insert_service($service);
  if($result === true){
      $_SESSION['message'] = 'New Service Created Successfully.';
      $new_id = mysqli_insert_id($db);
      redirect_to(url_for('/homepage/service/show.php?serv_no=' . $new_id . '&cust_id=' . h(u($cust_id))));
  }else{
      $errors = $result;
  }

} else {
  //display the blank form
  $service = [];
  $service['sche_time'] = '';
  $service['pickup_date'] = '';
  $service['droff_date'] = '';
  $service['sta_odo'] = '';
  $service['end_odo'] = '';
  $service['odolimit'] = '';
  $service['pickup_loc'] = '';
  $service['droff_loc'] = '';
  $service['veh_id'] = '';
  $service['cust_id'] = '';
  $service['invno'] = '';
  $service['coupon_no'] = '';

}

$office_set = find_all_offices();
$vehicle_set = find_all_vehicles();
//$customer_set = find_all_customers();
//$coupon_set = find_all_coupons();

$last_service = last_inserted_service();
$last_service_id = $last_service['serv_no'];
$new_invno = $last_service_id + 1;

?>

<?php $page_title = 'Create Service'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/homepage/service/index.php?id=' . h(u($cust_id))); ?>">&laquo; Back to Services Index</a>

  <div class="serviec new">
    <h1>Create Service</h1>

    <?php if($payment_count == 0){
      $msg[]="Please add AT LEAST ONE VALID payment method before create a new service!!!";
      echo display_messages($msg);
    } if ($payment_count!= 0) { ?>
 
    <?php echo display_errors($errors); ?>
    
    <form action="<?php echo url_for('/homepage/service/new.php'); ?>" method="post">
      <dl>
        <dt>Customer Name</dt>
        <dd>
          <select name="cust_id">
          <?php echo "<option value=\"{$customer['cust_id']}\"";
              if($service['cust_id'] == $customer['cust_id']) {
                echo " selected";
              }
              echo ">" . name_format(h($customer['fname'])). " " . name_format(h($customer['lname'])) . "</option>";
          ?>
          </select>
        </dd>
      </dl>
      <dl>
        <dt>Scheduled Time</dt>
        <dd><input type="date" name="sche_time" value="<?php echo $service['sche_time']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Pickup Date</dt>
        <dd><input type="date" name="pickup_date" value="<?php echo $service['pickup_date']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Dropoff Date</dt>
        <dd><input type="date" name="droff_date" value="<?php echo $service['droff_date']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Start Odometer</dt>
        <dd><input type="number" name="sta_odo" value="<?php echo 0; ?>" min="0" min="0" max="0" step="0.01"/></dd> miles(default)
      </dl>
      <dl>
        <dt>End Odometer</dt>
        <dd><input type="number" name="end_odo" value="<?php echo 0; ?>" min="0" max="0" step="0.01"/></dd> miles(default)
      </dl>
      <dl>
        <dt>Daily Odolimit</dt>
        <dd><input type="number" name="odolimit" value="<?php echo 500; ?>" min="500" max="500"/></dd>   mile/day(default)
      </dl>
      <dl>
        <dt>Pickup Location</dt>
        <dd>
          <select name="pickup_loc">
          <?php
            foreach($office_set as $office) {
              echo "<option value=\"{$office['loc_id']}\"";
              if($service['pickup_loc'] == $office['loc_id']) {
                echo " selected";
              }
              echo ">". h($office['loc_id']) . "--" . h($office['loc_state']). "--" . h($office['loc_city']) . "</option>";
            }
          ?>
          </select>
        </dd>
      </dl>

     <dl>
        <dt>Dropoff Location</dt>
        <dd>
          <select name="droff_loc">
          <?php
            foreach($office_set as $office) {
              echo "<option value=\"{$office['loc_id']}\"";
              if($service['droff_loc'] == $office['loc_id']) {
                echo " selected";
              }
              echo ">". h($office['loc_id']) . "--" . h($office['loc_state']). "--" . h($office['loc_city']) . "</option>";
            }
          ?>
          </select>
        </dd>
      </dl>

      <dl>
        <dt>Vehicle ID</dt>
        <dd>
          <select name="veh_id">
          <?php
            foreach($vehicle_set as $vehicle) {
              echo "<option value=\"{$vehicle['veh_id']}\"";
              if($service['veh_id'] == $vehicle['veh_id']) {
                echo " selected";
              }
              echo ">". h($vehicle['veh_id']) . "--" . h($vehicle['make']) ."--" . h($vehicle['model']) ."</option>";
            }
          ?>
          </select>
        </dd>
      </dl>

      <dl>
        <dt>Invoice No</dt>
        <dd>
          <select name="invno">
          <?php echo "<option value=\"{$new_invno}\"";if($service['invno'] == $new_invno) {
                echo " selected";}
              echo ">{$new_invno}</option>";
          ?>
          </select>
        </dd>
      </dl>

     <dl>
        <dt>Coupon No</dt>
        <dd>
          <select name="coupon_no">
            <option value=" ">No coupon used</option>;
          <?php
            foreach($coupon_set as $coupon) {
              echo "<option value=\"{$coupon['coupon']}\"";
              if(($service['coupon_no'] == $coupon['coupon_no'])and($service['coupon_no']!= '')) {
                echo " selected";
              }
              echo ">{$coupon['coupon_no']}</option>";
            }
          ?>
          </select>
        </dd>(Optional)
      </dl>
      <br>
      
   
      <div id="operations">
        <input type="submit" value="Create New Service" />
      </div>
    </form>

  </div>

</div>
<br><br>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>

<?php

mysqli_free_result($office_set);
mysqli_free_result($vehicle_set);
mysqli_free_result($coupon_set);

}

?>


