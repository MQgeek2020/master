<?php require_once('../../../private/initialize.php'); ?>

<?php

require_cust_login();

$id = $_GET['id'] ?? '1'; 

$customer = find_customer_by_id($id);


if($customer['cust_type'] == "I"){ 

  $custind = find_custind_by_custid($id);
  $custind_count = mysqli_num_rows($custind);

} elseif ($customer['cust_type'] == "C"){
  
  $custcor = find_custcor_by_custid($id);
  $custcor_count = mysqli_num_rows($custcor);
}

?>

<?php $page_title = 'Show Customer'; ?>
<?php include(SHARED_PATH . '/customer_login_header.php'); ?>

<div id="content">
  <div>
  <?php  $msg[]= "You have completed your profile. ";
         $msg[]= "Go to your WOW homepage and start a new service!";
         echo display_messages($msg);
  ?>
</div>

  <div class="customer show">

    <h1>Customer ID: <?php echo h($customer['cust_id']); ?></h1>
    <h2>General Infomation:</h2>
    <div class="attributes">

    <dl>
        <dt>CustType</dt>
        <dd>
         <dd><?php echo h($customer['cust_type']) == 'I' ? 'Individual' : 'Corporation'; ?></dd>
        </dd>
      </dl>
       <dl>
        <dt>First Name:</dt>
        <dd><?php echo name_format(h($customer['fname'])); ?></dd>
      </dl>
      <dl>
        <dt>Last Name</dt>
        <dd><?php echo name_format(h($customer['lname'])); ?></dd>
      </dl>
      <dl>
        <dt>State</dt>
        <dd><?php echo h($customer['state']); ?></dd>
      </dl>
      <dl>
        <dt>City</dt>
        <dd><?php echo h($customer['city']); ?></dd>
      </dl>
       <dl>
        <dt>Street</dt>
        <dd><?php echo h($customer['st_addr']); ?></dd>
      </dl>
       <dl>
        <dt>Apartment</dt>
        <dd><?php echo h($customer['apt']) == 0 ? 'NULL' : h($customer['apt']); ?></dd>
      </dl>
       <dl>
        <dt>Zipcode</dt>
        <dd><?php echo h($customer['zipcode']); ?></dd>
      </dl>
      <dl>
        <dt>Email</dt>
        <dd><?php echo h($customer['email']); ?></dd>
      </dl>
      <dl>
        <dt>Phone</dt>
        <dd><?php echo "+1 " . h($customer['phone']); ?></dd>
      </dl>

  <?php if(($customer['cust_type'] == "I") && ($custind_count!=0)) { 
          $custind = mysqli_fetch_assoc($custind);     ?>

        <h2>More Individual Details:</h2>
     <dl>
        <dt>Driver License Number</dt>
        <dd>
         <dd><?php echo h($custind['DLN'])?></dd>
        </dd>
      </dl>
       <dl>
        <dt>Insurance Company Name</dt>
        <dd><?php echo h($custind['INSCN']); ?></dd>
      </dl>
      <dl>
        <dt>Insurance Policy Number</dt>
        <dd><?php echo h($custind['INSPN']); ?></dd>
      </dl>

  <?php  //mysqli_free_result($custind);  
     } elseif (($customer['cust_type'] == "C") && ($custcor_count!=0)) { 
        $custcor = mysqli_fetch_assoc($custcor);  ?>

        <h2>More Corporation Details:</h2>
       <dl>
        <dt>Corp. Name</dt>
        <dd><?php echo h($custcor['corp_name']); ?></dd>
      </dl>
      <dl>
        <dt>Register Number</dt>
        <dd><?php echo h($custcor['register_no']); ?></dd>
      </dl>
       <dl>
        <dt>Employee ID</dt>
        <dd><?php echo h($custcor['emp_id']); ?></dd>
      </dl>

      <?php //mysqli_free_result($custcor);
      } ?>

      
    </div>

  </div><br>
  <a class="back-link" href="<?php echo url_for('/homepage/index.php'); ?>"> Forward to Homepage &rArr;</a>

</div>
<br><br>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>