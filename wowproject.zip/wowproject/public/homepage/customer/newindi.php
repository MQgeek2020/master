<?php

require_once('../../../private/initialize.php');



if(!isset($_SESSION['cust_type'])||!isset($_SESSION['new_cust_id'])) {
  redirect_to(url_for('/homepage/customer/new.php'));
  }
  $cust_id = $_SESSION['new_cust_id'];
  $individual = find_customer_by_id($cust_id);

 if(is_post_request()) {

  // Handle form values sent by new.php

  $custind = [];
  $custind['cust_id'] = $_POST['cust_id'] ?? '';
  $custind['DLN'] = $_POST['DLN'] ?? '';
  $custind['INSCN'] = $_POST['INSCN'] ?? '';
  $custind['INSPN'] = $_POST['INSPN'] ?? '';

  $result = insert_custind($custind);
  if($result === true){
      //$new_id = mysqli_insert_id($db);
      redirect_to(url_for('/homepage/customer/showall.php?id=' . $cust_id));
      
  }else{
      $errors = $result;
  }

} else {
  //display the blank form
  $custind = [];
  $custind['cust_id'] = '';
  $custind['DLN'] = '';
  $custind['INSCN'] = '';
  $custind['INSPN'] = '';

}

//$individual_set = find_all_individuals();

?>

<?php $page_title = 'Create Individual'; ?>
<?php include(SHARED_PATH . '/customer_login_header.php'); ?>

<div id="content">
  <a class="back-link" href="<?php echo url_for('/homepage/customer/show.php?id=' . $cust_id); ?>">&lArr; Back to General Info</a>

  <div class="Individual new">
    <h1>Individual Info</h1>

    <?php echo display_errors($errors); ?>

    <form action="<?php echo url_for('/homepage/customer/newindi.php'); ?>" method="post">
     <dl>
        <dt>Customer Name</dt>
        <dd>
          <select name="cust_id">
          <?php
              echo "<option value=\"{$individual['cust_id']}\"";
              if($custind['cust_id'] == $individual['cust_id']) {
                echo " selected";
              }
              echo ">" . h($individual['cust_id']) . "--" . h($individual['fname']). " ". h($individual['lname']) . "</option>";
          ?>
          </select>
        </dd>
      </dl>
       <dl>
        <dt>Driver License Number</dt>
        <dd><input type="text" name="DLN" value="<?php echo $custind['DLN']; ?>" /></dd>
      </dl>
       <dl>
        <dt>Insurance Company Name</dt>
        <dd><input type="text" name="INSCN" value="<?php echo $custind['INSCN']; ?>" /></dd>
      </dl>
       <dl>
        <dt>Insurance Policy Number</dt>
        <dd><input type="text" name="INSPN" value="<?php echo $custind['INSPN']; ?>" /></dd>
      </dl>
      
      <div id="operations">
        <input type="submit" value="Submit" />
      </div>
    </form>

  </div>

</div>
<?php

//mysqli_free_result($individual_set);
?>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
