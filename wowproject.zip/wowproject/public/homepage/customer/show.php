<?php require_once('../../../private/initialize.php'); ?>

<?php

require_cust_login();

$id = $_GET['id'] ?? '1'; 

$customer = find_customer_by_id($id);


?>

<?php $page_title = 'Show Customer'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>

<div id="content">
  <div>
  <?php  $msg[]= "If you find any information mismatch or need to update your personal info, ";
         $msg[]= "please contact our customer services at 777-888-9999 in time. We are glad to help!";
         echo display_messages($msg);
  ?>
</div>

  <div class="customer show">

    <h1>Customer ID: <?php echo h($customer['cust_id']); ?></h1>
    <h2>General Infomation:</h2>
    <div class="attributes">

    <dl>
        <dt>CustType</dt>
        <dd>
         <dd><?php echo h($customer['cust_type']) == 'I' ? 'Individual' : 'Corporation'; ?></dd>
        </dd>
      </dl>
       <dl>
        <dt>First Name:</dt>
        <dd><?php echo name_format(h($customer['fname'])); ?></dd>
      </dl>
      <dl>
        <dt>Last Name</dt>
        <dd><?php echo name_format(h($customer['lname'])); ?></dd>
      </dl>
      <dl>
        <dt>State</dt>
        <dd><?php echo h($customer['state']); ?></dd>
      </dl>
      <dl>
        <dt>City</dt>
        <dd><?php echo h($customer['city']); ?></dd>
      </dl>
       <dl>
        <dt>Street</dt>
        <dd><?php echo h($customer['st_addr']); ?></dd>
      </dl>
       <dl>
        <dt>Apartment</dt>
        <dd><?php echo h($customer['apt']) == 0 ? 'NULL' : h($customer['apt']); ?></dd>
      </dl>
       <dl>
        <dt>Zipcode</dt>
        <dd><?php echo h($customer['zipcode']); ?></dd>
      </dl>
      <dl>
        <dt>Email</dt>
        <dd><?php echo h($customer['email']); ?></dd>
      </dl>
      <dl>
        <dt>Phone</dt>
        <dd><?php echo "+1 " . h($customer['phone']); ?></dd>
      </dl><br>

  <?php if($customer['cust_type'] == "I") {   ?>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/homepage/customer/newindi.php'); ?>">Next Step &rArr; </a>
    </div>

  <?php  } elseif ($customer['cust_type'] == "C") {  ?>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/homepage/customer/newcorp.php'); ?>">Next Step &rArr;</a>
    </div>


      <?php } ?>

      
    </div>


  </div>

</div>
<br><br>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>