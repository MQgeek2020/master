<?php

require_once('../../../private/initialize.php');

if(is_post_request()) {

  // Handle form values sent by new.php
  // Single page post submission


  $customer = [];
  $customer['cust_type'] = $_POST['CustType'] ?? '';
  $customer['fname'] = $_POST['fname'] ?? '';
  $customer['lname'] = $_POST['lname'] ?? '';
  $customer['state'] = $_POST['state'] ?? '';
  $customer['city'] = $_POST['city'] ?? '';
  $customer['st_addr'] = $_POST['street'] ?? '';
  $customer['apt'] = $_POST['apartment'] ?? '';
  $customer['zipcode'] = $_POST['zipcode'] ?? '';
  $customer['email'] = $_POST['email'] ?? '';
  $customer['phone'] = $_POST['phone'] ?? '';
  // $_SESSION['cust_username'] = $admin['username'];
  // $_SESSION['cust_first_name'] = $admin['first_name'];
  // $_SESSION['cust_last_name'] = $admin['last_name'];
 
  $result = insert_customer($customer);
  if($result === true){
      $new_id = mysqli_insert_id($db);
      $_SESSION['cust_type'] =  $customer['cust_type'];
      $_SESSION['new_cust_id'] = $new_id;
      redirect_to(url_for('/homepage/customer/show.php?id=' . $new_id));
  }else{
      $errors = $result;
  }

} else {
  //display the blank form
  $customer = [];
  $customer['cust_type'] = '';
  $customer['fname'] = '';
  $customer['lname'] = '';
  $customer['state'] = '';
  $customer['city'] = '';
  $customer['st_addr'] = '';
  $customer['apt'] = '';
  $customer['zipcode'] = '';
  $customer['email'] =  '';
  $customer['phone'] = '';

}

$cust_admin_id = $_SESSION['cust_admin_id'];
$cust_admin = find_cust_admin_by_id($cust_admin_id);

?>



<?php $page_title = 'Create Customer'; ?>
<?php include(SHARED_PATH . '/customer_login_header.php'); ?>


<div id="content">

  <a class="back-link" href="<?php echo url_for('/homepage/index.php'); ?>">&lArr; Back to Homepage</a>

  <div class="customer new">
    <h1>Create Profile</h1>

    <?php echo display_errors($errors); ?>

    <?php /* <form action="<?php echo url_for('/staff/customer/create.php'); ?>" method="post"> */?>
    <form action="<?php echo url_for('/homepage/customer/new.php');?>" method="post">

      <dl>
        <dt>CustType</dt>
        <dd>
          <input type="radio" name="CustType" value="I" <?php if(h($customer['cust_type']) == 'I') echo "checked"; ?>/>Login as an individual customer<br>
          <input type="radio" name="CustType" value="C" <?php if(h($customer['cust_type']) == 'C') echo "checked"; ?>/>Login as a corporation representative
        </dd>
      </dl>
      <dl>
        <dt>First Name:</dt>
        <dd><input type="text" name="fname" value="<?php echo $cust_admin['first_name']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Last Name</dt>
        <dd><input type="text" name="lname" value="<?php echo $cust_admin['last_name']; ?>" /></dd>
      </dl>
      <dl>
        <dt>State</dt>
        <dd><input type="text" name="state" value="<?php echo $customer['state']; ?>" /></dd>
      </dl>
      <dl>
        <dt>City</dt>
        <dd><input type="text" name="city" value="<?php echo $customer['city']; ?>" /></dd>
      </dl>
       <dl>
        <dt>Street</dt>
        <dd><input type="text" name="street" value="<?php echo $customer['st_addr']; ?>" /></dd>
      </dl>
       <dl>
        <dt>Apartment</dt>
        <dd><input type="text" name="apartment" value="<?php echo $customer['apt']; ?>" /></dd>(Optional)
      </dl>
       <dl>
        <dt>Zipcode</dt>
        <dd><input type="number" name="zipcode" value="<?php echo $customer['zipcode']; ?>" min="0"/></dd>
      </dl>
      <dl>
        <dt>Email</dt>
        <dd><input type="email" name="email" value="<?php echo $cust_admin['email']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Phone</dt>
        <dd><input type="text" name="phone" value="<?php echo $customer['phone']; ?>" /></dd>

        <br><br>
      <div id="operations">
        <input type="submit" value="Submit My Profile" />
      </div>
    </form>

  </div>
</div>
<br>




<?php include(SHARED_PATH . '/staff_footer.php'); ?>
