<?php require_once('../../../private/initialize.php'); ?>

<?php

require_cust_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/homepage/index.php'));
}
$cust_id = $_GET['id'];

$invoice_info_set = find_cust_invoices_info_by_id($cust_id);
$invoice_count = mysqli_num_rows($invoice_info_set);
//$invoice_count = 0;

?>

<?php $page_title = 'Invoices'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>

<div id="content">
 
  <a class="back-link" href="<?php echo url_for('/homepage/index.php'); ?>">&laquo; Back to Homepage</a>

  <div class="invoices listing">
    <h1>Invoices Info</h1>

    <?php if($invoice_count== 0 ){
      $msg[] = "No invoices found. You haven't ordered any service yet. ";
      $msg[] = "Go back to your homepage and start a WOW service! ";
      $msg[] = "If you have any questions, please contact us at +1 777-888-9999.";
      echo display_messages($msg);

    } if ($invoice_count!= 0) { ?>

  	<table class="list">
  	  <tr>
        <th>Invoice No.</th>
        <th>Invoice Date</th>
        <th>Invoice Amount(/$)</th>
        <th>Payment Date</th>
        <th>Payment Amount(/$)</th>
        <th>Card Number</th>
        <th>Method</th>
        <th>Payment Status</th>
  	    <th>&nbsp;</th>
  	  </tr>

      <?php while($invoice_info = mysqli_fetch_assoc($invoice_info_set)){ ?>
        <tr>
          <td><?php echo h($invoice_info['invno']); ?></td>
          <td><?php echo h($invoice_info['inv_date']); ?></td>
    	    <td><?php echo h($invoice_info['inv_amount']); ?></td>
          <td><?php echo h($invoice_info['pay_date']); ?></td>
          <td><?php echo h($invoice_info['pay_amount']); ?></td>
          <td><?php echo h($invoice_info['card_no']); ?></td>
          <td><?php if($invoice_info['method'] == 'G'){
                  echo 'Gift';
             } else{
              echo $invoice_info['method'] == 'C' ? 'Credit' : 'Debit';  } ?> 
          </td>
          <td><?php if($invoice_info['pay_status'] == 'CLEARED'){
                  echo 'Cleared';
             } else{
              echo $invoice_info['pay_status'] == 'UNCLEARED' ? 'Uncleared' : 'Unpaid';  }
              ?> </td>
          <td><a class="action" href="<?php echo url_for('/homepage/invoice/show.php?txn_id=' . h(u($invoice_info['txn_id'])). '&invno='. h(u($invoice_info['invno'])). '&cust_id=' . h(u($cust_id))); ?>">View More &rArr;</a></td>
    	  </tr>
      <?php } ?>
  	</table>

    <?php
      mysqli_free_result($invoice_info_set); }
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
