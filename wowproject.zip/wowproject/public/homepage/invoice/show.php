<?php require_once('../../../private/initialize.php'); ?>

<?php


require_cust_login();

$txn_id = $_GET['txn_id'] ?? '1'; // PHP > 7.0
$invno = $_GET['invno'] ?? '1';
$cust_id = $_GET['cust_id'];

$invpay = find_invpay_by_id($txn_id);
$invoice = find_invoice_by_id($invno);
?>

<?php $page_title = 'Show Invoice Payment'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/homepage/invoice/index.php?id=' . h(u($cust_id))); ?>">&laquo; Back to Invoices Info</a>

  <div class="invpay show">

   <h1>Invoice No: <?php echo h($invoice['invno']); ?></h1>

    <div class="attributes">
      <dl>
        <dt>Invoice No</dt>
        <dd><?php echo h($invpay['invno']); ?></dd>
      </dl>    
       <dl>
        <dt>Transaction ID</dt>
         <dd><?php echo h($invpay['txn_id']); ?></dd>
      </dl>
      <dl>
        <dt>Invoice Date</dt>
        <dd><?php echo h($invoice['inv_date']); ?></dd>
      </dl>
      <dl>
        <dt>Invoice Amount</dt>
        <dd><?php echo h($invoice['inv_amount'])."  $"; ?></dd>   
      </dl>
    <dl>
        <dt>Payment No</dt>
        <dd><?php echo h($invpay['payno']); ?></dd>
      </dl>
      <dl>
        <dt>Transaction Date</dt>
        <dd><?php echo h($invpay['pay_date']); ?></dd>
      </dl>
      <dl>
        <dt>Payment Amount</dt>
        <dd><?php echo h($invpay['pay_amount']) . "  $"; ?></dd>
      </dl>
      <dl>
        <dt>Status</dt>
         <dd><?php if($invpay['pay_status'] == 'CLEARED'){
                  echo 'Cleared';
             } else{
              echo $invpay['pay_status'] == 'UNCLEARED' ? 'Uncleared' : 'Unpaid';  }
              
              ?> </td><dd>
      </dl>   

   </div>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>