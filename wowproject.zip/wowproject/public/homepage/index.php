<?php require_once('../../private/initialize.php'); ?>

<?php require_cust_login(); 


$username = $_SESSION['cust_username'];
//echo $username;
/*if(!isset($_GET['username'])) {
  redirect_to(url_for('/homepage/login.php'));
}*/

$cust_admin = find_cust_admin_by_username($username);
$admin_id = $cust_admin['id'];
$customer = find_customer_by_cust_admin($cust_admin);

//$admin_id = 1;
//$cust_id = 1;


?>

<?php include(SHARED_PATH . '/customer_header.php'); ?>
<div id="content">



 <?php if(!isset($customer)){   ?>
  <div id="main-menu">
    <?php $page_title = 'Main Menu'; ?>
  
      <p><h2>Hello new visitor! <br>
        Welcome to your home page!</h2></p> 

      <?php  $msg[] = "Please complete your personal profile first before any operations!";
        echo display_messages($msg);?>
        
  <div class="actions">
      <a class="action" href="<?php echo url_for('/homepage/customer/new.php'); ?>">Add new profile &rArr;</a>
    </div>
  </div>

    <?php  } else { 
      $cust_id = $customer['cust_id']; 
      $customer = find_customer_by_id($cust_id);
      ?>

  <div id="main-menu">
    <?php $page_title = 'Main Menu'; ?>
  
      <p><h2>Hello <?php echo name_format(h($customer['fname'])) . " ".  name_format(h($customer['lname'])). "! " ?>
      Welcome to your home page! </h2></p> 

    <h2>Main Menu</h2>
    <ul>
      <li><b>Personal Info</b></li>
      <li><a href="<?php echo url_for('/homepage/admins/index.php?admin_id=' . h(u($admin_id))); ?>">MyAdmin</a></li>
      <li><a href="<?php echo url_for('/homepage/coupon/index.php?id=' . h(u($cust_id))); ?>">Coupon</a></li>
      <li><a href="<?php echo url_for('/homepage/payment/index.php?id=' . h(u($cust_id))); ?>">PaymentMethods</a></li><br>
      <li><b>Avaliable vehicles</b></li>
      <li><a href="<?php echo url_for('/homepage/vehicle/index.php'); ?>">Vehicles Info Overview</a></li>
      <li><a href="<?php echo url_for('/homepage/office/index.php'); ?>">WOW Offices</a></li>
      <li><a href="<?php echo url_for('/homepage/vclass/index.php'); ?>">Vehicle Types</a></li><br>
     
      <li><b>Services</b></li>
      <li><a href="<?php echo url_for('/homepage/service/index.php?id=' . h(u($cust_id))); ?>">Ordered Services</a></li>
      <li><a href="<?php echo url_for('/homepage/invoice/index.php?id=' . h(u($cust_id))); ?>">Invoices Info</a></li>
    
    </ul>
 </div>


<?php $page_title = 'Customer info'; ?>

  <div class="customers listing">
    <h3>Customer Profile</h3>

    <table class="list">
      <tr>
        <th>ID</th>
        <th>CustType</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>State</th>
        <th>City</th>
        <th>Street</th>
        <th>Apartment</th>
        <th>Zipcode</th>
        <th>Email</th>
        <th>Phone</th>
        <th>&nbsp;</th>
      </tr>

        <tr>
          <td><?php echo h($customer['cust_id']); ?></td>
          <td><?php echo $customer['cust_type'] == 'I' ? 'Individual' : 'Corporation'; ?></td>
          <td><?php echo name_format(h($customer['fname'])); ?></td>
          <td><?php echo name_format(h($customer['lname'])); ?></td>
          <td><?php echo h($customer['state']); ?></td>
          <td><?php echo h($customer['city']); ?></td>
          <td><?php echo h($customer['st_addr']); ?></td>
          <td><?php echo h($customer['apt'])==0 ? 'NULL' : h($customer['apt']); ?></td>
          <td><?php echo h($customer['zipcode']); ?></td>
          <td><?php echo h($customer['email']); ?></td>
          <td><?php echo "+1 " . h($customer['phone']); ?></td>
          
          <td><a class="action" href="<?php echo url_for('/homepage/customer/showcust.php?id=' . h(u($customer['cust_id']))); ?>">View More &rArr;</a></td>
        </tr>
  
    </table>

  </div>

     <p><h3><b>Quick Operations:</b></h3></p>
    <div class="actions">
      <a class="action" href="<?php echo url_for('/homepage/payment/new.php?cust_id='. h($cust_id)); ?>">Create New Pay Method &rArr;</a><br><br>
      <a class="action" href="<?php echo url_for('/homepage/service/new.php?cust_id='. h($cust_id)); ?>">Create New Service &rArr;</a>
    </div>
    
  </div>


<?php include(SHARED_PATH . '/staff_footer.php'); ?>

  <?php }  ?>
