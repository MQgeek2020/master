<?php require_once('../../../private/initialize.php'); ?>

<?php

require_cust_login();

if(!isset($_GET['coupon_no'])||!isset($_GET['cust_id'])) {
  redirect_to(url_for('/homepage/coupon/index.php'));
}
$coupon_no = $_GET['coupon_no']; // PHP > 7.0
$cust_id = $_GET['cust_id'];

$coupon = find_coupon_by_id($coupon_no);
?>

<?php $page_title = 'Show Coupon'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/homepage/coupon/index.php?id=' . h(u($cust_id))); ?>">&laquo; Back to MyCoupons</a>

  <div class="coupon show">

  	<h1>Coupon No: <?php echo h($coupon['coupon_no']); ?></h1>

  	<div class="attributes">
    <?php $customer = find_customer_by_id($coupon['cust_id']); ?>
     <dl>
        <dt>Customer Name</dt>
        <dd><?php echo name_format(h($customer['fname'])). " " .name_format(h($customer['lname'])); ?></dd>
      </dl>
      <dl>
        <dt>Coupon Type</dt>
        <dd><?php echo $coupon['coup_type'] == 'IND' ? 'Individual' : 'Corporation'; ?></dd>
      </dl>
      <dl>
        <dt>Discount</dt>
        <dd><?php echo h($coupon['discount']) . " %"; ?></dd>
      </dl>
      <dl>
        <dt>Start Date</dt>
        <dd><?php echo h($coupon['sta_date']); ?></dd>
      </dl>
      <dl>
        <dt>Expiration Date</dt>
        <dd><?php echo h($coupon['exp_date']); ?></dd>
      </dl>

   </div>

  </div>

</div>
<?php include(SHARED_PATH . '/staff_footer.php'); ?>