<?php require_once('../../../private/initialize.php'); ?>

<?php

require_cust_login();

if(!isset($_GET['id'])) {
  redirect_to(url_for('/homepage/index.php'));
}
$cust_id = $_GET['id'];

$coupon_set = find_coupons_by_custid($cust_id);
$coupon_count = mysqli_num_rows($coupon_set);
//$coupon_count = 0;

?>

<?php $page_title = 'Coupon'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>

<div id="content">

 <a class="back-link" href="<?php echo url_for('/homepage/index.php'); ?>">&laquo; Back to Homepage</a>

  <div class="coupons listing">
    <h1>MyCoupons</h1>

  <?php if($coupon_count== 0){
      $msg[] = "Seems that you haven't ordered any coupon yet! ";
      $msg[] = "We have prepared a lot of promoption for both new and regular customers! ";
      $msg[] = "For more details, please check our official website www.worldonwheels.com. ";
      $msg[] = "If you have any questions, please contact us at +1 777-888-9999.";
      echo display_messages($msg);

    } if ($coupon_count!= 0) { ?>

  	<table class="list">
  	  <tr>
        <th>Coupon No</th>
        <th>Coupon Type</th>
        <th>Discount in %</th>
        <th>Start Date</th>
        <th>Expiration Date</th>
  	    <th>&nbsp;</th>
  	  </tr>

      <?php while($coupon = mysqli_fetch_assoc($coupon_set)) { ?>
      <?php //$customer = find_customer_by_id($coupon['cust_id']); ?>
        <tr>
          <td><?php echo h($coupon['coupon_no']); ?></td>
          <td><?php echo h($coupon['coup_type']) == 'IND' ? 'Individual' : 'Corporation'; ?></td>
          <td><?php echo h($coupon['discount']); ?></td>
          <td><?php echo h($coupon['sta_date']); ?></td>
          <td><?php echo h($coupon['exp_date']); ?></td>
          <td><a class="action" href="<?php echo url_for('/homepage/coupon/show.php?coupon_no=' . h(u($coupon['coupon_no'])). '&cust_id=' . h(u($cust_id))); ?>">View More &rArr;</a></td>
    	  </tr>
      <?php } ?>
  	</table>

    <?php
      mysqli_free_result($coupon_set); }
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
