<?php
require_once('../../private/initialize.php');

log_out_cust_admin();
redirect_to(url_for('/homepage/login.php'));

?>
