<?php

require_once('../../../private/initialize.php');

require_cust_login();

if(!isset($_GET['admin_id'])) {
  redirect_to(url_for('/homepage/index.php'));
}
$admin_id = $_GET['admin_id'];

$cust_admin = find_cust_admin_by_id($admin_id);

?>

<?php $page_title = 'Admins'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>

<div id="content">

  <div id="content">
  <a class="back-link" href="<?php echo url_for('/homepage/index.php'); ?>">&laquo; Back to Homepage</a>

  <div class="admins listing">
    <h1>MyLoginAdmin</h1>

    <table class="list">
      <tr>
        <th>ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Username</th>
        <th>&nbsp;</th>
        <th>&nbsp;</th>
      </tr>

      <?php //while($admin = mysqli_fetch_assoc($admin_set)) { ?>
        <tr>
          <td><?php echo h($cust_admin['id']); ?></td>
          <td><?php echo h($cust_admin['first_name']); ?></td>
          <td><?php echo h($cust_admin['last_name']); ?></td>
          <td><?php echo h($cust_admin['email']); ?></td>
          <td><?php echo h($cust_admin['username']); ?></td>
          <td><a class="action" href="<?php echo url_for('/homepage/admins/show.php?id=' . h(u($cust_admin['id']))); ?>">View &rArr;</a></td>
          <td><a class="action" href="<?php echo url_for('/homepage/admins/edit.php?id=' . h(u($cust_admin['id']))); ?>">Edit Password &rArr;</a></td>
        </tr>
      <? //php } ?>
    </table>

    <?php
      //mysqli_free_result($admin_set);
    ?>
  </div>

</div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
