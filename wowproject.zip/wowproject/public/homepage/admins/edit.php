<?php

require_once('../../../private/initialize.php');

require_cust_login();

/*if(!isset($_SESSION['username'])) {
  redirect_to(url_for('/homepage/login.php'));
}

$username = $_SESSION['username'];
echo $username;
$cust_admin = find_cust_admin_by_username($username);
$admin_id = $cust_admin['id'];
echo $admin_id;*/
$username = $_SESSION['cust_username'];
$cust_admin = find_cust_admin_by_username($username);
$admin_id = $cust_admin['id'];
$customer = find_customer_by_cust_admin($cust_admin);
//$cust_id = $_SESSION['cust_id'];
//$customer = find_customer_by_id($cust_id);

if(!isset($_GET['id'])) {
  redirect_to(url_for('/homepage/admins/index.php'));
}

$admin_id = $_GET['id'];

if(is_post_request()) {
  $admin = [];
  $admin['id'] = $admin_id;
  $admin['first_name'] = $customer['fname'] ?? '';
  $admin['last_name'] = $customer['lname'] ?? '';
  $admin['email'] = $customer['email'] ?? '';
  $admin['username'] = $username ?? '';
  $admin['password'] = $_POST['password'] ?? '';
  $admin['confirm_password'] = $_POST['confirm_password'] ?? '';

  $result = update_cust_admin($admin);
  if($result === true) {
    $_SESSION['message'] = 'Your Password Updated.';
    redirect_to(url_for('/homepage/admins/show.php?id=' . $admin_id));
  } else {
    $errors = $result;
  }
} else {
  $cust_admin = find_cust_admin_by_id($admin_id);
}


?>

<?php $page_title = 'Edit My Admin'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>

<div id="content">

   <div>
    <?php  $msg[]= "If you have any trouble with your WOW Admin or have any questions, ";
         $msg[]= "please contact our staff at +1 777-888-9999 in time. ";
         $msg[]= "We are 24hrs online and glad to help!";
         echo display_messages($msg);
     ?></div>

  <a class="back-link" href="<?php echo url_for('/homepage/admins/index.php?admin_id=' . h(u($admin_id))); ?>">&laquo; Back to MyLoginAdmin</a>

  <div class="admin edit">
    <h1>Edit Password</h1>


    <?php echo display_errors($errors); ?>

    <form action="<?php echo url_for('/homepage/admins/edit.php?id=' . h(u($admin_id))); ?>" method="post">
      <dl>
        <dt>First name</dt>
        <dd><input type="text" name="first_name" value="<?php echo h($customer['fname']); ?>" /></dd>
      </dl>

      <dl>
        <dt>Last name</dt>
        <dd><input type="text" name="last_name" value="<?php echo h($customer['lname']); ?>" /></dd>
      </dl>

      <dl>
        <dt>Username</dt>
        <dd><input type="text" name="username" value="<?php echo h($cust_admin['username']); ?>" /></dd>
      </dl>

      <dl>
        <dt>Email</dt>
        <dd><input type="text" name="email" value="<?php echo h($customer['email']); ?>" /><br /></dd>
      </dl>

      <dl>
        <dt>Password</dt>
        <dd><input type="password" name="password" value="" /></dd>
      </dl>

      <dl>
        <dt>Confirm Password</dt>
        <dd><input type="password" name="confirm_password" value="" /></dd>
      </dl>
      <p>
        Passwords should be at least 8 characters and include at least one uppercase letter, lowercase letter and number.
      </p>
      <div id="operations">
        <input type="submit" value="Edit Admin" />
      </div>
    </form>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
