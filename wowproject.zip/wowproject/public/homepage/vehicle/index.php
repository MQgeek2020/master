
<?php require_once('../../../private/initialize.php'); ?>

<?php
  
  require_cust_login();

  $vehicle_info_set = find_all_vehicles_info();
  $vehicle_info_count = mysqli_num_rows($vehicle_info_set);
  //$vehicle_info_count = 0;
?>

<?php $page_title = 'Vehicles'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/homepage/index.php'); ?>">&laquo; Back to Homepage</a>

  <div class="vehicles listing">
    <h1>Vehicles Information</h1>

    <?php if($vehicle_info_count== 0){
      $msg[] = "No more vehicle info. Coming Soon...";
        echo display_messages($msg);

    } if ($vehicle_info_count!= 0) { ?>

  	<table class="list">
  	  <tr>
        <th>Office ID</th>
        <th>Office State</th>
        <th>Office City</th>
        <th>Vehicle ID</th>
  	    <th>Make</th>
        <th>Model</th>
        <th>Vehicle Identification Number</th>
        <th>License Plate number</th>
        <th>Vehcle Type</th>
        <th>Rent Charge ($/day)</th>
        <th>Extra Charge ($/mile)</th>
  	    <th>&nbsp;</th>
  	  </tr>

      <?php while($vehicle_info = mysqli_fetch_assoc($vehicle_info_set))  { ?>
      <?php //$vclass = find_vclass_by_id($vehicle['vclass_id']); ?>
        <tr>
          <td><?php echo h($vehicle_info['loc_id']); ?></td>
          <td><?php echo h($vehicle_info['loc_state']); ?></td>       
    	    <td><?php echo h($vehicle_info['loc_city']); ?></td>
          <td><?php echo h($vehicle_info['veh_id']); ?></td>
          <td><?php echo h($vehicle_info['make']); ?></td>
          <td><?php echo h($vehicle_info['model']); ?></td>       
          <td><?php echo h($vehicle_info['VIN']); ?></td>     
          <td><?php echo h($vehicle_info['LPN']); ?></td>
          <td><?php echo h($vehicle_info['vc_name']); ?></td>
          <td><?php echo h($vehicle_info['rent_charge']); ?></td>
          <td><?php echo h($vehicle_info['extra_charge']); ?></td>
          <td><a class="action" href="<?php echo url_for('/homepage/vehicle/vehicle_info_show.php?veh_id=' . h(u($vehicle_info['veh_id']))); ?>">View More &rArr;</a></td>
    	  </tr>
      <?php } ?>
  	</table>

    
    <?php
      mysqli_free_result($vehicle_info_set); }
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
