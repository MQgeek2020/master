<?php require_once('../../../private/initialize.php'); ?>

<?php

require_cust_login();

if(!isset($_GET['veh_id'])) {
  redirect_to(url_for('/homepage/office/show.php'));
}
$veh_id = $_GET['veh_id'];
//$vclass_id = $_GET['vclass_id'];

$vehicle = find_vehicle_by_id($veh_id);
$vclass = find_vclass_by_id($vehicle['vclass_id']);
$office = find_office_by_id($vehicle['loc_id']);

?>

<?php $page_title = 'Show Vehicle details'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/homepage/office/show.php?loc_id='. h(u($vehicle['loc_id']))); ?>">&laquo; Back to office info</a>

  <div class="vehicle show">
    <?php //$vclass = find_vclass_by_id($vehicle['vclass_id']); ?>

    <h1>Vehicle Type: <?php echo h($vclass['vc_name']); ?></h1>

    <div class="attributes">
      
       <dl>
        <dt>Vehicle ID</dt>
        <dd><?php echo h($vehicle['veh_id']); ?></dd>
      </dl>
       <dl>
        <dt>Vehicle Make</dt>
        <dd><?php echo h($vehicle['make']); ?></dd>
      </dl>
       <dl>
        <dt>Vehicle Model</dt>
        <dd><?php echo h($vehicle['model']); ?></dd>
      </dl>
      <dl>
        <dt>Year of Production</dt>
        <dd><?php echo h($vehicle['vyear']); ?></dd>
      </dl>
      <dl>
        <dt>Vehicle Identification Number</dt>
        <dd><?php echo h($vehicle['VIN']); ?></dd>
      </dl>
      <dl>
        <dt>License Plate number</dt>
        <dd><?php echo h($vehicle['LPN']); ?></dd>
      </dl>
      <dl>
        <dt>Rent Charge</dt>
        <dd><?php echo h($vclass['rent_charge']). "  $/day"; ?></dd> 
      </dl>  
      <dl>
        <dt>Extra Charge</dt>
        <dd><?php echo h($vclass['extra_charge']). " $/mile"; ?></dd>
      </dl>       
      <dl>
        <dt>Office ID</dt>
        <dd><?php echo h($vehicle['loc_id']); ?></dd>
      </dl>
      <dl>
        <dt>Office Full Address</dt>
        <dd><?php if($office['floor']!=0){
          echo h($office['loc_state']).",  ". h($office['loc_city']) . ",  " . h($office['loc_st']). "  St., ". h($office['floor']). "th floor";
          } elseif($office['floor'] == 0){
            echo h($office['loc_state']).",  ". h($office['loc_city']) . ",  " . h($office['loc_st']). "  St.";
          }
          ?></dd>
      </dl>      

    </div>
  </div>

</div>



<?php include(SHARED_PATH . '/staff_footer.php'); ?>