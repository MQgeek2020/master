<?php require_once('../../../private/initialize.php'); ?>

<?php require_cust_login();

if(!isset($_GET['loc_id'])){
  redirect_to(url_for('/homepage/office/index.php'));
}

$loc_id = $_GET['loc_id'];

$office = find_office_by_id($loc_id);
$vehicle_set = find_vehicles_by_office_id($loc_id);
$vehicle_count = mysqli_num_rows($vehicle_set);

?>

<?php $page_title = 'Show Office Location'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/homepage/office/index.php'); ?>">&laquo; Back to Office Locations</a>

  <div class="office show">

    <h1>Office ID: <?php echo h($office['loc_id']); ?></h1>

    <div class="attributes">
    <dl>
        <dt>State</dt>
        <dd><?php echo h($office['loc_state']); ?></dd>
      </dl>
      <dl>
        <dt>City</dt>
        <dd><?php echo h($office['loc_city']); ?></dd>
      </dl>
       <dl>
        <dt>Street</dt>
        <dd><?php echo h($office['loc_st']); ?></dd>
      </dl>
       <dl>
        <dt>Floor</dt>
        <dd><?php echo h($office['floor']) == 0 ? 'NULL' : h($office['floor']); ?></dd>
      </dl>
       <dl>
        <dt>Zipcode</dt>
        <dd><?php echo h($office['loc_zipcode']); ?></dd>
      </dl>
      <dl>
        <dt>Phone</dt>
        <dd><?php echo "+1 " . h($office['loc_phone']); ?></dd>
      </dl>
      
   </div>

    <hr />

<?php $msg[]= "Sorry we haven't had vehicles in this office yet. Coming Soon...";
 if($vehicle_count==0){ echo display_messages($msg);} ?>

<?php if($vehicle_count!=0){ ?>
  <div class="vehicles listing">
    <h1>Vehicles</h1>

    <table class="list">
      <tr>
        <th>Vehicle ID</th>
        <th>Make</th>
        <th>Model</th>
        <th>Year</th>
        <th>Vehicle Identification Number</th>
        <th>License Plate number</th>
        <th>Vehcle Type</th>
        <th>Rent Charge ($/day)</th>
        <th>Extra Charge ($/mile)</th>
        <th>&nbsp;</th>
      </tr>

      <?php while($vehicle = mysqli_fetch_assoc($vehicle_set))  { ?>
      <?php $vclass = find_vclass_by_id($vehicle['vclass_id']); ?>
        <tr>
          <td><?php echo h($vehicle['veh_id']); ?></td>
          <td><?php echo h($vehicle['make']); ?></td>       
          <td><?php echo h($vehicle['model']); ?></td>
          <td><?php echo h($vehicle['vyear']); ?></td>
          <td><?php echo h($vehicle['VIN']); ?></td>
          <td><?php echo h($vehicle['LPN']); ?></td>         
          <td><?php echo h($vclass['vc_name']); ?></td>
          <td><?php echo h($vclass['rent_charge']); ?></td>
          <td><?php echo h($vclass['extra_charge']); ?></td>
          <td><a class="action" href="<?php echo url_for('/homepage/vehicle/vehoff_show.php?veh_id=' . h(u($vehicle['veh_id']))); ?>">View Vehicle Info &rArr;</a></td>
        </tr>
      <?php } ?>
    </table>

    
    <?php mysqli_free_result($vehicle_set);?>
 
    </div>

  </div>

</div>

   <?php //include(SHARED_PATH . '/staff_footer.php'); ?>

<?php } ?>

