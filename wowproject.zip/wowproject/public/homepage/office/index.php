
<?php require_once('../../../private/initialize.php'); ?>

<?php
  require_cust_login();
  
  $office_set = find_all_offices();
  $office_count = mysqli_num_rows($office_set);
  //$office_count = 0;
?>

<?php $page_title = 'Office Locations'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>

<div id="content">

 <a class="back-link" href="<?php echo url_for('/homepage/index.php'); ?>">&laquo; Back to Homepage</a>

  <div class="offices listing">
    <h1>Office Locations</h1>

    <?php if($office_count== 0){
      $msg[] = "No more infomation about WOW offices yet. Coming Soon...";
        echo display_messages($msg);

    } if ($office_count!= 0) { ?>

  	<table class="list">
  	  <tr>
        <th>ID</th>
        <th>State</th>
        <th>City</th>
  	    <th>Street</th>
        <th>Floor</th>
        <th>Zipcode</th>
        <th>Phone</th>
        <th>Vehicles Stored</th>
  	    <th>&nbsp;</th>
  	  </tr>

      <?php while($office = mysqli_fetch_assoc($office_set)) { ?>
      <?php $vehicle_count = count_vehicles_by_office_id($office['loc_id']); ?>
        <tr>
          <td><?php echo h($office['loc_id']); ?></td>
          <td><?php echo h($office['loc_state']); ?></td>
          <td><?php echo h($office['loc_city']); ?></td>
          <td><?php echo h($office['loc_st']); ?></td>
          <td><?php echo h($office['floor']) == 0 ? 'NULL' : h($office['floor']); ?></td>
          <td><?php echo h($office['loc_zipcode']); ?></td>
          <td><?php echo "+1 " . h($office['loc_phone']); ?></td>
          <td><?php echo $vehicle_count; ?></td>

          <td><a class="action" href="<?php echo url_for('/homepage/office/show.php?loc_id=' . h(u($office['loc_id']))); ?>">View More &rArr;</a></td>
    	  </tr>
      <?php } ?>
  	</table>

    <?php
      mysqli_free_result($office_set); }
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
