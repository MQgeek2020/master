<?php require_once('../../../private/initialize.php'); ?>

<?php require_cust_login();

  $vclass_set = find_all_vclasses();
  $vclass_count = mysqli_num_rows($vclass_set);
  //$vclass_count = 0;
?>

<?php $page_title = 'VehicleClasses'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/homepage/index.php'); ?>">&laquo; Back to Homepage</a>

  <div class="classes listing">
    <h1>Vehicle Types</h1>

  <?php if($vclass_count== 0){
      $msg[] = "No more infomartion about available vehicle types. Coming Soon...";
        echo display_messages($msg);

    } if ($vclass_count!= 0) { ?>


  	<table class="list">
  	  <tr>
        <th>Vehicle Type ID</th>
        <th>Vehicle Type Name</th>
        <th>Rental Charge Rate ($/day)</th>
  	    <th>Over Mileage Fees ($/mile)</th>
        <th>Vehicles</th>
  	    <th>&nbsp;</th>
  	  </tr>

      <?php while($vclass = mysqli_fetch_assoc($vclass_set)) { ?>
        <?php $vehicle_count = count_vehicles_by_vclass_id($vclass['vclass_id']); ?>
        <tr>
          <td><?php echo h($vclass['vclass_id']); ?></td>
          <td><?php echo h($vclass['vc_name']); ?></td>
          <td><?php echo h($vclass['rent_charge']); ?></td>
    	    <td><?php echo h($vclass['extra_charge']); ?></td>
          <td><?php echo $vehicle_count; ?></td>
          <td><a class="action" href="<?php echo url_for('/homepage/vclass/show.php?vclass_id=' . h(u($vclass['vclass_id']))); ?>">View More &rArr;</a></td>
    	  </tr>
      <?php } ?>
  	</table>
    <?php
      mysqli_free_result($vclass_set); }
    ?>

  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
