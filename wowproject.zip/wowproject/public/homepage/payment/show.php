<?php require_once('../../../private/initialize.php'); ?>

<?php

require_cust_login();

if(!isset($_GET['payno'])||!isset($_GET['cust_id'])) {
  redirect_to(url_for('/homepage/payment/index.php'));
}
$payno = $_GET['payno'];
$cust_id = $_GET['cust_id'];

$payment = find_payment_by_id($payno);

?>

<?php $page_title = 'Show Payment'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/homepage/payment/index.php?id='.h(u($cust_id))); ?>">&laquo; Back to Payments index</a>

  <div class="payment show">

    <h1>Payment No: <?php echo h($payment['payno']); ?></h1>

    <div class="attributes">
    <?php $customer = find_customer_by_id($payment['cust_id']); ?>
     <dl>
        <dt>Customer ID</dt>
        <dd><?php echo h($payment['cust_id']); ?></dd>
      </dl>
      <dl>
        <dt>Full Name</dt>
        <dd><?php echo name_format(h($customer['fname'])) . " " . name_format(h($customer['lname'])); ?></dd>
      </dl>
    	<dl>
        <dt>Card Number</dt>
        <dd><?php echo h($payment['card_no']); ?></dd>
      </dl>

      <dl>
        <dt>Method</dt>
        <dd><?php if($payment['method'] == 'G'){
                  echo 'Gift';
             } else{
              echo $payment['method'] == 'C' ? 'Credit' : 'Debit';  }
             ?>
        </dd>
      </dl>    

    </div>
  </div>
</div>
<?php include(SHARED_PATH . '/staff_footer.php'); ?>