<?php

require_once('../../../private/initialize.php');

require_cust_login();

/*if(!isset($_SESSION['username'])) {
  redirect_to(url_for('/homepage/login.php'));*/

$username = $_SESSION['cust_username'];

$cust_admin = find_cust_admin_by_username($username);
$customer = find_customer_by_cust_admin($cust_admin);
$cust_id = $customer['cust_id'];

$customer = find_customer_by_id($cust_id);

/*if(is_post_request()) {

  // Handle form values sent by new.php

  $payment = [];
  $payment['card_no'] = $_POST['card_no'] ?? '';
  $payment['method'] = $_POST['method'] ?? '';
  $payment['cust_id']= $_POST['cust_id'] ?? '';
  echo $payment['card_no'];
  $result = insert_payment($payment);
  if($result === true){
      $new_id = mysqli_insert_id($db);
      redirect_to(url_for('/homepage/payment/show.php?id=' . $new_id));
  }else{
      $errors = $result;
  }

} else {
  //display the blank form
  $payment = [];
  $payment['card_no'] = '';
  $payment['method'] = '';
  $payment['cust_id']= '';

}*/


?>

<?php $page_title = 'Create Payment'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/homepage/payment/index.php?id='. h(u($cust_id))); ?>">&laquo; Back to Payments Index</a>

  <div class="payment new">
    <h1>Create Payment Methods</h1>
    <?php if(is_post_request()) {

  // Handle form values sent by new.php

  $payment = [];
  $payment['card_no'] = $_POST['card_no'] ?? '';
  $payment['method'] = $_POST['method'] ?? '';
  $payment['cust_id']= $_POST['cust_id'] ?? '';
  
  $result = insert_payment($payment);
  if($result === true){
      $new_id = mysqli_insert_id($db);
      //redirect_to(url_for('/homepage/payment/show.php?id=' . $new_id));
      $msg[] = "Successfully create a new payment method."; 
      echo display_messages($msg);
  }else{
      $errors = $result;
  }

} else {
  //display the blank form
  $payment = [];
  $payment['card_no'] = '';
  $payment['method'] = '';
  $payment['cust_id']= '';

}

?>

    <?php echo display_errors($errors); ?>

    <form action="<?php echo url_for('/homepage/payment/new.php'); ?>" method="post">
    <dl>
        <dt>Customer Name</dt>
        <dd>
          <select name="cust_id">
          <?php
              echo "<option value=\"{$customer['cust_id']}\"";
              if($payment['cust_id'] == $customer['cust_id']) {
                echo " selected";
              }
              echo ">" . name_format(h($customer['fname'])) . " " . name_format(h($customer['lname'])) . "</option>";
          ?>
          </select>
        </dd>
      </dl>
      <dl>
        <dt>Card Number</dt>
        <dd><input type="text" name="card_no" value="" /></dd>
      </dl>

      <dl>
        <dt>Method</dt>
        <dd>
          <input type="radio" name="method" value="C">Credit Card<br>
          <input type="radio" name="method" value="D">Debit Card<br>
          <input type="radio" name="method" value="G">Gift Card<br>
        </dd>
      </dl>

      <br>
      <div id="operations">
        <input type="submit" value="Create New Method" />
      </div>
    </form>

  </div>

</div>
<?php
/*    <dl>
        <dt>Customer ID</dt>
        <dd><input type="number" name="cust_id" value="" min="1"/></dd>
      </dl>

*/


?>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
