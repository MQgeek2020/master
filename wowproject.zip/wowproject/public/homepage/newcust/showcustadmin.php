<?php

require_once('../../../private/initialize.php');



if(!isset($_GET['admin_id'])) {
  redirect_to(url_for('/homepage/index.php'));
}
$id = $_GET['admin_id'];
$admin = find_cust_admin_by_id($id);

?>

<?php $page_title = 'Show Customer Admin'; ?>
<?php include(SHARED_PATH . '/customer_login_header.php'); ?>

<div id="content">

  <div class="admin show">
    <h1>Your New Admin: </h1>
    <div>
  <?php  $msg[]= "Your admin created successfully! ";
         $msg[]= "Now you can login with your username and password. ";
         $msg[]= "Go back to the login page and manage your WOW homepage!";
         echo display_messages($msg);
  ?>
</div>
    <h2>Username: <?php echo h($admin['username']); ?></h2>

    <div class="attributes">
      <dl>
        <dt>First name</dt>
        <dd><?php echo h($admin['first_name']); ?></dd>
      </dl>
      <dl>
        <dt>Last name</dt>
        <dd><?php echo h($admin['last_name']); ?></dd>
      </dl>
      <dl>
        <dt>Email</dt>
        <dd><?php echo h($admin['email']); ?></dd>
      </dl>
      <dl>
        <dt>Username</dt>
        <dd><?php echo h($admin['username']); ?></dd>
      </dl>
    </div>

  </div>

  <a class="back-link" href="<?php echo url_for('/homepage/login.php'); ?>">Start Log In &rArr;</a>


</div>
<?php include(SHARED_PATH . '/staff_footer.php'); ?>