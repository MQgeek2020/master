<?php require_once('../../../private/initialize.php'); ?>

<?php

  $invpay_set = find_all_invpays();
?>

<?php $page_title = 'Invoice Payments'; ?>
<?php include(SHARED_PATH . '/customer_header.php'); ?>

<div id="content">
  <div class="invpays listing">
    <h1>Invoice Payments</h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/homepage/invpay/new.php'); ?>">Create New Invoice Payment</a>
    </div>

  	<table class="list">
  	  <tr>
        <th>Transaction ID</th>
        <th>Invoice No</th>
        <th>Payment No</th>
        <th>Transaction Date</th>
  	    <th>Amount</th>
        <th>Status</th>
  	    <th>&nbsp;</th>
  	    <th>&nbsp;</th>
        <th>&nbsp;</th>
  	  </tr>

      <?php while($invpay = mysqli_fetch_assoc($invpay_set))  { ?>
        <tr>
          <td><?php echo h($invpay['txn_id']); ?></td>
          <td><?php echo h($invpay['invno']); ?></td>
          <td><?php echo h($invpay['payno']); ?></td>
    	    <td><?php echo h($invpay['pay_date']); ?></td>
          <td><?php echo h($invpay['pay_amount']); ?></td>
          <td>
            <?php if($invpay['pay_status'] == 'CLEARED'){
                  echo 'Cleared';
             } else{
              echo $invpay['pay_status'] == 'UNCLEARED' ? 'Uncleared' : 'Unpaid';  }
              
              ?> </td>
          <td><a class="action" href="<?php echo url_for('/homepage/invpay/show.php?id=' . h(u($invpay['txn_id'])) ); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/homepage/invpay/edit.php?id=' . h(u($invpay['txn_id'])) ); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/homepage/invpay/delete.php?id=' . h(u($invpay['txn_id'])) ); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>
    <?php
      mysqli_free_result($invpay_set);
    ?>

  </div>

</div>

<?php
/*<td><a class="action" href="<?php echo url_for('/staff/invpay/edit.php?id=' . h(u($invpay['id']))); ?>">Edit</a></td> */
?>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
