<?php

require_once('../../../private/initialize.php');

if(!isset($_GET['id'])) {
  redirect_to(url_for('/staff/invpay/index.php'));
}
$txn_id = $_GET['id'];

if(is_post_request()) {

  $result = delete_invpay($txn_id);
  redirect_to(url_for('/staff/invpay/index.php'));

} else {
  $invpay = find_invpay_by_id($txn_id);
}

?>

<?php $page_title = 'Delete Transaction'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/invpay/index.php'); ?>">&laquo; Back to List</a>

  <div class="Transaction delete">
    <h1>Delete Transaction</h1>
    <p><h2>Are you sure you want to delete this transaction?</h2></p>
    <p class="item">
      <?php echo "Form parameters<br />";
            echo "Transaction ID: " . h($invpay['txn_id']) . "<br />";
            echo "Invoice No: " . h($invpay['invno']) . "<br />";
            echo "Payment No: " . h($invpay['payno']) . "<br />";
            echo "Payment Date: " . h($invpay['pay_date']) . "<br />";
            echo "Paymant Amount: " . h($invpay['pay_amount']) . "<br />";
            echo "Payment Status: " . h($invpay['pay_status']) . "<br />";
      ?> 
      </p>
    <br />
    <form action="<?php echo url_for('/staff/invpay/delete.php?id=' . h(u($invpay['txn_id']))); ?>" method="post">
      <div id="operations">
        <input type="submit" name="commit" value="Delete Transaction" />
      </div>
    </form>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
